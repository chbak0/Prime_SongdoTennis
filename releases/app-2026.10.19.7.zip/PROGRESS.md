# 새 디자인 구현 진행 상황 (이어서 진행용)

원본 디자인: https://claude.ai/code/artifact/076b0cf0-b612-4553-8130-86be0cf33029 (Home/HomeGuest/Main/Cart/Settings.dc.html)
작업 폴더: /home/claude/songdo_cart  · 배포 사본: /mnt/user-data/outputs/Claude_Tennis

## 결정 사항
- 기존 화면 전면 교체. 전체 일정(Day) 화면은 보류.
- 담기 시도는 적게: 목표당 거절 후 대기 2초, 목표당 담기 최대 4회(러시) / 사후 감시 중엔 슬롯이 다시 '열림'으로 바뀔 때만.
- 자동 교체·대안·한도 초과 자동 빼기 제거. 빼기는 사용자가 장바구니 화면에서 누를 때만.
- 날씨: API 생기면.
- 계정 이름: 사이트 프로필 이름 필드 미확인 → 직접 입력(기본 '계정N'), 색은 자동 배정.
- 테스트 모드: 관리자 비밀번호(처음 정함, PBKDF2 해시로 data/admin.json) → 가상 오픈 시각으로 모든 목표를 한 번에 진행.
- 공휴일은 오픈 규칙에 반영하지 않음(사이트 공지가 토·일 기준). 대회 막힘은 settings의 blocks(기본 10월 공지).

## 할 일
- [x] rules.py: 대회 막힘, 목표 최대 5/계정, swap 필드 제거
- [x] engine.py: 미리 확인(pre_seconds)·러시·사후 감시 설정, 교체 제거, 시도 횟수 제한, 지난 오픈은 즉시, 테스트 모드 시각
- [x] journal.py: 분류(cat)·레벨 붙은 자세한 로그, 로그 조회/CSV, 짧은 화면 로그
- [x] app.py (테스트 미작성): 계정 객체(이름·색), 목표 저장(최대 5), 관리자 비번, 테스트 모드, 월별 CSV, 로그 폴더 열기, 상태 API
- [x] static: index.html / style.css / app.js — 홈(로그인 전/후), 코트 예약, 장바구니·예약 내역, 설정(3탭)
- [x] 테스트 갱신·실행, 화면 Playwright 확인
- [x] README 갱신, 배포 사본 갱신, 사용자 보고, 예약된 이어하기 작업 삭제(trig_01CDT1CSpUq6cUxCXCSZ51iB)

## 관리자 대시보드(2026-10-14)
- 설정 '테스트 모드' 탭 → '관리자' 탭(대시보드). 테스트 모드는 코트 예약 화면 버튼에만 남김.
- Supabase 무료: installs/runs/issues/control/admin_secret 표, RLS 켜고 정책 없음, SECURITY DEFINER 함수(app_*, admin_*)만 anon 실행 허용. PG16에서 setup.sql 2번 실행·권한 확인.
- 관리자 인증: 지금 관리자 비밀번호 재사용(사용자 '일단 간단하게, 나중에 변경'). 대시보드 비번은 bcrypt 해시, 첫 관리자 로그인 때 admin_init으로 등록. 앱에선 메모리에만.
- 원격 제어: 공지, 긴급 정지(전체·PC별), 최소 버전. 속도 상한 원격 조정은 선택 안 함.
- 계정 구분은 사이트 아이디(이메일).
- 대시보드 탭: PC 현황 / 예약 성과(성공률·주간 추이·코트·시간대·거절 이유) / 안정성(주의·오류·429·지연) / 원격 제어.

## 모임 일정 공유(2026-10-14)
- bookings 표 + app_bookings(PC별 통째로 교체, 이번 달~다음 달만) + app_shared_calendar(control.share_calendar 켜졌을 때만).
- 대시보드 '예약 현황' 탭(달력·날짜별 내역·계정별 갱신) + '홈 달력에 배포' 켜기/끄기.
- 홈 달력 '모임 일정' = 이 PC 계정 예약·장바구니 + 배포된 다른 PC 것(계정 아이디). 상세는 달력 아래.
- 장바구니 포함, 표시는 계정 아이디(사용자 결정).

## 운영 기능(2026-10-14, VERSION 2026.10.14.2)
- core/clock.py: Date 헤더 8표본 구간 교차로 오차 측정(±), engine.now = PC시각+offset(오차범위 0.5초 이하일 때만). 켤 때·1시간마다·오픈 준비 때.
- 토큰 자동 갱신: 만료 60초 전 Keeper(once, 100초 대기) → 사이트 JS가 갱신 토큰으로 새 JWT. 실패 10분 뒤 재시도, error 상태면 안 함.
- 오류 자동 전송: journal err 로그·notify warn/err → issues(+context 40줄), 같은 문제 10분 1회, 예외 훅(스레드·메인·HTTP 처리), 화면 JS 오류.
- 자동 업데이트: releases 표(zip b64, sha256 서버 검증, 최근 3개), core/updater.py(허용 목록·버전 확인·백업), 예약 중이면 대기, 다시 시작은 접속 소켓을 새 프로세스로 넘김(Windows socket.share, 그 외 fd 상속), 실패 시 최대 4분 재시도. 리눅스에서 실제 교체·재시작 끊김 없이 확인.

## 날씨(2026-10-15, VERSION 2026.10.15)
- core/weather.py: Open-Meteo forecast(송도 37.389,126.645, Asia/Seoul, 16일, 06~22시만 보관), 30분 갱신·실패 10분 재시도, data/weather.json.
- /api/weather + state.weather_at(바뀌면 화면이 다시 읽음). 시계 아래·다음 모임·달력 아이콘·날짜 상세.
- 기상청은 나중에 필요하면 가까운 3일만 바꿔 끼울 수 있게 normalize 형태 유지.

## 로그인 창 개선(2026-10-15, 2026.10.15.3)
- 로그인 확인 즉시 창 숨김(CDP Browser.setWindowBounds 화면 밖 → 안 되면 최소화) 후 숨긴 채 프로필 읽고 닫기.
- 공지 팝업: 공지 목록을 기다리지 않음(뒤에서 받음, 그동안 버튼 누르기), data/popup_ids.json에 3일 저장.
- 로그인 서버(prime-reserve.com)에서 40초 넘게 멈추면 'F5 새로고침' 안내(창은 건드리지 않음).
- 10/15 00:31 기록: 공지 목록·장바구니 조회 모두 응답 없음 → 그 시각 사이트 응답 지연으로 판단.

## 설치 프로그램(2026-10-19, VERSION 2026.10.19)
- NSIS(리눅스에서 빌드) + uv.exe + Windows 휠(py3.11~3.13). 설치 시 uv가 CPython 3.12를 runtime/python에 받고 .venv 생성, 휠로 오프라인 설치.
- %LOCALAPPDATA%\SongdoTennis(사용자 권한), launch.cmd(최소화 콘솔) 바로가기, 제거 시 data 남길지 질문, HKCU 제거 항목.
- cloud.json: installer/embed/cloud.json(빌드 시 포함) > setup.exe 옆 > 예전 바탕화면 폴더.
- Wine에서 설치·업그레이드·실행(API 응답, 계정 옮겨옴, cloud 켜짐)·제거 확인. 한글 출력 못 하는 콘솔에서 멈추던 문제(print) 수정.
- 'start.cmd'는 cmd 내장 start와 헷갈려서 launch.cmd로.

## 설치 오류 대응(2026-10-19, 2026.10.19.4)
- 사용자 PC: 예전 버전이 켜진 채 설치 → Python 폴더가 반쯤 바뀌어 EXTERNALLY-MANAGED 쓰기 실패 → 남은 .venv 때문에 시스템 Python 대체도 실패.
- 설치·제거 전에 이 폴더에서 실행 중인 프로세스 종료(PowerShell). setup_runtime: .venv·runtime\python 지우고 새로, Python 받기 2번(설치 폴더→기본 위치), 그다음 PC Python(레지스트리 무시 재시도), 라이브러리 오프라인 실패 시 온라인.
- uv Python은 레지스트리에 등록 안 함(UV_PYTHON_INSTALL_REGISTRY=false). 휠은 py3.11~3.14.
- 관리자 PC 연결 폴더: C:\Users\Cheol-Hwan Bak\Desktop\SongdoTennis (설치 위치로 쓰면 파일 직접 갱신 가능).

## 로그인 갱신 실패 수정(2026-10-19, 2026.10.19.5)
- 원인: 화면 새로고침(1분마다)이 토큰 2분 전부터 10초짜리 숨은 Chrome 확인을 띄움 → 사이트는 만료 직전에야 새 토큰 → '만료' 오판 → error 상태라 자동 갱신도 멈춤.
- 화면 새로고침은 토큰이 살아 있으면 확인 안 함(끝났을 때만 30초 확인). Keeper는 새 토큰이 안 와도 지금 토큰이 살아 있으면 오류 아님.
- 자동 갱신 실패 시 2분 간격 3번 재시도(중간 실패는 조용히), 3번 실패해야 '로그인이 필요해요'.

## 배포 주의
- 새 버전 배포 전 app.py VERSION 올리기(같은 날 여러 번이면 2026.10.14.3처럼).
- PC로 보낼 때 같은 stagedPath를 다시 쓰면 예전 내용이 그대로 써질 수 있음 → 매번 새 폴더(/mnt/user-data/outputs/deploy_시각/...)에 복사해서 보내고, device_stage_files로 다시 받아 비교 확인.

## 2026.10.19.6
- 사이트 공지 실시간 반영: 공개 조회 `tenantAnnouncements/queries:listByTenantSlug`를 30분마다(실패 시 5분) 받아 홈 '사이트 공지'에 표시(core/notices.py). 못 받으면 마지막 저장본 → 기본 문구 순.
- 설치 파일에 대시보드 연결(cloud.json, sb_publishable 공개 키) 내장 → 설치만 하면 대시보드·원격 기록 연결.
- Supabase `keepalive()` 함수 추가(setup.sql). GitHub chbak0/Prime_SongdoTennis의 Actions가 3일마다 호출해 무료 프로젝트가 멈추지 않게 함(저장소 비밀값 SUPABASE_URL·SUPABASE_KEY 필요).
- 아직 고정값: 오픈 일정·대회 차단 규칙(공지 목록만 실시간).

## 2026.10.19.7
- GitHub 자동 업데이트: 각 PC가 켤 때와 30분마다 chbak0/Prime_SongdoTennis의 releases/latest.json을 확인 → 새 버전이면 zip을 받아 sha256·파일 이름·VERSION 확인 후 백업·적용·자동 재시작(예약 중·로그인 창이 열려 있으면 끝난 뒤). 관리자 배포(Supabase)와 함께 쓰며 더 새 버전을 고름.
- 배포 방법(개발용): `python tools/publish_github.py <저장소 폴더> "바뀐 점"` → 저장소 commit·push.
- 한계: requirements.txt에 새 패키지가 생기면 자동 업데이트만으로는 설치되지 않음(그때만 설치 파일 필요).
