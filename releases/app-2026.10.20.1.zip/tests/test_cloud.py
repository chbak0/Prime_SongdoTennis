"""관리자 대시보드(Supabase) 연동 오프라인 테스트. 실제 서버 대신 같은 함수를 흉내 낸 가짜 RPC를 쓴다."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import requests

import app as appmod
from core.cloud import Cloud, version_tuple
from core.engine import Engine
from core.journal import Journal
from test_engine import FakeServer, FakeTransport

KEY = "sb_publishable_testkey_1234567890"


class Resp:
    def __init__(self, code, value):
        self.status_code, self._v = code, value
        self.text = json.dumps(value)

    def json(self):
        return self._v


class FakeSupabase:
    """supabase/setup.sql의 app_*/admin_* 함수와 같은 규칙."""

    def __init__(self):
        self.installs, self.runs, self.issues = {}, {}, []
        self.control = {"stop_all": False, "stop_ids": [], "min_version": "", "notice": "", "notice_id": 0, "share_calendar": False}
        self.bookings = {}
        self.releases = {}
        self.admin = None
        self.down = False
        self.calls = []
        self.headers = []

    def ctrl(self, pid):
        c = self.control
        rel = max(self.releases.values(), key=lambda r: r["seq"]) if self.releases else {}
        return {"latest_version": rel.get("version"), "release_sha": rel.get("sha256"), "release_auto": rel.get("auto"),
                "release_notes": rel.get("notes"), "stop": c["stop_all"] or pid in c["stop_ids"], "stop_all": c["stop_all"], "min_version": c["min_version"],
                "notice": c["notice"], "notice_id": c["notice_id"], "share_calendar": c["share_calendar"], "server_time": "2026-10-14T00:00:00+00:00"}

    def post(self, url, json=None, timeout=None, headers=None):
        if self.down:
            raise requests.ConnectionError("down")
        self.headers.append(headers)
        fn = url.rsplit("/", 1)[-1]
        p = json or {}
        self.calls.append(fn)
        if headers.get("apikey") != KEY:
            return Resp(401, {"message": "Invalid API key"})

        def admin_check():
            if self.admin is None:
                return Resp(400, {"message": "no_admin"})
            if p.get("p_pw") != self.admin:
                return Resp(400, {"message": "denied"})
            return None

        if fn == "app_heartbeat":
            self.installs[p["p_id"]] = {"id": p["p_id"], "pc": p["p_pc"], "version": p["p_version"], "accounts": p["p_accounts"],
                                        "targets": p["p_targets"], "running": p["p_running"], "state": p["p_state"]}
            return Resp(200, self.ctrl(p["p_id"]))
        if fn == "app_report":
            if p["p_id"] not in self.installs:
                return Resp(400, {"message": "unknown_install"})
            self.runs.setdefault((p["p_id"], p["p_run_key"]), p["p_report"])
            return Resp(200, True)
        if fn == "app_issue":
            if p["p_id"] not in self.installs:
                return Resp(400, {"message": "unknown_install"})
            self.issues.append(p)
            return Resp(200, True)
        if fn == "app_bookings":
            if p["p_id"] not in self.installs:
                return Resp(400, {"message": "unknown_install"})
            self.bookings[p["p_id"]] = list(p["p_items"])
            return Resp(200, len(p["p_items"]))
        if fn == "app_shared_calendar":
            if not self.control["share_calendar"]:
                return Resp(200, None)
            items = [{**x, "mine": pid == p["p_id"], "install_id": pid} for pid, xs in self.bookings.items() for x in xs]
            return Resp(200, {"at": "2026-10-14T00:00:00+00:00", "items": items})
        if fn == "app_get_release":
            r = self.releases.get(p["p_version"])
            return Resp(200, {k: r[k] for k in ("version", "sha256", "zip_b64")} if r else None)
        if fn == "admin_publish_release":
            bad = admin_check()
            if bad:
                return bad
            import base64 as b64, hashlib as hl
            raw = b64.b64decode(p["p_zip_b64"])
            if hl.sha256(raw).hexdigest() != p["p_sha256"]:
                return Resp(400, {"message": "bad_sha"})
            self.releases[p["p_version"]] = {"version": p["p_version"], "sha256": p["p_sha256"], "zip_b64": p["p_zip_b64"],
                                             "auto": p["p_auto"], "notes": p["p_notes"], "seq": len(self.releases)}
            return Resp(200, {"version": p["p_version"], "size": len(raw)})
        if fn == "admin_issue":
            bad = admin_check()
            if bad:
                return bad
            return Resp(200, self.issues[p["p_issue"]] if p["p_issue"] < len(self.issues) else None)
        if fn == "admin_init":
            if self.admin is None:
                self.admin = p["p_pw"]
            return Resp(200, self.admin == p["p_pw"])
        if fn == "admin_dashboard":
            return admin_check() or Resp(200, {"server_time": "2026-10-14T00:00:00+00:00", "control": self.control,
                                                "installs": list(self.installs.values()),
                                                "runs": [{"install_id": k[0], "report": v} for k, v in self.runs.items()],
                                                "issues": self.issues})
        if fn == "admin_control":
            bad = admin_check()
            if bad:
                return bad
            patch = p["p_patch"]
            for k in ("stop_all", "stop_ids", "min_version", "share_calendar"):
                if k in patch:
                    self.control[k] = patch[k]
            if "notice" in patch:
                self.control["notice"] = patch["notice"]
                if patch["notice"]:
                    self.control["notice_id"] += 1
            return Resp(200, dict(self.control))
        if fn == "admin_forget_install":
            return admin_check() or Resp(200, bool(self.installs.pop(p["p_id"], None)))
        return Resp(404, {"message": "no function"})


class CloudTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        self.sb = FakeSupabase()

    def tearDown(self):
        self.tmp.cleanup()

    def cloud(self, cfg=True, version="2026.10.14"):
        path = self.data / "cloud.json"
        if cfg:
            path.write_text(json.dumps({"url": "https://abc.supabase.co", "anon_key": KEY}), encoding="utf-8")
        return Cloud(path, self.data, version, session=self.sb)

    def test_disabled_without_config(self):
        c = self.cloud(cfg=False)
        self.assertFalse(c.enabled)
        c.issue("warn", "", "x")
        self.assertEqual(c.queue, [])
        self.assertEqual(c.block_reason(), "")

    def test_publishable_key_not_sent_as_bearer(self):
        c = self.cloud()
        c.heartbeat({})
        self.assertNotIn("Authorization", self.sb.headers[-1])

    def test_install_id_is_stable(self):
        a = self.cloud().install_id
        self.assertEqual(self.cloud().install_id, a)

    def test_queue_survives_offline_and_flushes(self):
        c = self.cloud()
        self.sb.down = True
        c.report("r1", {"started": "x", "totals": {}})
        c.issue("err", "a@x.com", "오류")
        c.flush()
        self.assertEqual(len(c.queue), 2)
        c2 = self.cloud()                        # 프로그램을 다시 켜도 남아 있음
        self.assertEqual(len(c2.queue), 2)
        self.sb.down = False
        c2.heartbeat({"accounts": []})
        c2.flush()
        self.assertEqual(c2.queue, [])
        self.assertEqual(len(self.sb.runs), 1)
        self.assertEqual(self.sb.issues[0]["p_account"], "a@x.com")

    def test_controls(self):
        c = self.cloud()
        c.heartbeat({})
        self.sb.control["min_version"] = "2026.10.20"
        c.heartbeat({})
        self.assertIn("업데이트", c.block_reason())
        self.sb.control["min_version"] = "2026.10.1"
        c.heartbeat({})
        self.assertEqual(c.block_reason(), "")
        self.sb.control["stop_ids"] = [c.install_id]
        c.heartbeat({})
        self.assertIn("멈춰", c.block_reason())
        self.sb.down = True                      # 끊겨도 마지막 제어 값 유지(다시 켜도)
        self.assertIn("멈춰", self.cloud().block_reason())
        self.sb.down = False
        self.sb.control.update(stop_ids=[], notice="공지", notice_id=3)
        c.heartbeat({})
        self.assertEqual(c.take_notice(), "공지")
        self.assertEqual(c.take_notice(), "")
        self.assertEqual(self.cloud().take_notice(), "")   # 다시 켜도 한 번만

    def test_bookings_upload_only_when_changed(self):
        c = self.cloud()
        c.heartbeat({})
        items = [{"account": "a@x.com", "kind": "res", "date": "2026-10-18", "start_min": 480, "synced_at": "t1"}]
        self.assertTrue(c.sync_bookings(items))
        self.assertFalse(c.sync_bookings([{**items[0], "synced_at": "t2"}]))   # 갱신 시각만 바뀌면 안 올림
        self.assertTrue(c.sync_bookings(items + [{**items[0], "kind": "cart"}]))
        self.assertEqual(len(self.sb.bookings[c.install_id]), 2)
        c._bk_at -= 601                                                        # 10분 지나면 다시 올림
        self.assertTrue(c.sync_bookings(items + [{**items[0], "kind": "cart"}]))

    def test_shared_calendar_follows_admin_switch(self):
        c = self.cloud()
        c.heartbeat({})
        c.sync_bookings([{"account": "a@x.com", "kind": "res", "date": "2026-10-18"}])
        c.fetch_shared()
        self.assertIsNone(c.shared)
        self.sb.control["share_calendar"] = True
        c.heartbeat({})
        c.fetch_shared()
        self.assertEqual(len(c.shared["items"]), 1)
        self.assertTrue(c.shared["items"][0]["mine"])
        self.sb.down = True                       # 끊겨도 마지막 공유 내용 유지(다시 켜도)
        self.assertEqual(len(self.cloud().shared["items"]), 1)
        self.sb.down = False
        self.sb.control["share_calendar"] = False
        c.heartbeat({})
        c.fetch_shared()
        self.assertIsNone(c.shared)

    def test_version_compare(self):
        self.assertLess(version_tuple("2026.10.9"), version_tuple("2026.10.14"))
        self.assertEqual(version_tuple("2026.10.14"), version_tuple("2026.10.14"))


class AppCloudTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        (self.data / "cloud.json").write_text(json.dumps({"url": "https://abc.supabase.co", "anon_key": KEY}), encoding="utf-8")
        self.sb = FakeSupabase()
        orig = appmod.Cloud
        appmod.Cloud = lambda path, data, version: orig(path, data, version, session=self.sb)
        self.addCleanup(setattr, appmod, "Cloud", orig)
        j = Journal(self.data / "logs")
        self.eng = Engine(j, lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=self.data, engine=self.eng, start_threads=False)

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_status_uses_login_ids_only(self):
        self.app.add_account("철환")
        self.app.settings["accounts"][0]["login_id"] = "a@x.com"
        self.app.add_account("B")
        st = self.app._cloud_status()
        self.assertEqual(st["accounts"], ["a@x.com", "(로그인 전)"])
        self.assertEqual(st["state"], "대기")

    def test_bookings_from_accounts(self):
        self.app.add_account("철환")
        self.app.settings["accounts"][0]["login_id"] = "a@x.com"
        acct = self.eng.accounts["철환"]
        acct.reservations = [{"_id": "r1", "date": "2026-10-18", "startMinute": 480.0, "endMinute": 600.0, "facilityId": "f12", "status": "confirmed"},
                             {"_id": "r2", "date": "2026-10-19", "startMinute": 480.0, "endMinute": 600.0, "facilityId": "f12", "status": "cancelled"}]
        acct.synced_at = 1791900000
        out = self.app._cloud_bookings()
        self.assertEqual([(x["account"], x["kind"], x["date"], x["start_min"]) for x in out], [("a@x.com", "res", "2026-10-18", 480)])
        self.assertTrue(out[0]["synced_at"].startswith("2026-10"))
        self.app.admin_login("pw12")
        self.app.cloud.heartbeat({})
        self.app.cloud.sync_bookings(out)
        self.app.admin_control({"share_calendar": True})
        self.assertTrue(self.app.state()["shared"]["items"][0]["mine"])
        self.app.admin_control({"share_calendar": False})
        self.assertIsNone(self.app.state()["shared"])

    def test_report_and_issue_mapping(self):
        self.app.add_account("철환")
        self.app.settings["accounts"][0]["login_id"] = "a@x.com"
        rep = self.app._cloud_report({"targets": [{"account": "철환", "reject_reasons": ["x" * 200]}], "log_file": "f.jsonl"})
        self.assertEqual(rep["targets"][0]["account"], "a@x.com")
        self.assertEqual(len(rep["targets"][0]["reject_reasons"][0]), 80)
        self.assertNotIn("log_file", rep)
        self.app.journal.notify("철환", "로그인이 필요해요", "warn")
        self.app.journal.notify("시스템", "예약 시작", "ok")     # 정보성 알림은 올리지 않음
        issues = [q for q in self.app.cloud.queue if q["kind"] == "issue"]
        self.assertEqual([(q["account"], q["msg"]) for q in issues], [("a@x.com", "로그인이 필요해요")])

    def test_engine_report_hook_enqueues(self):
        self.app.engine._save_report()
        self.assertEqual([q["kind"] for q in self.app.cloud.queue], ["report"])

    def test_block_prevents_start_and_stops_running(self):
        self.app.cloud.heartbeat({})
        self.sb.control["stop_all"] = True
        self.app.cloud.heartbeat({})
        with self.assertRaisesRegex(ValueError, "멈춰"):
            self.app.start()
        self.app.engine.running = True
        stopped = []
        self.app.engine.stop = lambda: stopped.append(1)
        self.app._cloud_control(self.app.cloud.control)
        self.assertEqual(stopped, [1])

    def test_notice_becomes_notification_once(self):
        self.sb.control.update(notice="토요일 오픈 변경", notice_id=1)
        self.app.cloud.heartbeat({})
        self.app._cloud_control(self.app.cloud.control)
        self.app._cloud_control(self.app.cloud.control)
        notes = [n for n in self.app.journal.notes if n["msg"] == "토요일 오픈 변경"]
        self.assertEqual(len(notes), 1)

    def test_admin_dashboard_flow(self):
        with self.assertRaises(ValueError):
            self.app.admin_dashboard()
        self.app.admin_login("pw12")
        self.app.cloud.heartbeat({})
        d = self.app.admin_dashboard()          # 처음이면 같은 비밀번호로 등록
        self.assertEqual(self.sb.admin, "pw12")
        self.assertEqual(d["me"], self.app.cloud.install_id)
        ctrl = self.app.admin_control({"notice": " 안녕 ", "min_version": "2026.10.14"})
        self.assertEqual((ctrl["notice"], ctrl["min_version"]), ("안녕", "2026.10.14"))
        with self.assertRaises(ValueError):
            self.app.admin_control({"min_version": "v2"})
        with self.assertRaises(ValueError):
            self.app.admin_control({"stop_ids": ["nope"]})
        self.app.admin_lock()
        self.assertEqual(self.app.admin_pw, "")
        with self.assertRaises(ValueError):
            self.app.admin_control({"notice": "x"})

    def test_wrong_dashboard_password(self):
        self.sb.admin = "other"
        self.app.admin_login("pw12")
        with self.assertRaisesRegex(ValueError, "달라요"):
            self.app.admin_dashboard()

    def test_admin_password_not_persisted(self):
        self.app.admin_login("secret-pw")
        self.app.admin_dashboard()
        for f in self.data.rglob("*"):
            if f.is_file():
                self.assertNotIn(b"secret-pw", f.read_bytes(), f.name)


if __name__ == "__main__":
    unittest.main()


class ReloadConfigTests(unittest.TestCase):
    def test_new_key_applied_without_restart(self):
        import os, tempfile, time as _t
        from core.cloud import Cloud
        with tempfile.TemporaryDirectory() as d:
            d = Path(d)
            cfg = d / "cloud.json"
            cfg.write_text('{"url": "https://x.supabase.co", "anon_key": "sb_publishable_OLDOLDOLDOLDOLDOLDOLD"}', encoding="utf-8")
            c = Cloud(cfg, d, "1")
            self.assertTrue(c.enabled)
            self.assertFalse(c.reload_config())
            c.last_error = "Invalid API key"
            cfg.write_text('﻿{"url": "https://x.supabase.co/ ", "anon_key": " sb_publishable_NEWNEWNEWNEWNEWNEWNEW "}', encoding="utf-8")
            os.utime(cfg, (_t.time() + 5, _t.time() + 5))
            self.assertTrue(c.reload_config())
            self.assertEqual(c.key, "sb_publishable_NEWNEWNEWNEWNEWNEWNEW")
            self.assertEqual(c.url, "https://x.supabase.co")
            self.assertEqual(c.last_error, "")
            cfg.unlink()
            self.assertTrue(c.reload_config())
            self.assertFalse(c.enabled)
