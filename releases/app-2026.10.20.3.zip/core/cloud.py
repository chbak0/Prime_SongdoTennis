"""관리자 대시보드용 Supabase 연동.

- 각 PC는 1분마다 '하트비트'(PC 이름·버전·계정 아이디·목표 수·실행 여부)를 올리고, 관리자 제어 값(긴급 정지·최소 버전·공지)을 받는다.
- 실행 요약 리포트와 주의·오류 알림을 올린다. 인터넷이 끊겨 있으면 data/cloud_queue.json에 모아 두었다가 나중에 보낸다.
- 토큰·비밀번호·전화번호는 올리지 않는다. 계정은 사이트 아이디(이메일)로만 구분한다.
- cloud.json(Supabase 주소·공개 키)이 없으면 아무것도 하지 않는다(프로그램은 그대로 동작).
- 공개 키(anon key)로는 표를 직접 읽을 수 없고, 정해진 함수(app_*, admin_*)만 부를 수 있다(supabase/setup.sql).
"""
from __future__ import annotations

import json
import platform
import threading
import time
import uuid
from pathlib import Path

import requests

HEARTBEAT_SECONDS = 60
QUEUE_MAX = 300


class CloudError(Exception):
    def __init__(self, msg: str = "", status: int = 0):
        super().__init__(msg)
        self.status = status


def version_tuple(v: str) -> tuple:
    out = []
    for part in str(v or "").replace("-", ".").split("."):
        out.append(int(part) if part.isdigit() else 0)
    return tuple(out)


class Cloud:
    def __init__(self, config_path: Path, data: Path, version: str, session: requests.Session | None = None):
        self.version = version
        self.data = data
        self.lock = threading.Lock()
        self.http = session or requests.Session()
        self.config_path = config_path
        self._cfg_mtime = None
        self.url = self.key = ""
        self.enabled = False
        self.reload_config()
        self.state_path = data / "cloud_state.json"
        self.queue_path = data / "cloud_queue.json"
        st = self._read(self.state_path, {})
        self.install_id = st.get("install_id") or str(uuid.uuid4())
        self.control: dict = st.get("control") or {}          # 마지막으로 받은 제어 값(인터넷이 끊겨도 유지)
        self.notice_seen = int(st.get("notice_seen") or 0)
        self.shared = st.get("shared")                         # 관리자가 배포한 모임 일정(꺼지면 None)
        self._bk_key, self._bk_at = "", 0.0
        self.queue: list = self._read(self.queue_path, [])
        self.last_ok = 0.0
        self.last_error = ""
        self.pc = (platform.node() or "PC")[:60]
        self.os = f"{platform.system()} {platform.release()}"[:40]
        self._save_state()

    # ---------------------------------------------------------------- 파일
    @staticmethod
    def _read(path: Path, default):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return default

    def _write(self, path: Path, value):
        try:
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
            tmp.replace(path)
        except OSError:
            pass

    def _save_state(self):
        self._write(self.state_path, {"install_id": self.install_id, "control": self.control, "notice_seen": self.notice_seen,
                                      "shared": self.shared})

    # ---------------------------------------------------------------- 통신
    def rpc(self, fn: str, params: dict, timeout: float = 8):
        if not self.enabled:
            raise CloudError("대시보드 서버(cloud.json)가 설정되지 않았어요")
        try:
            headers = {"apikey": self.key, "Content-Type": "application/json"}
            if self.key.startswith("eyJ"):          # 예전 형식(JWT) anon 키만 Authorization에도 넣는다. 새 sb_publishable_ 키는 apikey만
                headers["Authorization"] = f"Bearer {self.key}"
            r = self.http.post(f"{self.url}/rest/v1/rpc/{fn}", json=params, timeout=timeout, headers=headers)
        except requests.RequestException as exc:
            raise CloudError(f"연결 실패({type(exc).__name__})") from None
        if r.status_code >= 400:
            try:
                msg = r.json().get("message") or r.text[:120]
            except ValueError:
                msg = r.text[:120]
            raise CloudError(str(msg), r.status_code)
        try:
            return r.json()
        except ValueError:
            return None

    # ---------------------------------------------------------------- 올릴 것 모으기
    def enqueue(self, kind: str, payload: dict):
        if not self.enabled:
            return
        with self.lock:
            self.queue.append({"kind": kind, **payload})
            self.queue = self.queue[-QUEUE_MAX:]
            self._write(self.queue_path, self.queue)

    def report(self, run_key: str, rep: dict):
        self.enqueue("report", {"run_key": run_key, "report": rep})

    def issue(self, level: str, account: str, msg: str, context: list | None = None):
        self.enqueue("issue", {"level": level, "account": account, "msg": msg, "context": context,
                               "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")})

    def flush(self):
        """모아 둔 기록을 순서대로 보낸다. 연결이 안 되면 다음 하트비트 때 다시."""
        while True:
            with self.lock:
                if not self.queue:
                    return
                item = self.queue[0]
            try:
                if item["kind"] == "report":
                    self.rpc("app_report", {"p_id": self.install_id, "p_run_key": item["run_key"], "p_report": item["report"]}, 15)
                elif item["kind"] == "issue":
                    self.rpc("app_issue", {"p_id": self.install_id, "p_level": item["level"], "p_account": item["account"],
                                           "p_msg": item["msg"], "p_at": item.get("at"), "p_context": item.get("context")})
            except CloudError as exc:
                # 서버가 내용 때문에 거절한 경우(400, 함수가 낸 bad_* 등)만 버리고,
                # 연결 실패·키 오류(401)·함수 없음(404)·서버 오류는 남겨 두었다가 다음에 다시 보낸다
                if exc.status != 400 or "unknown_install" in str(exc):
                    return
            with self.lock:
                if self.queue and self.queue[0] is item:
                    self.queue.pop(0)
                self._write(self.queue_path, self.queue)

    # ---------------------------------------------------------------- 하트비트·제어
    def heartbeat(self, status: dict) -> dict:
        ctrl = self.rpc("app_heartbeat", {"p_id": self.install_id, "p_pc": self.pc, "p_version": self.version, "p_os": self.os,
                                          "p_accounts": status.get("accounts", [])[:20], "p_targets": status.get("targets", 0),
                                          "p_running": bool(status.get("running")), "p_state": status.get("state", ""),
                                          "p_clock_ms": status.get("clock_ms")})
        if isinstance(ctrl, dict):
            self.control = ctrl
            self.last_ok = time.time()
            self.last_error = ""
            self._save_state()
        return self.control

    def block_reason(self) -> str:
        c = self.control or {}
        if c.get("stop"):
            return "관리자가 예약 실행을 잠시 멈춰 두었어요"
        mv = c.get("min_version") or ""
        if mv and version_tuple(self.version) < version_tuple(mv):
            return f"새 버전({mv})으로 업데이트한 뒤 사용해 주세요"
        return ""

    def take_notice(self) -> str:
        """아직 보여주지 않은 관리자 공지가 있으면 돌려준다(한 번만)."""
        c = self.control or {}
        nid = int(c.get("notice_id") or 0)
        if c.get("notice") and nid > self.notice_seen:
            self.notice_seen = nid
            self._save_state()
            return str(c["notice"])
        return ""

    # ---------------------------------------------------------------- 모임 일정(예약·장바구니 공유)
    BOOKINGS_REFRESH = 600

    def sync_bookings(self, items: list):
        """이 PC 계정들의 예약·장바구니를 올린다. 내용이 바뀌었거나 10분이 지났을 때만."""
        key = json.dumps([{k: v for k, v in x.items() if k != "synced_at"} for x in items], sort_keys=True, ensure_ascii=False)
        if key == self._bk_key and time.time() - self._bk_at < self.BOOKINGS_REFRESH:
            return False
        self.rpc("app_bookings", {"p_id": self.install_id, "p_items": items[:300]}, 15)
        self._bk_key, self._bk_at = key, time.time()
        return True

    def fetch_shared(self):
        """관리자가 홈 달력 배포를 켜 두었으면 모임 일정을 받아 둔다(끊기면 마지막 것을 유지)."""
        if not (self.control or {}).get("share_calendar"):
            if self.shared is not None:
                self.shared = None
                self._save_state()
            return
        got = self.rpc("app_shared_calendar", {"p_id": self.install_id}, 15)
        self.shared = got if isinstance(got, dict) else None
        self._save_state()

    def reload_config(self) -> bool:
        """cloud.json을 (바뀌었으면) 다시 읽는다. 프로그램을 다시 켜지 않아도 새 주소·키가 적용되게."""
        try:
            mt = self.config_path.stat().st_mtime
        except OSError:
            mt = None
        if mt == self._cfg_mtime:
            return False
        self._cfg_mtime = mt
        url = key = ""
        try:
            cfg = json.loads(self.config_path.read_text(encoding="utf-8-sig"))
            url = str(cfg.get("url", "")).strip().rstrip("/")
            key = str(cfg.get("anon_key", "")).strip()
        except (OSError, ValueError, AttributeError):
            pass
        self.url, self.key = url, key
        self.enabled = (url.startswith("https://") and len(key) > 20) or url.startswith("http://127.0.0.1")
        self.last_error = ""
        return True

    def run_forever(self, get_status, on_control, stop_event: threading.Event | None = None, get_bookings=None):
        stop_event = stop_event or threading.Event()
        wait = 3.0
        while not stop_event.wait(wait):
            wait = HEARTBEAT_SECONDS
            self.reload_config()
            if not self.enabled:
                continue
            try:
                self.heartbeat(get_status())
                on_control(self.control)
                self.flush()
                if get_bookings:
                    self.sync_bookings(get_bookings())
                self.fetch_shared()
            except CloudError as exc:
                self.last_error = str(exc)[:120]
            except Exception as exc:      # 대시보드 문제로 프로그램이 멈추면 안 됨
                self.last_error = type(exc).__name__

    def start(self, get_status, on_control, get_bookings=None) -> threading.Event | None:
        """cloud.json이 없어도 돌린다(나중에 넣으면 다음 확인 때부터 연결)."""
        ev = threading.Event()
        threading.Thread(target=self.run_forever, args=(get_status, on_control, ev, get_bookings), daemon=True, name="cloud").start()
        return ev

    def info(self) -> dict:
        return {"enabled": self.enabled, "install_id": self.install_id, "pc": self.pc, "version": self.version,
                "last_ok": self.last_ok, "error": self.last_error, "queued": len(self.queue), "block": self.block_reason()}
