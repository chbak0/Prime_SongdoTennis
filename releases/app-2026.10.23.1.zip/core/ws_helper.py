"""실시간(WebSocket) 칸 구독 도우미 — 별도 프로세스로 실행.

본 프로그램 안에서 convex 클라이언트의 비동기 구독(anext)을 쓰면 첫 결과만 오고 그 뒤 변화가 오지 않았다
(10/20·10/23 오픈 기록: ws_first 뒤 실시간 변화 0건). 그래서 공식 클라이언트의 '동기' 방식으로,
본 프로그램과 떨어진 프로세스에서 구독을 돌리고 결과를 한 줄씩 JSON으로 내보낸다.
이 프로세스가 멈추거나 죽어도 본 프로그램(조회·담기)은 영향을 받지 않는다.

  python -I ws_helper.py <backend_url> '<[{"id": "...", "path": "...", "args": {...}}, ...]>'
출력(한 줄에 하나): {"id": ..., "value": ...} / {"id": ..., "error": "..."} / {"ready": n}
읽기 전용 조회 구독만 한다(담기·빼기 같은 변경은 하지 않음).
"""
from __future__ import annotations

import json
import sys
import threading

_lock = threading.Lock()


def emit(obj) -> None:
    line = json.dumps(obj, ensure_ascii=False, default=str)
    with _lock:
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except (OSError, ValueError):
            raise SystemExit(0)                  # 본 프로그램이 닫음 → 끝


def watch(client, sid: str, path: str, args: dict) -> None:
    last = None
    try:
        sub = client.subscribe(path, args)
        for value in sub:                        # 동기 반복: 값이 바뀔 때마다 하나씩
            text = json.dumps(value, sort_keys=True, default=str)
            if text != last:
                last = text
                emit({"id": sid, "value": value})
    except SystemExit:
        raise
    except Exception as exc:                     # noqa: BLE001
        emit({"id": sid, "error": f"{type(exc).__name__}: {str(exc)[:120]}"})


def main(argv: list[str]) -> int:
    url, subs = argv[1], json.loads(argv[2])
    from convex import ConvexClient
    client = ConvexClient(url)
    threads = []
    for s in subs:
        t = threading.Thread(target=watch, args=(client, str(s["id"]), s["path"], s.get("args") or {}), daemon=True)
        t.start()
        threads.append(t)
    emit({"ready": len(threads)})
    for t in threads:
        t.join()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
