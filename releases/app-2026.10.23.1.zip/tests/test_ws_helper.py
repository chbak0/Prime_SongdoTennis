"""실시간 도우미(별도 프로세스) 테스트.
1) ws_helper.watch: 값이 바뀔 때만 한 줄씩 내보냄, 오류는 error 줄로
2) 엔진 연동: 가짜 도우미 프로세스가 '칸 생김'을 밀어주면 조회(HTTP)를 기다리지 않고 바로 담는다."""
import io
import json
import sys
import tempfile
import textwrap
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core import ws_helper
from core.engine import FALLBACK_FACILITIES, Engine, Target, DONE
from core.journal import Journal
from core.rules import KST
from test_engine import FakeServer, FakeTransport, jwt


class WatchTests(unittest.TestCase):
    def test_emits_only_changes_and_errors(self):
        class Client:
            def subscribe(self, path, args):
                def gen():
                    yield [1]
                    yield [1]
                    yield [1, 2]
                    raise RuntimeError("끊김")
                return gen()
        out = io.StringIO()
        old = sys.stdout
        sys.stdout = out
        try:
            ws_helper.watch(Client(), "0", "p", {})
        finally:
            sys.stdout = old
        lines = [json.loads(x) for x in out.getvalue().splitlines()]
        self.assertEqual(lines[0], {"id": "0", "value": [1]})
        self.assertEqual(lines[1], {"id": "0", "value": [1, 2]})
        self.assertIn("RuntimeError", lines[2]["error"])


FAKE_HELPER = textwrap.dedent('''
    import json, sys, time
    subs = json.loads(sys.argv[2])
    rows_file = sys.argv[3] if len(sys.argv) > 3 else ""
    print(json.dumps({"ready": len(subs)}), flush=True)
    for s in subs:
        print(json.dumps({"id": s["id"], "value": []}), flush=True)        # 처음엔 칸 없음
    time.sleep(float(open(sys.argv[0] + ".delay").read()))
    rows = json.load(open(sys.argv[0] + ".rows"))
    for s in subs:
        key = s["args"]["facilityId"] + "|" + s["args"]["date"]
        print(json.dumps({"id": s["id"], "value": rows.get(key, [])}), flush=True)   # 칸 생김 → 바로 밀어줌
    time.sleep(60)
''')


class EngineHelperTests(unittest.TestCase):
    def test_push_from_helper_triggers_add_without_polling(self):
        tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        d = (datetime.now(KST) + timedelta(days=12)).date().isoformat()
        server = FakeServer()
        fac = FALLBACK_FACILITIES[12]
        server.make_slots(fac, d, open_=True)
        rows = {fac + "|" + d: server.slots[(fac, d)]}
        script = Path(tmp.name) / "helper.py"
        script.write_text(FAKE_HELPER)
        Path(str(script) + ".rows").write_text(json.dumps(rows))
        Path(str(script) + ".delay").write_text("6.0")
        # 조회(HTTP)는 아주 느리게: 실시간으로만 알아챌 수 있게
        timing = {"prepare_minutes": 0.05, "pre_seconds": 2, "rush_seconds": 8, "after_minutes": 0, "rush_poll": 30.0,
                  "verify_seconds": 1.5, "now_delay": 0.3, "http_rps": 4.0, "reject_cooldown": 0.3, "ws_lead_seconds": 4,
                  "burst_from": 999, "burst_to": 999}
        journal = Journal(Path(tmp.name) / "logs")

        class Slow(FakeTransport):
            async def query(self, path, args, timeout=4.0, urgent=False, skip_gate=False):
                if path.startswith("slots/"):
                    import asyncio
                    await asyncio.sleep(20)
                return await super().query(path, args, timeout)
        eng = Engine(journal, lambda tok: Slow(server, tok), timing=timing)
        eng.ws_helper, eng.ws_helper_script = True, str(script)
        eng.facilities = dict(FALLBACK_FACILITIES)
        eng.link_token("A", jwt("ua"))
        eng.arm([Target(account="A", date=d, court=12, start=600)], test_at=datetime.now(KST) + timedelta(seconds=6))
        end = time.time() + 20
        while time.time() < end and not any(st.status == DONE for st in eng.states.values()):
            time.sleep(0.1)
        try:
            self.assertTrue(any(st.status == DONE for st in eng.states.values()), [st.message for st in eng.states.values()])
            self.assertEqual(eng.stats["ws"]["mode"], "helper")
            self.assertGreaterEqual(eng.stats["ws"]["updates"], 1)
        finally:
            eng.stop(); journal.close(); tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
