"""통신 계층. 감시는 WebSocket 구독(공식 convex 패키지), 조회 폴백은 HTTP.

- 모든 호출은 rules.check_allowed()를 통과해야 한다(예약 생성·확정·취소·전체 비우기 차단).
- 토큰은 이 객체의 메모리에만 있고 로그·예외 메시지에 넣지 않는다.
- 담기/빼기는 한 번만 보낸다. 응답이 끊기면 다시 보내지 않고 장바구니 조회로 결과를 확인한다.
"""
from __future__ import annotations

import asyncio
from concurrent.futures import ThreadPoolExecutor
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
import threading
import time
from typing import Any, AsyncIterator

import requests

from .rules import check_allowed

BACKEND = "https://backend.prime-reserve.com"


class Rejected(Exception):
    """서버가 요청을 명확히 거절(애플리케이션 오류)."""


class Unknown(Exception):
    """결과를 알 수 없음(시간 초과·연결 끊김). inflight: 아직 끝나지 않았을 수 있는 요청(concurrent Future)."""

    def __init__(self, msg: str = "", inflight=None):
        super().__init__(msg)
        self.inflight = inflight


# 담기·빼기 전용(조회와 스레드를 나눠, 멈춘 요청이 조회를 막지 않게 한다)
MUTATION_POOL = ThreadPoolExecutor(max_workers=6, thread_name_prefix="mutation")


class AuthExpired(Exception):
    pass


class RateLimited(Exception):
    def __init__(self, wait: float):
        super().__init__(f"요청 제한 · {wait:.1f}초 대기")
        self.wait = wait


def _retry_after(value: str | None) -> float:
    try:
        return max(1.0, float(value))
    except (TypeError, ValueError):
        try:
            return max(1.0, (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds())
        except (TypeError, ValueError, OverflowError):
            return 3.0


class RateGate:
    """프로세스 전체 HTTP 요청 상한(초당 rps)과 429 대기. WebSocket 구독에는 적용하지 않는다."""

    def __init__(self, rps: float = 4.0):
        self.lock = threading.Lock()
        self.set_rps(rps)
        self.next_at = 0.0
        self.blocked_until = 0.0

    def set_rps(self, rps: float):
        self.gap = 1.0 / max(0.5, min(20.0, rps))

    def pause(self, seconds: float):
        with self.lock:
            self.blocked_until = max(self.blocked_until, time.monotonic() + seconds)

    def reserve(self) -> float:
        with self.lock:
            now = time.monotonic()
            at = max(now, self.next_at, self.blocked_until)
            self.next_at = at + self.gap
            return at - now


class Transport:
    """한 계정(또는 공개용 token=None)의 연결."""

    def __init__(self, token: str | None, gate: RateGate, backend: str = BACKEND, use_ws: bool = True):
        self.backend = backend.rstrip("/")
        self.gate = gate
        self._token = token
        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        self._ws = None
        self.use_ws = use_ws
        self.ws_error = ""

    # ---- 인증 ----
    def set_token(self, token: str):
        self._token = token
        if self._ws is not None:
            try:
                self._ws.set_auth(token)
            except Exception:
                self.ws_error = "토큰 갱신 실패"

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self._token}"} if self._token else {}

    # ---- WebSocket ----
    def ws(self):
        if not self.use_ws:
            return None
        if self._ws is None:
            try:
                from convex import ConvexClient  # 공식 클라이언트(Rust 기반 WebSocket)
                client = ConvexClient(self.backend)
                if self._token:
                    client.set_auth(self._token)
                self._ws = client
            except Exception as exc:
                self.ws_error = f"WebSocket 사용 불가: {type(exc).__name__}"
                self.use_ws = False
                return None
        return self._ws

    async def subscribe(self, path: str, args: dict) -> AsyncIterator[Any]:
        check_allowed("query", path)
        client = self.ws()
        if client is None:
            raise Unknown("WebSocket 비활성")
        sub = client.subscribe(path, args)
        try:
            while True:
                try:
                    value = await sub.__anext__()
                except Exception as exc:
                    if "auth" in str(exc).lower() or "unauth" in str(exc).lower():
                        raise AuthExpired("로그인이 만료되었습니다.") from None
                    raise Unknown(f"구독 오류: {type(exc).__name__}") from None
                yield value
        finally:
            try:
                sub.unsubscribe()
            except Exception:
                pass

    # ---- HTTP ----
    def _http(self, kind: str, path: str, args: dict, timeout: float) -> Any:
        wait = self.gate.reserve()
        if wait > 0:
            time.sleep(wait)
        try:
            r = self.session.post(f"{self.backend}/api/{kind}", json={"path": path, "args": args, "format": "json"},
                                  headers=self._headers(), timeout=(min(3.0, timeout), timeout))
        except requests.RequestException:
            raise Unknown("서버 응답 없음") from None
        if r.status_code == 429:
            w = _retry_after(r.headers.get("Retry-After"))
            self.gate.pause(w)
            raise RateLimited(w)
        if r.status_code in (401, 403):
            raise AuthExpired("로그인이 만료되었거나 권한이 없습니다.")
        try:
            data = r.json()
        except ValueError:
            raise Unknown(f"해석 불가 응답 (HTTP {r.status_code})") from None
        if not isinstance(data, dict) or data.get("status") not in ("success", "error"):
            raise Unknown(f"예상과 다른 응답 (HTTP {r.status_code})")
        if data["status"] == "error":
            msg = str(data.get("errorMessage", ""))
            if "auth" in msg.lower() or "로그인" in msg:
                raise AuthExpired("로그인이 필요합니다.")
            raise Rejected(_safe_reason(msg))
        return data.get("value")

    async def query(self, path: str, args: dict, timeout: float = 4.0) -> Any:
        check_allowed("query", path)
        return await asyncio.get_running_loop().run_in_executor(None, self._http, "query", path, args, timeout)

    async def mutation(self, path: str, args: dict, timeout: float = 6.0) -> Any:
        """담기/빼기. WebSocket이 있으면 그쪽으로 한 번, 없으면 HTTP로 한 번. 재전송하지 않는다."""
        check_allowed("mutation", path)
        client = self.ws()
        if client is not None:
            cfut = MUTATION_POOL.submit(_ws_mutation, client, path, args)
        else:
            cfut = MUTATION_POOL.submit(self._http, "mutation", path, args, timeout)
        try:
            return await asyncio.wait_for(asyncio.shield(asyncio.wrap_future(cfut)), timeout)
        except asyncio.TimeoutError:
            # 요청은 아직 살아 있을 수 있다(재연결 시 클라이언트가 다시 보냄). 다시 보내지 않고 상대에게 넘긴다.
            raise Unknown("응답 시간 초과", inflight=cfut) from None

    def close(self):
        self.session.close()
        self._ws = None


def _ws_mutation(client, path, args):
    """WebSocket 클라이언트는 연결이 끊기면 스스로 재연결·재전송하며 기다린다.
    따라서 여기서 예외가 나왔다면 서버가 돌려준 오류(ConvexError 또는 Server Error) → 거절로 본다."""
    try:
        return client.mutation(path, args)
    except Exception as exc:
        msg = str(exc)
        if "auth" in msg.lower() or "로그인" in msg or "unauthenticated" in msg.lower():
            raise AuthExpired("로그인이 필요합니다.") from None
        raise Rejected(_safe_reason(msg) if type(exc).__name__ == "ConvexError" else "서버 오류로 거절됨") from None


def _safe_reason(msg: str) -> str:
    """서버 오류 문구는 화면에 보여줄 만큼만 자른다(개인정보·토큰이 섞이지 않도록 길이 제한)."""
    msg = " ".join(str(msg).split())
    for marker in ("Bearer", "eyJ"):
        if marker in msg:
            return "서버가 요청을 거절했습니다."
    return msg[:120] or "서버가 요청을 거절했습니다."
