'use strict';
/* Songdo Tennis 화면. 서버(/api/state)를 1초마다 읽어 그린다. 예약 신청·결제 버튼은 없다. */

const DOW = '일월화수목금토';
const pad = (n) => String(n).padStart(2, '0');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const hm = (m) => pad(Math.floor(m / 60)) + ':' + pad(m % 60);
const won = (n) => (n == null ? '' : n.toLocaleString('ko-KR') + '원');
const priceOf = (t) => (t === 360 || t >= 1080 ? 7500 : 5000);
const store = {
  get(k, d) { try { const v = localStorage.getItem('st.' + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem('st.' + k, JSON.stringify(v)); } catch (_) {} },
};
// 한국 시간 기준 날짜 도우미
let CLOCK_OFF = 0;   // 사이트 서버 시각 - PC 시각(ms). 서버에서 잰 값으로 화면 시계도 맞춘다
const nowMs = () => Date.now() + CLOCK_OFF;
const kst = (ms = nowMs()) => new Date(ms + 9 * 3600e3);
const keyOf = (y, m, d) => y + '-' + pad(m) + '-' + pad(d);
const todayKey = () => { const k = kst(); return keyOf(k.getUTCFullYear(), k.getUTCMonth() + 1, k.getUTCDate()); };
const dowOfKey = (k) => new Date(Date.UTC(+k.slice(0, 4), +k.slice(5, 7) - 1, +k.slice(8, 10))).getUTCDay();
const kstMs = (y, m, d, h = 0, mi = 0, s = 0) => Date.UTC(y, m - 1, d, h, mi, s) - 9 * 3600e3;
const md = (k) => (+k.slice(5, 7)) + '/' + (+k.slice(8, 10)) + ' (' + DOW[dowOfKey(k)] + ')';
const daysBetween = (a, b) => Math.round((Date.UTC(+b.slice(0, 4), +b.slice(5, 7) - 1, +b.slice(8, 10)) - Date.UTC(+a.slice(0, 4), +a.slice(5, 7) - 1, +a.slice(8, 10))) / 86400e3);

// 공휴일(대체공휴일 포함, 달력 표시용)
const HOL = {
  '2026-01-01': '신정', '2026-02-16': '설날', '2026-02-17': '설날', '2026-02-18': '설날', '2026-03-01': '삼일절', '2026-03-02': '대체공휴일',
  '2026-05-05': '어린이날', '2026-05-24': '부처님오신날', '2026-05-25': '대체공휴일', '2026-06-03': '지방선거', '2026-06-06': '현충일',
  '2026-08-15': '광복절', '2026-08-17': '대체공휴일', '2026-09-24': '추석', '2026-09-25': '추석', '2026-09-26': '추석',
  '2026-10-03': '개천절', '2026-10-05': '대체공휴일', '2026-10-09': '한글날', '2026-12-25': '성탄절',
  '2027-01-01': '신정', '2027-02-06': '설날', '2027-02-07': '설날', '2027-02-08': '설날', '2027-02-09': '대체공휴일', '2027-03-01': '삼일절',
};
// 사이트 공지: 프로그램이 30분마다 사이트에서 받아 온 것(S.notices). 못 받았을 때만 아래(2026-10-13 확인) 내용
const NOTICES_FALLBACK = [
  { badge: '고정', title: '사이트 예약일정 안내', date: '25.12.18', body: '20일 10:00 평일 오전·오후(06~18시) 오픈\n20일 20:00 평일 저녁(18~22시) 오픈\n23일 10:00 주말(토·일 06~22시) 오픈\n장바구니는 5시간 후 자동취소 · 예약 후 48시간 내 미입금 시 자동취소' },
  { badge: '고정', title: '하루 예약 건수 제한', date: '26.04.02', body: '하루에 만들 수 있는 예약은 최대 5건\n예약 날짜와 관계없이 그날 만든 건수로 세고 자정에 초기화' },
  { badge: '10월', title: '10월 대회 일정', date: '26.09.18', body: '10/17·21·24 전 코트 예약 불가\n10/23·25 5~14번 코트 예약 불가(15~17번 가능)\n새벽 06~08시는 예약 가능' },
  { badge: '안내', title: '주차장 출차 시 꼬리물기 금지', date: '26.09.26', body: '꼬리물기 출차가 카메라에 잡히면 시설관리공단에서 출입 제한·고발 조치 예정' },
];

// 대회 막힘: 날짜마다 [{courts, from, to, note, src}] (공지에서 읽은 것 + 프로그램 고정값)
const tourHit = (rs, c, t) => !!rs && rs.some((r) => r.courts.includes(c) && t < r.to && t + 120 > r.from);
const tourDay = (rs, c) => !!rs && rs.some((r) => r.courts.includes(c) && r.from <= 360 && r.to >= 1320);
const blockText = (rs) => (rs || []).map((r) => r.note).join(' · ');
const noticeList = () => (S.notices && S.notices.length ? S.notices : NOTICES_FALLBACK);
const S = {
  data: null, sig: '', route: 'home', acct: store.get('acct', null), logs: [], logAfter: 0, cartEnd: {}, tokEnd: {},
  dragging: false, modal: null, bellOpen: false, bellSeen: store.get('bellSeen2', 0), bellSeenBefore: 0,
  home: { ym: null, sel: null, delAsk: false },
  book: { ym: null, date: null, courts: [], times: [] },
  cart: { acct: 'all', csort: ['date', 1], rsort: ['date', 1], tab: 'up', asking: null, refreshed: 0 },
  set: { tab: 'run', kind: 'all', q: '', rows: [], rowsAt: 0 },
  tm: { date: null, time: null, cal: null, pw: '', err: '' },
};

/* ------------------------------------------------------------ 통신 */
async function api(path, body = {}) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': S.data ? S.data.csrf : '' }, body: JSON.stringify(body) });
  let j = {};
  try { j = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error(j.error || '요청 실패');
  return j;
}
async function act(path, body, okMsg) {
  try {
    const j = await api(path, body);
    if (okMsg) toast(okMsg);
    await poll(true);
    return j;
  } catch (e) { toast(e.message, true); return null; }
}
let toastTimer = null;
function toast(msg, err) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'toast' + (err ? ' err' : ''); t.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
}
const VOLATILE = new Set(['now', 'logs', 'log_saved', 'exp_in', 'left_s', 'synced_at', 'csrf', 'msg']);
/* 연결 상태(다크/라이트 왼쪽): 프로그램(뒤에서 실행)이 응답하면 초록, 두 번 연속 응답이 없으면 빨강 */
function renderConn() {
  const el = document.getElementById('conn'); if (!el) return;
  const down = S.fails >= 2; const running = S.data && S.data.running;
  el.className = 'conn ' + (down ? 'down' : S.data ? 'ok' : '');
  el.querySelector('span').textContent = down ? '연결 끊김' : !S.data ? '연결 확인 중' : running ? '예약 실행 중' : '실행 중';
  el.title = down ? '프로그램이 꺼졌거나 응답이 없어요. 바탕화면의 Songdo Tennis 아이콘으로 다시 실행해 주세요.'
    : '프로그램이 뒤에서 정상 실행 중이에요' + (running ? ' · 예약을 걸어 두어서 이 화면을 닫아도 계속 실행돼요' : ' · 이 화면을 닫으면 꺼져요');
}
async function poll(force) {
  if (S.polling) return;
  S.polling = true;
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 4000);
  try {
    const r = await fetch('/api/state?log_after=' + S.logAfter, { cache: 'no-store', signal: ctl.signal });
    if (!r.ok) throw new Error('state ' + r.status);
    const d = await r.json();
    if (d.logs && d.logs.length) {
      S.logs = S.logs.concat(d.logs).slice(-300);
      S.logAfter = S.logs[S.logs.length - 1].id;
    }
    const now = Date.now();
    (d.accounts || []).forEach((a) => {
      if (a.exp_in == null) { delete S.tokEnd[a.name]; return; }
      const end = now + a.exp_in * 1000;
      if (!S.tokEnd[a.name] || Math.abs(S.tokEnd[a.name] - end) > 5000) S.tokEnd[a.name] = end;
    });
    (d.accounts || []).forEach((a) => (a.cart || []).forEach((c) => {
      if (c.left_s == null) return;
      const end = now + c.left_s * 1000;
      if (!S.cartEnd[c.sid] || Math.abs(S.cartEnd[c.sid] - end) > 5000) S.cartEnd[c.sid] = end;
    }));
    if (S.data && S.acct && !d.accounts.some((a) => a.name === S.acct)) {
      const before = new Set(S.data.accounts.map((a) => a.name));
      const fresh = d.accounts.filter((a) => !before.has(a.name));
      if (fresh.length === 1) { S.acct = fresh[0].name; store.set('acct', S.acct); }
    }
    S.data = d;
    S.fails = 0;
    CLOCK_OFF = d.clock_offset_ms || 0;
    if (S.version && d.version && S.version !== d.version) { location.reload(); return; }
    S.version = d.version;
    if (d.weather_at && d.weather_at !== S.weatherAt) { S.weatherAt = d.weather_at; loadWeather(); }
    if (d.notices_at && d.notices_at !== S.noticesAt) { S.noticesAt = d.notices_at; loadNotices(); }
    const sig = JSON.stringify(d, (k, v) => (VOLATILE.has(k) ? undefined : v));
    if (force || sig !== S.sig) { S.sig = sig; render(); }
    else { updateLive(); }
  } catch (_) { S.fails = (S.fails || 0) + 1; /* 서버가 꺼졌을 수 있음 */ }
  finally { clearTimeout(tm); S.polling = false; renderConn(); }
}

/* ------------------------------------------------------------ 공통 */
const accts = () => (S.data ? S.data.accounts : []);
function cur() {
  const A = accts();
  return A.find((a) => a.name === S.acct) || A[0] || null;
}
const acctOk = (a) => !!a && a.linked && !a.auth_error && a.state !== 'error';
const colorOf = (name) => (accts().find((a) => a.name === name) || {}).color || '#E4E2EE';
function chips(onFrame, withAll) {
  const A = accts();
  const c = cur();
  let h = '<div class="chips' + (onFrame ? ' on-frame' : '') + '" role="group" aria-label="계정 선택">';
  if (withAll) h += '<button type="button" class="chip" data-act="cartAcct" data-v="all" aria-pressed="' + (S.cart.acct === 'all') + '">전체</button>';
  A.forEach((a) => {
    const on = withAll ? S.cart.acct === a.name : c && c.name === a.name;
    h += '<button type="button" class="chip" data-act="' + (withAll ? 'cartAcct' : 'pickAcct') + '" data-v="' + esc(a.name) + '" aria-pressed="' + on + '">'
      + '<span class="cdot' + (acctOk(a) ? '' : ' bad') + '" style="background:' + a.color + '"></span>' + esc(a.name) + '</button>';
  });
  if (!withAll) h += onFrame ? '<button type="button" class="chip-add" data-act="addAcct" title="계정 추가" aria-label="계정 추가">+</button>'
    : '<button type="button" class="chip-add" data-act="addAcct">+ 계정 추가</button>';
  return h + '</div>';
}
/* 날씨(Open-Meteo). 서버가 30분마다 받아 둔 것을 읽는다 */
const WX = (c) => (c == null ? ['', ''] : c === 0 ? ['☀️', '맑음'] : c === 1 ? ['🌤️', '대체로 맑음'] : c === 2 ? ['⛅', '구름 조금'] : c === 3 ? ['☁️', '흐림']
  : c === 45 || c === 48 ? ['🌫️', '안개'] : c >= 51 && c <= 57 ? ['🌦️', '이슬비'] : c === 65 || c === 82 ? ['🌧️', '강한 비'] : (c >= 61 && c <= 67) || (c >= 80 && c <= 82) ? ['🌧️', '비']
  : (c >= 71 && c <= 77) || c === 85 || c === 86 ? ['🌨️', '눈'] : c >= 95 ? ['⛈️', '뇌우'] : ['', '']);
const wxDay = (key) => (S.weather && S.weather.days ? S.weather.days[key] : null);
const wxHour = (key, min) => (S.weather && S.weather.hours && min != null ? S.weather.hours[key + 'T' + pad(Math.floor(min / 60))] : null);
async function loadNotices() {
  try { const r = await fetch('/api/notices', { cache: 'no-store' }); const j = await r.json(); S.notices = j.items || []; render(); } catch (_) {}
}
async function loadWeather() {
  try { const r = await fetch('/api/weather', { cache: 'no-store' }); S.weather = await r.json(); S.weatherAt = S.data.weather_at; render(); } catch (_) {}
}
function wxLine() {
  const w = S.weather; const c = w && w.current;
  if (!c || c.temp == null) return '';
  const d = wxDay(todayKey()) || {}; const [ic, tx] = WX(c.code);
  const full = '송도 ' + tx + ' ' + Math.round(c.temp) + '°' + (d.tmax != null ? ' · 최고 ' + Math.round(d.tmax) + '° 최저 ' + Math.round(d.tmin) + '°' : '') + (d.pop != null ? ' · 강수확률 ' + d.pop + '%' : '') + ' · Open-Meteo ' + String(c.time || '').slice(11, 16) + ' 기준';
  return '<div class="wxl" title="' + esc(full) + '">' + ic + ' <b class="num">' + Math.round(c.temp) + '°</b>' + (d.pop != null ? ' <span class="num">' + d.pop + '%</span>' : '') + ' ' + tx + '</div>';
}
function clockHtml(label) {
  return '<div class="clock" aria-label="지금 시각"><div class="d" data-clock="date">' + (label || '') + '</div><div class="t num"><span data-clock="hm" style="font-size:inherit;opacity:1"></span><span data-clock="sec"></span></div>' + wxLine() + '</div>';
}
function nextOpen() {
  const d = S.data; const now = nowMs();
  if (d && d.test_at) { return { at: Date.parse(d.test_at), label: '테스트 · 오픈 ' + fmtClock(Date.parse(d.test_at)), test: true }; }
  const k = kst(); const y = k.getUTCFullYear(); const m = k.getUTCMonth() + 1;
  const list = [];
  [[y, m], [m === 12 ? y + 1 : y, m === 12 ? 1 : m + 1]].forEach(([yy, mm]) => (d ? d.rules.open_events : []).forEach((e) => {
    const [h, mi] = e.time.split(':').map(Number);
    list.push({ at: kstMs(yy, mm, e.day, h, mi), label: e.name.replace('평일 ', '') + ' ' + mm + '/' + e.day + ' ' + e.time });
  }));
  return list.filter((x) => x.at > now).sort((a, b) => a.at - b.at)[0] || null;
}
const fmtClock = (ms) => { const d = kst(ms); return pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()) + ':' + pad(d.getUTCSeconds()); };
function fmtLeft(sec) {
  const neg = sec < 0; sec = Math.abs(sec);
  const d = Math.floor(sec / 86400);
  return (neg ? '+' : '') + (d ? d + '일 ' : '') + pad(Math.floor((sec % 86400) / 3600)) + ':' + pad(Math.floor((sec % 3600) / 60)) + ':' + pad(sec % 60);
}
/* 페이지 상단 띠: 네 칸으로 고정 — ① 제목 ② 계정 ③ 시간·일정 ④ 버튼 (모든 화면에서 같은 위치) */
function band(o) {
  return '<section class="band" aria-label="상단">'
    + '<div class="b-title"><h1 title="' + esc(o.titleText || '') + '">' + o.title + '</h1><div class="b-sub">' + (o.sub || '') + '</div></div>'
    + '<div class="b-acct">' + (o.acct || '') + '</div>'
    + '<div class="b-info">' + (o.info || '') + '</div>'
    + '<div class="b-act">' + (o.act || '') + '</div></section>';
}
function allRes() {
  const out = [];
  accts().forEach((a) => (a.reservations || []).forEach((r) => out.push({ ...r, acct: a.name, color: a.color })));
  return out;
}
function sharedAgo() {
  const at = S.data.shared && Date.parse(S.data.shared.at);
  if (!at) return '';
  const m = Math.max(0, Math.floor((Date.now() - at) / 60000));
  return m < 1 ? '방금 갱신' : m < 60 ? m + '분 전 갱신' : Math.floor(m / 60) + '시간 전 갱신';
}
function allCart() {
  const out = [];
  accts().forEach((a) => (a.cart || []).forEach((c) => out.push({ ...c, acct: a.name, color: a.color })));
  return out;
}
const SVG = {
  prev: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
  next: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
  xls: '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>',
  ext: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  user: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>',
  flask: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3h6M10 3v6L4.5 18.5A1.6 1.6 0 0 0 5.9 21h12.2a1.6 1.6 0 0 0 1.4-2.5L14 9V3"/><path d="M7 15h10"/></svg>',
  play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7 5v14l12-7z"/></svg>',
  stop: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>',
  plus: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
};

/* ------------------------------------------------------------ 그리기 */
function render() {
  if (!S.data || S.dragging) return;
  const route = ['home', 'book', 'cart', 'settings'].includes(S.route) ? S.route : 'home';
  document.querySelectorAll('[data-nav]').forEach((a) => a.setAttribute('aria-current', a.dataset.nav === route ? 'page' : 'false'));
  const theme = store.get('theme', 'light');
  document.documentElement.dataset.theme = theme;
  document.querySelectorAll('[data-act="theme"]').forEach((b) => b.setAttribute('aria-pressed', b.dataset.v === theme));
  const c = cur();
  document.getElementById('avatar').innerHTML = c
    ? '<div class="avatar" style="background:' + c.color + '" title="' + esc(c.name) + ' 계정">' + esc(c.name.charAt(0)) + '</div>'
    : '<div class="avatar guest" title="로그인 안 됨">' + SVG.user + '</div>';
  // 입력 중이던 칸의 포커스·커서를 다시 그린 뒤에도 유지
  const ae = document.activeElement;
  const keep = ae && ae.id && ae.tagName === 'INPUT' ? { id: ae.id, s: ae.selectionStart, e: ae.selectionEnd } : null;
  const scrolls = {};
  document.querySelectorAll('[data-keep-scroll]').forEach((el) => { scrolls[el.dataset.keepScroll] = el.scrollTop; });
  document.getElementById('view').innerHTML = PAGES[route]();
  document.querySelectorAll('[data-keep-scroll]').forEach((el) => { if (scrolls[el.dataset.keepScroll] != null) el.scrollTop = scrolls[el.dataset.keepScroll]; });
  if (keep) { const el = document.getElementById(keep.id); if (el) { el.focus(); try { el.setSelectionRange(keep.s, keep.e); } catch (_) {} } }
  renderBell();
  renderTerm();
  centerTimeCols();
  updateLive();
}
function updateLive() {
  const now = nowMs(); const k = kst(now);
  document.querySelectorAll('[data-clock="date"]').forEach((el) => { el.textContent = (k.getUTCMonth() + 1) + '월 ' + k.getUTCDate() + '일 (' + DOW[k.getUTCDay()] + ')' + (el.dataset.suffix || ''); });
  document.querySelectorAll('[data-clock="hm"]').forEach((el) => { el.textContent = pad(k.getUTCHours()) + ':' + pad(k.getUTCMinutes()); });
  document.querySelectorAll('[data-clock="sec"]').forEach((el) => { el.textContent = ':' + pad(k.getUTCSeconds()); });
  const nx = nextOpen();
  document.querySelectorAll('[data-next="left"]').forEach((el) => { el.textContent = nx ? fmtLeft(Math.floor((nx.at - now) / 1000)) : '—'; });
  document.querySelectorAll('[data-cartleft]').forEach((el) => {
    const end = S.cartEnd[el.dataset.cartleft];
    if (!end) { el.textContent = '—'; return; }
    const s = Math.max(0, Math.floor((end - Date.now()) / 1000));
    el.textContent = Math.floor(s / 3600) + ':' + pad(Math.floor((s % 3600) / 60)) + ':' + pad(s % 60);
    el.style.color = s < 1800 ? 'var(--red)' : '';
  });
  document.querySelectorAll('[data-tok]').forEach((el) => {
    const end = S.tokEnd[el.dataset.tok];
    const sec = end ? Math.floor((end - Date.now()) / 1000) : null;
    const bar = document.querySelector('[data-tokbar="' + CSS.escape(el.dataset.tok) + '"]');
    if (sec == null || sec <= 0) { el.textContent = '만료 · 자동 갱신 대기'; if (bar) { bar.style.width = '0%'; } return; }
    el.textContent = Math.floor(sec / 60) + '분 ' + pad(sec % 60) + '초';
    if (bar) { bar.style.width = Math.min(100, sec / 36) + '%'; bar.style.background = sec < 600 ? '#FF8F8F' : 'var(--accent)'; }
  });
  const tl = document.querySelector('[data-term-state]');
  if (tl) tl.textContent = termState();
  const sv = document.querySelector('[data-term-saved]');
  if (sv && S.data) sv.textContent = '자세한 기록 ' + S.data.log_saved + '줄 · 파일에 저장 중';
  renderTerm(true);
}

/* ------------------------------------------------------------ 홈 */
function homePage() {
  const A = accts();
  const c = cur();
  const guest = A.length === 0;
  const tk = todayKey();
  let top;
  if (guest) {
    top = band({
      title: '먼저 계정을 연결해 주세요', titleText: '먼저 계정을 연결해 주세요', sub: '원하는 코트·시간을 장바구니에 담아 드려요',
      acct: '<ol class="steps"><li><div class="st">STEP 1</div><div class="h">계정 연결하기</div><div class="s">작은 로그인 창이 열려요</div></li>'
        + '<li><div class="st">STEP 2</div><div class="h">Google 계정 고르기</div><div class="s">팝업·로그인 버튼은 자동</div></li>'
        + '<li><div class="st">STEP 3</div><div class="h">자동으로 끝</div><div class="s">이름 받고 창이 닫혀요</div></li></ol>',
      info: clockHtml(),
      act: '<button type="button" class="btn dark lg" data-act="addAcct">계정 연결하기</button>',
    });
  } else {
    const ok = acctOk(c);
    const meet = nextMeeting();
    let first;
    if (c.state === 'checking') first = '<button type="button" class="btn" disabled>확인 중…</button>';
    else if (c.login_open || c.state === 'login') first = '<button type="button" class="btn dark" data-act="checkLogin">로그인 확인</button>';
    else if (!ok && (!c.profile || c.state === 'error' || c.linked)) first = '<button type="button" class="btn dark" data-act="openLogin">로그인 창 열기</button>';
    else if (!ok) first = '<button type="button" class="btn" data-act="checkLogin">로그인 확인</button>';
    else first = '<button type="button" class="btn ok" data-act="checkLogin">✓ 로그인 정상</button>';
    const del = S.home.delAsk
      ? '<div style="display:flex;gap:6px"><button type="button" class="btn danger" style="padding:0" data-act="delAcct">삭제</button><button type="button" class="btn" style="padding:0" data-act="delCancel">취소</button></div>'
      : '<button type="button" class="btn danger-line" data-act="delAsk">계정 삭제</button>';
    const nm = c.display_name || c.name;
    top = band({
      title: '안녕하세요, ' + esc(nm) + '님', titleText: '안녕하세요, ' + nm + '님',
      sub: (c.login_id ? esc(c.login_id) + ' · ' : '') + (ok ? '로그인 정상' : '<span class="need">로그인이 필요해요</span>')
        + '<button type="button" class="pen" data-act="rename" title="이름 바꾸기" aria-label="이름 바꾸기">✎</button>',
      acct: chips(true) + '<div style="display:flex;align-items:center;gap:8px;min-width:0;max-width:320px">'
        + (ok ? '<span class="pill ok">로그인 정상</span><span style="font-size:12px;white-space:nowrap">토큰 <b class="num" data-tok="' + esc(c.name) + '">—</b></span>'
          + '<span class="today-bar" title="로그인 토큰(1시간) 남은 시간 · 예약 중에는 자동으로 갱신돼요"><span data-tokbar="' + esc(c.name) + '"></span></span>'
          : '<span class="pill warn">로그인 필요</span>') + '</div>',
      info: clockHtml() + '<div class="vsep"></div>'
        + (meet ? '<div class="meet2"><div class="d">다음 모임 <b class="num">' + meet.dday + '</b>' + (() => { const h = wxHour(meet.date, meet.start); return h ? ' <span class="mw">' + WX(h[2])[0] + ' <span class="num">' + Math.round(h[0]) + '° · ' + (h[1] ?? 0) + '%</span></span>' : ''; })() + '</div><div class="t">' + md(meet.date) + ' <span class="num">' + hm(meet.start) + '</span></div>'
          + '<div class="c">' + meet.court + '번 코트 · ' + (S.data.rules.kind[meet.court] || '') + (meet.kind === 'cart' ? ' · 장바구니' : '') + ' · ' + esc(meet.acct) + '</div></div>'
          : '<div class="meet2"><div class="d">다음 모임</div><div class="t" style="font-size:16px">잡힌 모임이 아직 없어요</div></div>'),
      act: '<div class="side-btns">' + first + del + '</div>',
    });
  }
  // 달력
  const k = kst(); const ty = k.getUTCFullYear(); const tm = k.getUTCMonth() + 1;
  const ym = S.home.ym ?? (ty * 12 + tm - 1);
  const Y = Math.floor(ym / 12); const M = (ym % 12) + 1;
  const first = new Date(Date.UTC(Y, M - 1, 1)).getUTCDay(); const nd = new Date(Date.UTC(Y, M, 0)).getUTCDate();
  const blocks = S.data.rules.blocks;
  const res = meetItems();
  const nm = M === 12 ? 1 : M + 1;
  let cells = '';
  for (let i = 0; i < first; i++) cells += '<button type="button" class="cal-cell blank" disabled aria-hidden="true"></button>';
  for (let d = 1; d <= nd; d++) {
    const key = keyOf(Y, M, d); const dw = (first + d - 1) % 7; const hol = HOL[key];
    const mine = res.filter((r) => r.date === key);
    let cls = 'cal-cell'; let tag = '';
    if (d === 20 || d === 23) { cls += ' open'; tag = '오픈'; } else if (blocks[key]) { cls += ' blk'; tag = '대회'; }
    const nRes = mine.filter((r) => r.kind === 'res').length;
    if (nRes) tag = '● 모임' + (mine.length > 1 ? ' ' + mine.length : ''); else if (mine.length) tag = '○ 장바구니'; else if (!tag && hol) tag = hol.length > 4 ? '공휴일' : hol;
    if (key === tk) cls += ' today';
    if (S.home.sel === key) cls += ' sel';
    const col = (d === 20 || d === 23) ? '' : (hol || dw === 0 ? 'color:var(--red)' : dw === 6 ? 'color:var(--blue)' : '');
    const wd = wxDay(key); const wi = wd ? WX(wd.code) : null;
    cells += '<button type="button" class="' + cls + '" style="' + col + '" data-act="homeSel" data-v="' + key + '" aria-label="' + M + '월 ' + d + '일 ' + DOW[dw] + '요일 ' + esc(tag) + (wi ? ' ' + wi[1] : '') + '">'
      + (wi && wi[0] ? '<span class="wxi" title="' + wi[1] + ' · ' + Math.round(wd.tmax) + '/' + Math.round(wd.tmin) + '° · 강수 ' + (wd.pop ?? 0) + '%">' + wi[0] + '</span>' : '') + '<span class="n">' + d + '</span><span class="tg">' + esc(tag) + '</span></button>';
  }
  let title = '날짜를 누르면 그날 일정이 보여요'; const lines = [];
  const sel = S.home.sel;
  if (sel) {
    title = md(sel).replace(' (', '일 (').replace('/', '월 ') + (sel === tk ? ' · 오늘' : '');
    if (HOL[sel]) lines.push(['var(--red)', HOL[sel]]);
    if (blocks[sel]) blocks[sel].forEach((r) => lines.push(['#F2A65A', r.note + (r.src ? ' — 공지: ' + r.src : '')]));
    const dd = +sel.slice(8, 10);
    if (dd === 20) { lines.push(['#9DB33A', '10:00 · ' + nmOf(sel) + '월 평일 주간(06~18시) 예약 오픈']); lines.push(['#9DB33A', '20:00 · ' + nmOf(sel) + '월 평일 저녁(18~22시) 예약 오픈']); }
    if (dd === 23) lines.push(['#9DB33A', '10:00 · ' + nmOf(sel) + '월 주말(토·일) 예약 오픈']);
    res.filter((r) => r.date === sel).forEach((r) => lines.push([r.kind === 'cart' ? '#F2A65A' : 'var(--violet)',
      meetKind(r) + ' · ' + (r.start != null ? hm(r.start) + '~' + hm(r.end ?? r.start + 120) + ' · ' : '') + (r.court ? r.court + '번 코트 ' + (S.data.rules.kind[r.court] || '') : '코트 확인 중') + ' · ' + r.acct]));
    if (!lines.length) lines.push(['#C9C6DE', '특별한 일정이 없어요']);
  }
  let wxBox = '';
  if (sel && wxDay(sel)) {
    const wd = wxDay(sel); const [ic, tx] = WX(wd.code);
    const slots = [360, 480, 600, 720, 840, 960, 1080, 1200].map((m) => { const h = wxHour(sel, m); return h ? '<span class="wxh' + ((h[1] ?? 0) >= 50 ? ' wet' : '') + '"><small>' + hm(m).slice(0, 2) + '시</small>' + WX(h[2])[0] + '<b class="num">' + Math.round(h[0]) + '°</b><small class="num">' + (h[1] ?? 0) + '%</small></span>' : ''; }).join('');
    wxBox = '<div class="wxbox"><div class="wxs">' + ic + ' <b>' + tx + '</b> · <span class="num">' + Math.round(wd.tmax) + '° / ' + Math.round(wd.tmin) + '°</span> · 강수확률 <span class="num">' + (wd.pop ?? 0) + '%</span>' + (wd.rain ? ' · <span class="num">' + wd.rain + 'mm</span>' : '') + '</div>'
      + (slots ? '<div class="wxhs">' + slots + '</div>' : '') + '</div>';
  } else if (sel && S.weather && S.weather.days) {
    wxBox = '<div class="wxbox"><div class="wxs sub">날씨 예보는 16일 뒤까지만 있어요</div></div>';
  }
  const cal = '<section class="card cal" aria-label="달력"><div class="cal-head"><div></div><div class="mid">'
    + '<button type="button" class="circle-btn" data-act="homeMonth" data-v="-1" aria-label="이전 달">' + SVG.prev + '</button><div class="lbl" aria-live="polite">' + Y + '년 ' + M + '월</div>'
    + '<button type="button" class="circle-btn" data-act="homeMonth" data-v="1" aria-label="다음 달">' + SVG.next + '</button></div>'
    + '<div style="display:flex;justify-content:flex-end"><button type="button" class="btn" data-act="homeToday">오늘</button></div></div>'
    + '<div class="cal-grid"><div style="color:var(--red)">일</div><div>월</div><div>화</div><div>수</div><div>목</div><div>금</div><div style="color:var(--blue)">토</div>' + cells + '</div>'
    + '<div class="legend"><span><i style="background:var(--accent)"></i>예약 오픈일</span><span><i style="background:var(--orange-bg)"></i>대회·예약 제한</span><span><i style="border:2px solid var(--violet)"></i>오늘</span>'
    + (guest ? '' : '<span>● 모임 일정(예약) · ○ 장바구니' + (S.data.shared ? ' · 공유 ' + sharedAgo() : '') + '</span>')
    + (S.weather && S.weather.days ? '<a class="wxsrc" href="https://open-meteo.com/" target="_blank" rel="noopener">날씨: Open-Meteo</a>' : '') + '</div>'
    + '<div class="detail" aria-live="polite"><div style="font-size:15px;font-weight:700">' + esc(title) + '</div>' + wxBox + '<ul>'
    + lines.map(([c2, t]) => '<li><span class="dot" style="background:' + c2 + '"></span><span>' + esc(t) + '</span></li>').join('') + '</ul></div></section>';
  // 오픈 일정
  const tgts = S.data.targets;
  const cnt = (pred) => tgts.filter((t) => t.date.startsWith(keyOf(tm === 12 ? ty + 1 : ty, tm === 12 ? 1 : tm + 1, 1).slice(0, 7)) && pred(t)).length;
  const isWE = (t) => { const w = dowOfKey(t.date); return w === 0 || w === 6; };
  const nmm = tm === 12 ? 1 : tm + 1;
  const evs = [
    [20, '10:00', '평일 주간 06~18시', cnt((t) => !isWE(t) && t.start < 1080), '평일 주간'],
    [20, '20:00', '평일 저녁 18~22시', cnt((t) => !isWE(t) && t.start >= 1080), '평일 저녁'],
    [23, '10:00', '주말 토·일 06~22시', cnt(isWE), '주말'],
  ];
  const opens = '<section class="card" aria-label="이번 달 예약 오픈 일정"><div class="row-between"><h2 class="h2">' + tm + '월 예약 오픈 일정</h2><span class="sub">' + nmm + '월 이용분이 열려요</span></div><ol class="opens">'
    + evs.map(([d, t, name, n, short]) => {
      const key = keyOf(ty, tm, d); const dd = daysBetween(tk, key);
      return '<li><div class="when"><b>' + d + '</b><small>' + DOW[dowOfKey(key)] + '</small><div>' + t + '</div></div><div style="flex:1"><div style="font-weight:600;font-size:14px">' + name + '</div><div class="sub" style="font-size:12.5px">'
        + nmm + '월 ' + short + (guest ? ' 슬롯' : ' · 내 목표 ' + n + '개') + '</div></div><span class="dd">' + (dd > 0 ? 'D-' + dd : dd === 0 ? '오늘' : '지남') + '</span></li>';
    }).join('') + '</ol><p class="sub" style="margin:10px 0 0">한도: 하루에 만든 예약 5건(자정 초기화) · 같은 이용일 3건 · 장바구니는 5시간 후 자동취소</p></section>';
  const notices = '<section class="card" style="flex:1 1 auto" aria-label="사이트 공지"><div class="row-between"><h2 class="h2">사이트 공지</h2><span class="sub">songdotennis.co.kr 기준</span></div><ul class="notices">'
    + noticeList().map((n, i) => '<li><button type="button" data-act="notice" data-v="' + i + '" aria-haspopup="dialog"><span class="nbadge' + (n.badge === '고정' ? ' fix' : n.badge === '10월' ? ' month' : '') + '">' + esc(n.badge) + '</span><span style="flex:1">'
      + esc(n.title) + '</span><span class="sub">' + esc(n.date) + '</span><span class="sub">›</span></button></li>').join('') + '</ul></section>';
  return top + '<div class="home-grid">' + cal + '<div class="home-side">' + opens + notices + '</div></div>';
}
const nmOf = (k) => { const m = +k.slice(5, 7); return m === 12 ? 1 : m + 1; };
/* 모임 일정: 이 PC 계정의 예약·장바구니 + 관리자가 배포한 다른 PC의 예약·장바구니(계정 아이디로 표시) */
function meetItems() {
  const out = []; const seen = new Set();
  const add = (x) => { const k = x.date + '|' + x.start + '|' + x.court + '|' + x.kind; if (!x.date || seen.has(k)) return; seen.add(k); out.push(x); };
  accts().forEach((a) => {
    const who = a.login_id || a.name;
    (a.reservations || []).forEach((r) => { if (!r.cancelled) add({ date: r.date, start: r.start, end: r.end ?? (r.start != null ? r.start + 120 : null), court: r.court, kind: 'res', status: r.status, acct: who, mine: true }); });
    (a.cart || []).forEach((c) => add({ date: c.date, start: c.start, end: c.start != null ? c.start + 120 : null, court: c.court, kind: 'cart', status: '', acct: who, mine: true }));
  });
  const sh = S.data.shared;
  if (sh && sh.items) sh.items.filter((x) => !x.mine).forEach((x) => add({ date: x.date, start: x.start_min, end: x.end_min, court: x.court, kind: x.kind, status: x.status, acct: x.account, mine: false, synced: x.synced_at }));
  const sk = (x) => x.date + String(x.start ?? 0).padStart(4, '0') + String(x.court ?? 0).padStart(2, '0') + x.kind;
  return out.sort((a, b) => sk(a).localeCompare(sk(b)));
}
const meetKind = (x) => (x.kind === 'cart' ? '장바구니' : RES_STATUS[String(x.status || '').toLowerCase()] || '예약');
function nextMeeting() {
  const tk = todayKey();
  const nowMin = kst().getUTCHours() * 60 + kst().getUTCMinutes();
  const list = meetItems().filter((r) => r.start != null && (r.date > tk || (r.date === tk && r.start >= nowMin)))
    .sort((a, b) => (a.date + pad(a.start)).localeCompare(b.date + pad(b.start)));
  const x = list[0];
  if (!x) return null;
  const dd = daysBetween(tk, x.date);
  return { ...x, dday: dd === 0 ? 'D-DAY' : 'D-' + dd };
}

/* ------------------------------------------------------------ 코트 예약 */
function occupancy() {
  // (date|court|start) → {kind, acct}
  const occ = {};
  S.data.targets.forEach((t) => { occ[t.date + '|' + t.court + '|' + t.start] = { kind: 'target', acct: t.account }; });
  allCart().forEach((c) => { if (c.date && c.court && c.start != null) occ[c.date + '|' + c.court + '|' + c.start] = { kind: 'cart', acct: c.acct }; });
  allRes().filter((r) => !r.cancelled).forEach((r) => { if (r.date && r.court && r.start != null) occ[r.date + '|' + r.court + '|' + r.start] = { kind: 'res', acct: r.acct }; });
  return occ;
}
function bookPage() {
  const A = accts(); const c = cur(); const d = S.data; const R = d.rules;
  const running = d.running; const nx = nextOpen();
  const B = S.book; const tk = todayKey();
  const kNow = kst(); const TY = kNow.getUTCFullYear(); const TM = kNow.getUTCMonth() + 1;
  const minYM = TY * 12 + TM - 1;
  const ym = B.ym ?? minYM + 1;
  const Y = Math.floor(ym / 12); const M = (ym % 12) + 1;
  // 계정 블록
  let acctBlock = chips(true) + '<div style="display:flex;align-items:center;gap:8px;min-width:0;max-width:320px">';
  if (!c) acctBlock += '<span class="pill warn">계정 없음</span>';
  else if (acctOk(c)) {
    const used = Math.min(5, c.daily_used || 0);
    acctBlock += '<span class="pill ok">준비됨</span><span style="font-size:12px;white-space:nowrap">오늘 <b class="num">' + used + '/5</b></span><span class="today-bar"><span style="width:' + used * 20 + '%;background:' + (used >= 5 ? '#FF8F8F' : 'var(--accent)') + '"></span></span>';
  } else acctBlock += '<span class="pill warn">로그인 필요</span><button type="button" class="btn dark sm" style="margin-left:auto" data-act="' + (c.login_open || c.state === 'login' ? 'checkLogin' : 'openLogin') + '">' + (c.login_open || c.state === 'login' ? '로그인 확인' : '로그인 창 열기') + '</button>';
  acctBlock += '</div>';
  const info = clockHtml() + '<div class="vsep"></div><div aria-label="다음 오픈까지" style="width:196px"><div style="font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;' + (nx && nx.test ? 'color:#FFC97A;font-weight:700' : '') + '">'
    + (nx ? (nx.test ? nx.label : '다음 오픈 · ' + nx.label) : '') + '</div><div class="num" data-next="left" style="font-size:30px;font-weight:600;line-height:1.1;white-space:nowrap;' + (nx && nx.test ? 'color:#FFE2A8' : '') + '"></div></div>';
  const actBtns = '<button type="button" class="flask' + (d.test_at ? ' on' : '') + '" data-act="testOpen" title="테스트 모드(관리자)" aria-label="테스트 모드">' + SVG.flask + '</button>'
    + '<button type="button" class="run-btn' + (running ? ' on' : '') + '" data-act="run" aria-pressed="' + running + '">' + (running ? SVG.stop : SVG.play) + '<span>' + (running ? '예약 중지' : '예약 시작') + '</span></button>';
  // 날짜
  const first = new Date(Date.UTC(Y, M - 1, 1)).getUTCDay(); const nd = new Date(Date.UTC(Y, M, 0)).getUTCDate();
  let sel = B.date && B.date.slice(0, 7) === keyOf(Y, M, 1).slice(0, 7) ? B.date : null;
  const mineT = d.targets.filter((t) => c && t.account === c.name);
  const mineC = c ? (c.cart || []) : [];
  let days = '';
  for (let i = 0; i < first; i++) days += '<button type="button" class="pday blank" disabled aria-hidden="true"></button>';
  for (let dd = 1; dd <= nd; dd++) {
    const key = keyOf(Y, M, dd); const dw = (first + dd - 1) % 7; const past = key < tk; const on = sel === key;
    let tg = ''; let tcls = 'tg';
    if (R.blocks[key]) { tg = '대회'; tcls += ' tour'; }
    else if (mineC.some((x) => x.date === key)) { tg = '●'; tcls += '" style="color:' + (on ? 'var(--accent)' : '#9DB33A'); }
    else if (mineT.some((x) => x.date === key)) { tg = '●'; tcls += '" style="color:' + (on ? '#C9C6DE' : 'var(--violet)'); }
    const cls = 'pday' + (past ? ' past' : dw === 0 || HOL[key] ? ' sun' : dw === 6 ? ' sat' : '');
    days += '<button type="button" class="' + cls + '"' + (past ? ' disabled' : '') + ' data-act="bookDate" data-v="' + key + '" aria-pressed="' + on + '" title="' + esc((HOL[key] || '') + (R.blocks[key] ? ' ' + blockText(R.blocks[key]) : '')) + '"><span>' + dd + '</span><span class="' + tcls + '">' + tg + '</span></button>';
  }
  for (let i = first + nd; i < 42; i++) days += '<button type="button" class="pday blank" disabled aria-hidden="true"></button>';
  const atMin = ym <= minYM;
  // 칸 막힘
  const occ = occupancy();
  const sw = sel ? [0, 6].includes(dowOfKey(sel)) : false;
  const blk = sel ? R.blocks[sel] : null;
  const lesson = (c2, t) => !sw && R.lesson.courts.includes(c2) && t >= R.lesson.from_minute;
  const blockOf = (t, c2) => {
    if (!sel) return { off: true };
    if (tourHit(blk, c2, t)) return { off: true, why: 'tour' };
    if (lesson(c2, t)) return { off: true, why: 'lesson' };
    const o = occ[sel + '|' + c2 + '|' + t];
    if (o) return { off: true, why: o.acct === (c && c.name) ? (o.kind === 'target' ? 'mine' : 'cart') : 'other', o };
    return { off: false };
  };
  const MAX = 2; const selCs = B.courts; const selTs = B.times;
  const isLes = (x) => R.lesson.courts.includes(x);
  const wkLes = !!sel && !sw;
  const pickedL = selCs.some(isLes); const pickedO = selCs.some((x) => !isLes(x));
  let courts = '';
  R.courts.forEach((cn) => {
    const tour = !!sel && tourDay(blk, cn);
    const off = !sel || tour; const on = !off && selCs.includes(cn);
    const taken = sel ? Object.keys(occ).filter((k2) => k2.startsWith(sel + '|' + cn + '|')).length : 0;
    const mix = wkLes && ((isLes(cn) && pickedO) || (!isLes(cn) && pickedL));
    let cls = 'cell'; let sub = R.kind[cn]; let note = cn + '번 ' + R.kind[cn];
    if (!sel) { cls += ' idle'; note = '날짜를 먼저 골라 주세요'; }
    else if (tour) { cls += ' off'; sub = '대회'; note = blockText(blk); }
    else if (taken) { sub = R.kind[cn] + ' · ' + taken + '칸'; note = '이 날 ' + taken + '개 시간이 이미 잡혀 있어요'; }
    if (on) cls += ' on-c';
    else if (!off && selCs.length >= MAX) { cls += ' dim'; note = '코트는 최대 2개까지'; }
    else if (!off && mix) { cls += ' dim'; note = '평일엔 5·6번은 5·6번끼리만 같이 고를 수 있어요'; }
    courts += '<button type="button" class="' + cls + '"' + (off ? ' disabled' : '') + ' data-act="bookCourt" data-v="' + cn + '" aria-pressed="' + on + '" title="' + esc(note) + '"><b>' + cn + '</b><small>' + esc(sub) + '</small></button>';
  });
  let times = '';
  const timeOn = {};
  R.starts.forEach((t) => {
    const bl = selCs.map((cn) => blockOf(t, cn));
    const ready = !!sel && selCs.length > 0;
    const allOff = !ready || bl.every((x) => x.off); const someOff = !allOff && bl.some((x) => x.off);
    const on = selTs.includes(t) && !allOff; timeOn[t] = on;
    const one = bl.length === 1 ? bl[0] : null;
    let cls = 'cell'; let sub = won(priceOf(t)); let note = hm(t) + ' · ' + won(priceOf(t));
    if (!ready) { cls += ' idle'; note = !sel ? '날짜를 먼저 골라 주세요' : '코트를 먼저 골라 주세요'; }
    else if (allOff && bl.every((x) => x.why === 'tour')) { cls += ' off'; sub = '대회'; note = blockText(blk); }
    else if (allOff && bl.every((x) => x.why === 'lesson')) { cls += ' off'; sub = '레슨 전용'; note = '평일 16시 이후 레슨 전용'; }
    else if (allOff && one && one.why === 'cart') { cls += ' cart'; sub = one.o.kind === 'res' ? '예약됨' : '장바구니 ✓'; note = '이미 담겨 있어요'; }
    else if (allOff && one && one.why === 'mine') { cls += ' mine'; sub = '내 목표'; note = '이미 내 목표예요'; }
    else if (allOff && one && one.why === 'other') { cls += ' other'; sub = one.o.acct + (one.o.kind === 'target' ? '' : ' 장바구니'); note = one.o.acct + ' 계정이 이미 잡은 칸(같은 칸은 한 계정만)'; }
    else if (allOff) { cls += ' off'; sub = '모두 불가'; note = '고른 코트 모두 막힌 시간이에요'; }
    else if (someOff) { sub = won(priceOf(t)) + ' · 일부'; note = '고른 코트 중 일부는 막혀 있어 빼고 추가해요'; }
    const full = selTs.filter((x) => x !== t).length >= MAX && !on;
    if (on) cls += ' on-t'; else if (!allOff && full) { cls += ' dim'; note = '시간은 최대 2개까지'; }
    times += '<button type="button" class="' + cls + '"' + (allOff ? ' disabled' : '') + ' data-act="bookTime" data-v="' + t + '" aria-pressed="' + on + '" title="' + esc(note) + '"><b style="font-size:17px">' + hm(t) + '</b><small style="font-size:11.5px;opacity:.85">' + esc(sub) + '</small></button>';
  });
  // 요약
  const cP = sel ? selCs.slice().sort((a, b) => a - b) : []; const tP = selTs.filter((t) => timeOn[t]).sort((a, b) => a - b);
  let combos = 0; let skipped = 0;
  cP.forEach((cn) => tP.forEach((t) => { if (blockOf(t, cn).off) skipped++; else combos++; }));
  const held = sel && c ? (c.reservations || []).filter((r) => r.date === sel && !r.cancelled).length + (c.cart || []).filter((x) => x.date === sel).length : 0;
  const sameT = sel ? mineT.filter((t) => t.date === sel).length : 0;
  const dateRoom = Math.max(0, 3 - held - sameT);
  const room = Math.min(Math.max(0, R.max_targets - mineT.length), sel ? dateRoom : 99); const over = combos > room;
  const ready = !!c && !!sel && combos > 0 && !over && !running;
  const sd = sel ? +sel.slice(8, 10) : 0;
  const pm = M === 1 ? 12 : M - 1;
  const openOf = (t) => (sw ? pm + '/23 10:00 오픈' : t >= 1080 ? pm + '/20 20:00 오픈' : pm + '/20 10:00 오픈');
  const t1 = !sel ? '날짜를 골라 주세요' : M + '월 ' + sd + '일 (' + DOW[dowOfKey(sel)] + ') · ' + (cP.length ? cP.map((x) => x + '번').join(', ') : '코트 미선택') + ' · ' + (tP.length ? tP.map(hm).join(', ') : '시간 미선택');
  const sameDate = sel && c ? mineT.filter((t) => t.date === sel).length : 0;
  const t2 = running ? '예약 중에는 목표를 바꿀 수 없어요 · 중지 후 바꿔 주세요'
    : !c ? '먼저 계정을 연결해 주세요'
      : mineT.length >= R.max_targets ? '예약 목표가 가득 찼어요(최대 5개) · 오른쪽 목록에서 빼고 추가해 주세요'
        : sel && dateRoom === 0 ? '이 날은 같은 날 3건이 다 찼어요' + (held ? '(이미 예약·장바구니 ' + held + '건)' : '') + ' · 다른 날을 골라 주세요'
        : over ? '지금 ' + room + '개만 더 넣을 수 있어요(고른 조합 ' + combos + '개 · 같은 날 최대 3건)'
          : !sel ? '기본은 다음 달이에요 · 화살표로 이번 달도 볼 수 있어요'
            : (combos ? '목표 ' + combos + '개 추가' + (skipped ? ' (막힌 칸 ' + skipped + '개 제외)' : '') + ' · ' : '코트와 시간을 2개씩 골라도 돼요 · ')
              + (tP.length ? [...new Set(tP.map((t) => won(priceOf(t))))].join('·') + ' · ' + [...new Set(tP.map(openOf))].join(', ') + ' · ' : '') + '이 날 ' + (sameDate + held) + ' / 3건';
  const picker = '<section class="card picker" aria-label="목표 고르기"><div class="row-between"><h2 class="h2" style="font-size:18px">목표 고르기</h2><span class="sub" style="font-size:12.5px">날짜 → 코트 → 시간 순서 · 코트·시간은 최대 2개씩</span></div>'
    + '<div class="cols"><div aria-label="날짜" style="flex:1 1 0;min-width:0;display:flex;flex-direction:column;gap:8px"><div class="row-between" style="align-items:center"><div class="step">① 날짜</div><div style="display:flex;align-items:center;gap:6px">'
    + '<button type="button" class="circle-btn sm" data-act="bookMonth" data-v="-1"' + (atMin ? ' disabled' : '') + ' aria-label="이전 달">' + SVG.prev + '</button><span style="min-width:96px;text-align:center;font-size:15px;font-weight:700">' + Y + '년 ' + M + '월</span>'
    + '<button type="button" class="circle-btn sm" data-act="bookMonth" data-v="1" aria-label="다음 달">' + SVG.next + '</button></div></div>'
    + '<div class="pcal"><div style="color:var(--red)">일</div><div class="sub">월</div><div class="sub">화</div><div class="sub">수</div><div class="sub">목</div><div class="sub">금</div><div style="color:var(--blue)">토</div>' + days + '</div>'
    + '<div class="leg2"><span><i style="width:6px;height:6px;border-radius:50%;background:var(--violet)"></i>내 목표</span><span><i style="width:6px;height:6px;border-radius:50%;background:#9DB33A"></i>장바구니</span><span><b style="color:#B4610E">대회</b>예약 제한 공지 있음</span></div></div>'
    + '<div style="flex:1 1 0;min-width:0;display:flex;flex-direction:column;gap:14px"><div aria-label="코트" style="display:flex;flex-direction:column;gap:8px">'
    + '<div class="row-between"><div class="step">② 코트 <span>· 최대 2개 ' + selCs.length + ' / 2</span></div><div class="sub" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'
    + (sel ? M + '/' + sd + ' (' + DOW[dowOfKey(sel)] + ') · ' + (blk ? blockText(blk) : sw ? '주말' : '평일') : '날짜를 먼저 골라 주세요') + '</div></div><div class="grid-courts">' + courts + '</div>'
    + '<div aria-label="시간" style="display:flex;flex-direction:column;gap:8px"><div class="row-between"><div class="step">③ 시간 <span>· 최대 2개 ' + selTs.length + ' / 2</span></div><div class="sub">고른 코트 기준으로 막힌 시간 표시</div></div>'
    + '<div class="grid-times">' + times + '</div><div class="leg2"><span><i style="background:#E6F7B8;border:1px solid #9DB33A"></i>장바구니</span><span><i style="background:var(--violet)"></i>내 목표</span><span><i style="background:var(--orange-bg)"></i>다른 계정</span><span><i style="background:var(--line)"></i>대회·레슨 전용·불가</span></div></div></div></div></div>'
    + '<div class="pickbar"><div style="flex:1;min-width:0"><div class="t1">' + esc(t1) + '</div><div class="t2">' + esc(t2) + '</div></div>'
    + '<button type="button" class="btn lg ' + (ready ? 'dark' : '') + '"' + (ready ? '' : ' disabled') + ' data-act="bookAdd">' + SVG.plus + esc(c ? c.name : '') + ' 목표에 ' + (ready ? combos + '개 ' : '') + '추가</button></div></section>';
  // 목표 목록
  const items = mineT.map((t, i) => '<li class="titem" data-tid="' + t.id + '" aria-label="' + (i + 1) + '순위 ' + md(t.date) + ' ' + hm(t.start) + ' ' + t.court + '번"><span class="grip" aria-hidden="true">⋮⋮</span><span class="rank">' + (i + 1) + '</span>'
    + '<div style="flex:1;min-width:0"><div class="w">' + md(t.date) + ' ' + hm(t.start) + '</div><div class="c">' + t.court + '번 · ' + R.kind[t.court] + ' · ' + won(priceOf(t.start)) + '</div></div>'
    + '<span class="pill ' + t.kind + '" title="' + esc(t.detail) + '">' + t.label + '</span><button type="button" class="xbtn" data-act="tRemove" data-v="' + t.id + '" aria-label="목표 빼기" title="목표 빼기">✕</button></li>').join('');
  const list = '<section class="card tlist" aria-label="예약 목표 목록"><div class="row-between" style="padding-right:4px"><h2 class="h2" style="font-size:16px">예약 목표 <span class="sub" style="font-size:16px;font-weight:500">' + mineT.length + ' / ' + R.max_targets + '개</span></h2><span class="sub" style="font-size:11.5px">끌어서 순서 바꾸기</span></div>'
    + '<div class="area">' + (mineT.length ? '' : '<div class="empty">대기 중인 목표가 없어요 · 최대 5개</div>') + '<ol id="tlist">' + items + '</ol></div></section>';
  const term = '<section class="term" aria-label="실행 로그"><div class="hd"><span class="live' + (running ? ' on' : '') + '"></span><span style="font-size:13px;font-weight:700">실행 로그</span><span data-term-state style="margin-left:auto;font-size:11px;color:#8E8AA8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></span></div>'
    + '<div class="body"><div class="scroll" id="term" role="log" aria-live="polite"></div></div><div class="ft"><span data-term-saved style="flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"></span><button type="button" data-act="openLogs" title="자세한 기록 폴더 열기">기록 파일 열기</button></div></section>';
  return band({ title: '코트 예약', titleText: '코트 예약', sub: '원하는 코트·시간 장바구니 담기 진행', acct: acctBlock, info, act: actBtns }) + '<div class="split">' + picker + '<div class="rightcol">' + list + term + '</div></div>';
}
function termState() {
  const d = S.data;
  if (!d) return '';
  if (!d.running) return '대기 중 · 예약 시작을 눌러 주세요';
  const ev = d.events.filter((e) => e.phase !== '종료').sort((a, b) => a.at.localeCompare(b.at))[0];
  return ev ? ev.name + ' · ' + ev.phase : '예약 중';
}
let termCount = -1;
function renderTerm(incremental) {
  const el = document.getElementById('term');
  if (!el) { termCount = -1; return; }
  if (incremental && termCount === S.logs.length) return;
  const ic = { ok: '✓', warn: '!', err: '✕', info: '·' };
  el.innerHTML = S.logs.slice(-200).reverse().map((l) => '<div class="ln"><span class="ts">' + l.time.slice(0, 5) + '</span><span class="ic lv-' + l.level + '">' + (ic[l.level] || '·') + '</span><span class="tx lv-'
    + l.level + '" title="' + esc(l.who + ' · ' + l.msg) + '">' + esc((l.who && l.who !== '시스템' ? l.who + ' · ' : '') + l.msg) + '</span></div>').join('');
  termCount = S.logs.length;
}

/* 목표 끌어서 순서 바꾸기: 잡은 항목은 손을 따라오고, 지나치는 항목은 한 칸씩 비켜 준다 */
const STEP = 56;
let drag = null;
function dragStart(e) {
  const li = e.target.closest('.titem');
  if (!li || e.target.closest('button') || (e.button !== undefined && e.button !== 0) || S.data.running) return;
  const all = [...document.querySelectorAll('#tlist .titem')];
  drag = { li, all, from: all.indexOf(li), y0: e.clientY, dy: 0, id: li.dataset.tid };
  try { li.setPointerCapture(e.pointerId); } catch (_) {}
  li.classList.add('drag'); S.dragging = true;
}
function dragMove(e) {
  if (!drag) return;
  const n = drag.all.length;
  const max = (n - 1 - drag.from) * STEP + 12; const min = -drag.from * STEP - 12;
  drag.dy = Math.max(min, Math.min(max, e.clientY - drag.y0));
  const to = Math.max(0, Math.min(n - 1, drag.from + Math.round(drag.dy / STEP)));
  drag.all.forEach((el, i) => {
    if (el === drag.li) { el.style.transform = 'translateY(' + drag.dy + 'px)'; return; }
    let ty = 0;
    if (drag.from < to && i > drag.from && i <= to) ty = -STEP;
    else if (drag.from > to && i >= to && i < drag.from) ty = STEP;
    el.style.transform = 'translateY(' + ty + 'px)';
  });
}
async function dragEnd() {
  if (!drag) return;
  const d = drag; drag = null;
  const n = d.all.length; const to = Math.max(0, Math.min(n - 1, d.from + Math.round(d.dy / STEP)));
  d.li.classList.remove('drag');
  d.li.style.transform = 'translateY(' + ((to - d.from) * STEP) + 'px)';
  setTimeout(async () => {
    S.dragging = false;
    if (to === d.from) { d.all.forEach((el) => { el.style.transform = ''; }); return; }
    const ids = d.all.map((el) => el.dataset.tid); ids.splice(d.from, 1); ids.splice(to, 0, d.id);
    await act('/api/targets/reorder', { name: cur().name, ids });
  }, 200);
}

/* ------------------------------------------------------------ 장바구니·예약 내역 */
function sortRows(rows, [key, dir], extra) {
  const f = {
    date: (x) => (x.date || '') + pad(x.start ?? 0) + pad(x.court ?? 0), court: (x) => pad(x.court ?? 0) + (x.date || '') + pad(x.start ?? 0),
    time: (x) => pad(x.start ?? 0) + (x.date || '') + pad(x.court ?? 0), acct: (x) => x.acct + (x.date || '') + pad(x.start ?? 0), ...extra,
  };
  return rows.slice().sort((a, b) => { const A2 = f[key](a); const B2 = f[key](b); return (A2 < B2 ? -1 : A2 > B2 ? 1 : 0) * dir; });
}
function sortBar(name, cur2, opts, exportKind) {
  return '<div class="sortbar" role="group" aria-label="정렬"><span style="margin-right:2px">정렬</span>' + opts.map(([k, label]) => {
    const on = cur2[0] === k;
    return '<button type="button" class="sortbtn" data-act="sort" data-which="' + name + '" data-v="' + k + '" aria-pressed="' + on + '">' + label + '<span style="font-size:10px;opacity:' + (on ? 1 : 0.35) + '">' + (on && cur2[1] < 0 ? '▼' : '▲') + '</span></button>';
  }).join('') + '<button type="button" class="btn green sm" style="margin-left:auto" data-act="exportOpen" data-v="' + exportKind + '" title="이번 달·다음 달 중 골라서 엑셀로 저장">' + SVG.xls + '엑셀 저장</button></div>';
}
const RES_STATUS = { pending: '입금 대기', unpaid: '입금 대기', awaiting_payment: '입금 대기', confirmed: '확정', paid: '결제 완료', approved: '확정', completed: '이용 완료' };
function cartPage() {
  const C = S.cart; const R = S.data.rules; const tk = todayKey();
  const pickA = (x) => C.acct === 'all' || x.acct === C.acct;
  const cart = sortRows(allCart().filter(pickA), C.csort, { left: (x) => pad(Math.floor((S.cartEnd[x.sid] || 0) / 1000), 14) });
  const total = cart.reduce((s, x) => s + (x.price || 0), 0);
  const res = allRes().filter(pickA);
  const tabs = { up: res.filter((r) => !r.cancelled && r.date >= tk), past: res.filter((r) => !r.cancelled && r.date < tk), cx: res.filter((r) => r.cancelled) };
  const hist = sortRows(tabs[C.tab], C.rsort, { status: (x) => x.status + (x.date || '') });
  const when = (x) => (x.date ? md(x.date) : '날짜 확인 중') + (x.start != null ? ' ' + hm(x.start) + '~' + hm(x.end ?? x.start + 120) : '');
  const courtTxt = (x) => (x.court ? x.court + '번 · ' + (R.kind[x.court] || '') : '코트 확인 중') + (x.price ? ' · ' + won(x.price) : '');
  const cartList = cart.map((x) => {
    const asking = C.asking === x.sid;
    return '<li class="li64"><span class="dot" style="background:' + x.color + '" title="' + esc(x.acct) + ' 계정"></span><div style="flex:1;min-width:0"><div class="w">' + when(x) + '</div><div class="c">' + courtTxt(x) + ' · ' + esc(x.acct) + '</div></div>'
      + '<div style="text-align:right"><div class="num" style="font-size:18px;font-weight:600" data-cartleft="' + x.sid + '"></div><div style="font-size:11.5px;color:var(--faint)">' + (x.exact_time ? '자동취소까지' : '자동취소까지(추정)') + '</div></div>'
      + '<div style="flex:0 0 160px;display:flex;justify-content:flex-end;gap:6px">' + (asking
        ? '<button type="button" class="btn danger" data-act="cartDo" data-v="' + x.sid + '" data-acct="' + esc(x.acct) + '">취소하기</button><button type="button" class="btn" data-act="cartNo">아니요</button>'
        : '<button type="button" class="btn danger-line" data-act="cartAsk" data-v="' + x.sid + '">취소</button>') + '</div></li>';
  }).join('');
  const histList = hist.map((r) => {
    const st = r.cancelled ? ['취소', 'gray'] : r.date < tk ? ['이용 완료', 'gray'] : [RES_STATUS[String(r.status).toLowerCase()] || r.status || '예약', String(r.status).toLowerCase().includes('pend') || String(r.status).toLowerCase().includes('unpaid') ? 'limit' : 'ok'];
    const note = r.created ? '신청 ' + md(new Date(r.created + 9 * 3600e3).toISOString().slice(0, 10)) : '';
    return '<li class="li64" style="padding:0 16px"><span class="dot" style="background:' + r.color + '" title="' + esc(r.acct) + ' 계정"></span><div style="flex:1;min-width:0"><div class="w">' + when(r) + '</div><div class="c">' + courtTxt(r) + ' · ' + esc(r.acct) + '</div></div>'
      + '<div style="text-align:right"><span class="pill ' + st[1] + '">' + esc(st[0]) + '</span><div style="font-size:11.5px;color:var(--faint);margin-top:4px;white-space:nowrap">' + note + '</div></div></li>';
  }).join('');
  const sum = '장바구니 ' + allCart().filter(pickA).length + '개 · 다가오는 예약 ' + tabs.up.length + '건';
  const acctBlock = chips(true, true) + '<div style="font-size:12px;white-space:nowrap">' + sum + '</div>';
  const siteBtn = '<a href="https://songdotennis.co.kr/songdo-tennis" target="_blank" rel="noopener" class="btn dark" style="height:52px;padding:0 22px;border-radius:26px;font-size:15px;text-decoration:none">사이트에서 신청' + SVG.ext + '</a>';
  const tabBtn = (k, l) => '<button type="button" data-act="histTab" data-v="' + k + '" aria-pressed="' + (C.tab === k) + '">' + l + ' ' + tabs[k].length + '</button>';
  return band({ title: '장바구니 · 예약', titleText: '장바구니 · 예약 내역', sub: '예약 신청과 결제는 사이트에서 직접 해 주세요', acct: acctBlock, info: clockHtml(), act: siteBtn })
    + '<div class="split"><section class="card" style="flex:1 1 0;min-width:0;min-height:0;padding:20px 22px;display:flex;flex-direction:column;gap:12px" aria-label="장바구니">'
    + '<div class="row-between" style="height:36px;align-items:center"><h2 class="h2" style="font-size:18px">장바구니 <span class="sub" style="font-size:18px;font-weight:500">' + cart.length + '개</span></h2><span class="sub" style="font-size:12.5px">담고 5시간이 지나면 자동취소 · 취소는 한 번 더 확인해요</span></div>'
    + sortBar('c', C.csort, [['date', '날짜'], ['court', '코트'], ['time', '시간'], ['left', '남은 시간'], ['acct', '계정']], 'cart')
    + (cart.length ? '' : '<div class="center-msg">장바구니가 비어 있어요</div>') + '<ul class="list" data-keep-scroll="cart">' + cartList + '</ul>'
    + '<div class="total"><span>합계</span><b>' + won(total) + '</b></div></section>'
    + '<section class="card" style="flex:1 1 0;min-width:0;min-height:0;padding:20px 22px;display:flex;flex-direction:column;gap:12px" aria-label="예약 내역">'
    + '<div class="row-between" style="height:36px;align-items:center"><h2 class="h2" style="font-size:18px">예약 내역</h2><div class="tabs" role="group" aria-label="내역 보기">' + tabBtn('up', '다가오는 예약') + tabBtn('past', '지난 이용') + tabBtn('cx', '취소') + '</div></div>'
    + sortBar('r', C.rsort, [['date', '날짜'], ['court', '코트'], ['time', '시간'], ['status', '상태'], ['acct', '계정']], 'res')
    + (hist.length ? '' : '<div class="center-msg">' + (C.tab === 'up' ? '다가오는 예약이 없어요' : C.tab === 'past' ? '지난 이용 내역이 없어요' : '취소된 예약이 없어요') + '</div>')
    + '<ul class="list" data-keep-scroll="hist">' + histList + '</ul></section></div>';
}

/* ------------------------------------------------------------ 설정 */
function settingsPage() {
  const T = S.set; const d = S.data; const tm = d.timing;
  const tab = (id, label, sub) => '<button type="button" data-act="setTab" data-v="' + id + '" aria-current="' + (T.tab === id ? 'page' : 'false') + '"><b>' + label + '</b><small>' + sub + '</small></button>';
  let body = '';
  if (T.tab === 'run') {
    const knob = (key, title, desc, unit, step) => '<div class="knob"><div style="flex:1;min-width:0"><div style="font-size:15px;font-weight:700">' + title + '</div><div class="sub" style="font-size:12.5px;margin-top:3px">' + desc + '</div></div>'
      + '<div role="group" aria-label="' + title + '" style="display:flex;align-items:center;gap:6px"><button type="button" data-act="knob" data-k="' + key + '" data-v="' + (-step) + '" aria-label="' + title + ' 줄이기">−</button>'
      + '<span class="v" aria-live="polite">' + tm[key] + '<small>' + unit + '</small></span><button type="button" data-act="knob" data-k="' + key + '" data-v="' + step + '" aria-label="' + title + ' 늘리기">+</button></div></div>';
    const base = d.test_at ? Date.parse(d.test_at) : kstMs(2026, 11, 20, 10, 0) % 86400e3 + Math.floor(Date.now() / 86400e3) * 86400e3;
    const at = (sec) => fmtClock(base + sec * 1000);
    const total = tm.prepare_minutes * 60 + tm.rush_seconds + tm.after_minutes * 60;
    const w = (s) => Math.max(1.5, (s / total) * 100);
    const C = { prep: '#C9C6DE', pre: '#FFC97A', rush: 'var(--accent)', after: 'var(--violet)' };
    let left = 0;
    const bars = [['prep', tm.prepare_minutes * 60 - tm.pre_seconds], ['pre', tm.pre_seconds], ['rush', tm.rush_seconds], ['after', tm.after_minutes * 60]]
      .map(([k, s]) => { const h = '<span style="left:' + left + '%;width:' + w(s) + '%;background:' + C[k] + '"></span>'; left += w(s); return h; }).join('');
    const stp = (c2, l, a, desc) => '<div><div style="display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700"><span class="dot" style="width:8px;height:8px;background:' + c2 + '"></span>' + l + '</div><div class="num" style="font-size:16px;font-weight:600;margin-top:2px">' + a + '</div><div class="sub" style="font-size:11.5px">' + desc + '</div></div>';
    const df = d.timing_default;
    body = '<div class="row-between"><h2 class="h2" style="font-size:20px">예약 동작</h2><span class="sub" style="font-size:12.5px">모든 계정에 똑같이 적용돼요' + (d.running ? ' · 예약 중에는 바꿀 수 없어요' : '') + '</span></div><div class="knobs">'
      + knob('pre_seconds', '오픈 전 미리 확인', '정시보다 이만큼 먼저 슬롯이 열렸는지 확인해요. 사이트 시계가 빠를 때 대비', '초 전', 1)
      + knob('rush_seconds', '오픈 후 빠르게 시도', '오픈 뒤 이 시간 동안 1초마다 확인하며 담기를 시도해요', '초', 10)
      + knob('after_minutes', '그 뒤 계속 감시', '취소로 다시 나오는 자리를 5초마다 확인해요', '분', 10)
      + knob('prepare_minutes', '미리 준비', '로그인 확인과 연결을 이만큼 먼저 해 둬요', '분 전', 1) + '</div>'
      + '<div class="planbox"><div style="font-size:14px;font-weight:700">이렇게 진행돼요 <span class="sub" style="font-size:14px;font-weight:500">· 예: ' + at(0) + ' 오픈</span></div><div class="planbar">' + bars + '</div><div class="plansteps">'
      + stp(C.prep, '준비', at(-tm.prepare_minutes * 60), '로그인·연결 확인') + stp(C.pre, '미리 확인', at(-tm.pre_seconds), tm.pre_seconds + '초 전부터 슬롯 확인')
      + stp(C.rush, '빠르게 시도', at(0) + '~', tm.rush_seconds + '초 동안 (' + at(tm.rush_seconds) + '까지)') + stp(C.after, '계속 감시', at(tm.rush_seconds) + '~', tm.after_minutes + '분 동안') + '</div></div>'
      + '<div style="display:flex;align-items:center;gap:10px;font-size:12.5px;color:var(--muted)"><button type="button" class="btn" data-act="knobReset">기본값으로</button><span>기본값: 미리 확인 ' + df.pre_seconds + '초 · 시도 ' + df.rush_seconds + '초 · 이후 감시 ' + df.after_minutes + '분 · 준비 ' + df.prepare_minutes + '분 전 · 담기는 목표당 최대 4번(다시 열리면 또 시도)</span></div>'
      + clockLine() + updateLine();
  } else if (T.tab === 'report') {
    body = reportBody();
  } else if (T.tab === 'log') {
    const LV = { info: '정보', ok: '성공', warn: '주의', err: '오류' };
    const q = T.q.toLowerCase();
    const rows = T.rows.filter((r) => (T.kind === 'all' || r.lvl === T.kind || r.cat === T.kind) && (!q || (r.ts + ' ' + r.acct + ' ' + r.cat + ' ' + r.msg).toLowerCase().includes(q)));
    const kinds = [['all', '전체'], ['err', '오류'], ['warn', '주의'], ['장바구니', '장바구니'], ['통신', '통신'], ['엔진', '엔진'], ['슬롯', '슬롯']];
    body = '<div class="row-between" style="align-items:center"><h2 class="h2" style="font-size:20px">자세한 로그 <span class="sub" style="font-size:14px;font-weight:500">' + rows.length + '줄</span></h2><div style="display:flex;align-items:center;gap:8px">'
      + '<label class="search"><input id="logq" type="search" value="' + esc(T.q) + '" placeholder="찾기 (예: 15번, 오류)" aria-label="로그에서 찾기" data-input="logq"></label>'
      + '<select id="logfile" class="search" style="height:32px" aria-label="기록 파일" data-change="logFile">' + (T.files || []).map((f) => '<option value="' + esc(f.name) + '"' + ((T.file || '') === (f.current ? '' : f.name) ? ' selected' : '') + '>' + esc(fileLabel(f.name)) + (f.current ? ' (지금)' : '') + '</option>').join('') + '</select>'
      + '<button type="button" class="btn sm" data-act="logsReload">새로고침</button><a class="btn green sm" style="height:32px;text-decoration:none" href="/api/logs.csv?kind=' + encodeURIComponent(T.kind) + '&q=' + encodeURIComponent(T.q) + (T.file ? '&file=' + encodeURIComponent(T.file) : '') + '">' + SVG.xls + '엑셀 저장</a></div></div>'
      + '<div role="group" aria-label="로그 종류" style="display:flex;flex-wrap:wrap;gap:6px">' + kinds.map(([k, l]) => '<button type="button" class="sortbtn" data-act="logKind" data-v="' + k + '" aria-pressed="' + (T.kind === k) + '">' + l + '</button>').join('') + '</div>'
      + '<div class="logtable"><div class="hd"><span>시각</span><span>종류</span><span>계정</span><span>분류</span><span>내용</span></div><div style="flex:1 1 0;min-height:0;overflow-y:auto" data-keep-scroll="logs">'
      + rows.slice().reverse().slice(0, 1500).map((r) => '<div class="r"><span class="mono" style="color:var(--muted)">' + r.ts + '</span><span class="lvl ' + r.lvl + '">' + LV[r.lvl] + '</span><span>' + esc(r.acct) + '</span><span class="sub" style="font-size:12.5px">' + esc(r.cat) + '</span><span class="mono" style="word-break:break-all">' + esc(r.msg) + '</span></div>').join('')
      + (rows.length ? '' : '<div style="padding:30px;text-align:center;color:var(--faint);font-size:13px">조건에 맞는 로그가 없어요</div>') + '</div></div>'
      + '<div style="font-size:12px;color:var(--faint)">프로그램을 켤 때마다 data/logs 폴더에 파일(' + esc(d.log_file) + ')로 저장돼요 · 토큰과 비밀번호는 기록하지 않아요 · <button type="button" class="btn sm" data-act="openLogs">폴더 열기</button></div>';
  } else {
    body = adminBody();
  }
  const tag = d.test_at ? '<div class="testtag"><span class="dot" style="width:8px;height:8px;background:var(--red)"></span>테스트 모드 켜짐 · 가상 오픈 ' + md(d.test_at.slice(0, 10)) + ' ' + fmtClock(Date.parse(d.test_at)) + '</div>' : '';
  return band({ title: '설정', titleText: '설정', sub: '예약 동작 · 실행 기록 · 로그 · 관리자', acct: tag, info: clockHtml() })
    + '<div class="split"><nav class="card snav" aria-label="설정 항목">' + tab('run', '예약 동작', '미리 확인 · 시도 시간') + tab('report', '실행 기록', '실행 요약 리포트') + tab('log', '자세한 로그', '디버깅용 기록') + tab('admin', '관리자', '대시보드 · 원격 제어') + '</nav>'
    + '<section class="card sbody" aria-label="설정 내용">' + body + '</section></div>';
}
function updateLine() {
  const u = S.data.update || {};
  const v = S.data.version || '';
  if (!u.available) return '<div class="sub" style="font-size:12px">프로그램 버전 ' + esc(v) + ' · 새 버전이 나오면 설치 없이 자동으로 바뀌어요' + ' · 이 화면을 닫으면 프로그램도 꺼져요(예약을 걸어 두었으면 끝날 때까지 뒤에서 계속 실행)</div>';
  const st = { busy: '받는 중…', wait: '예약이 끝나면 자동으로 바꿔요', fail: '실패 · ' + (u.error || ''), done: '다시 시작하는 중…' }[u.status] || '';
  return '<div class="updline"><b>새 버전 ' + esc(u.available) + '</b><span class="sub">지금 ' + esc(v) + (u.notes ? ' · ' + esc(u.notes) : '') + (st ? ' · ' + esc(st) : '') + '</span>'
    + '<button type="button" class="btn dark sm" style="margin-left:auto" data-act="updateNow"' + (d_running() || u.status === 'busy' ? ' disabled' : '') + '>지금 업데이트</button></div>';
}
const d_running = () => !!(S.data && S.data.running);
function clockLine() {
  const c = S.data.clock;
  if (!c) return '<div class="clockline"><b>사이트 시계</b><span>아직 확인 전이에요 · 켤 때와 오픈 준비 때 자동으로 확인해요</span></div>';
  const a = Math.abs(c.offset);
  const txt = a < 0.05 ? 'PC 시계가 사이트와 맞아요' : 'PC 시계가 사이트보다 ' + a.toFixed(1) + '초 ' + (c.offset > 0 ? '느려요' : '빨라요');
  const fixed = c.error <= 0.5 && a >= 0.05;
  const when = c.at ? fmtClock(c.at * 1000).slice(0, 5) + ' 확인' : '';
  return '<div class="clockline' + (a >= 1 ? ' bad' : '') + '"><b>사이트 시계</b><span>' + txt + ' (±' + c.error.toFixed(2) + '초)' + (fixed ? ' · 자동으로 맞춰서 진행해요' : '') + ' · ' + when + '</span>'
    + (a >= 1 ? '<span>Windows 설정 → 시간 및 언어 → 날짜 및 시간 → 지금 동기화를 권장해요</span>' : '') + '</div>';
}
function adminForm() {
  const d = S.data;
  return '<div style="display:flex;flex-direction:column;gap:12px"><div style="font-size:15px;font-weight:700">' + (d.admin.exists ? '관리자 비밀번호를 입력해 주세요' : '처음이에요 · 관리자 비밀번호를 정해 주세요') + '</div>'
    + '<div class="sub" style="font-size:12.5px">테스트 모드와 관리자 대시보드에 쓰여요.' + (d.admin.exists ? '' : ' 이 컴퓨터에만 암호화(해시)해서 보관하고, 대시보드 서버에도 같은 비밀번호로 처음 한 번 등록돼요.') + '</div>'
    + '<div style="display:flex;gap:8px"><input id="adminpw" class="input" style="flex:1" type="password" autocomplete="off" aria-label="관리자 비밀번호" placeholder="' + (d.admin.exists ? '비밀번호' : '새 비밀번호(4자 이상)') + '" data-input="pw" data-enter="adminLogin">'
    + '<button type="button" class="btn dark" style="height:42px;border-radius:14px" data-act="adminLogin">확인</button></div>'
    + (S.tm.err ? '<div style="font-size:12.5px;color:var(--red)">' + esc(S.tm.err) + '</div>' : '') + '</div>';
}
function tmDraft() {
  const now = nowMs();
  const def = kst(Math.ceil((now + 3 * 60e3) / 60e3) * 60e3);
  const date = S.tm.date || keyOf(def.getUTCFullYear(), def.getUTCMonth() + 1, def.getUTCDate());
  const time = S.tm.time || pad(def.getUTCHours()) + ':' + pad(def.getUTCMinutes()) + ':00';
  const ms = kstMs(+date.slice(0, 4), +date.slice(5, 7), +date.slice(8, 10), +time.slice(0, 2), +time.slice(3, 5), +time.slice(6, 8));
  return { date, time, ms };
}
function testPicker(inModal) {
  const d = S.data; const dr = tmDraft(); const tk = todayKey();
  const parts = dr.date.split('-').map(Number);
  const ym = S.tm.cal ?? (parts[0] * 12 + parts[1] - 1);
  const Y = Math.floor(ym / 12); const M = (ym % 12) + 1;
  const first = new Date(Date.UTC(Y, M - 1, 1)).getUTCDay(); const nd = new Date(Date.UTC(Y, M, 0)).getUTCDate();
  let cal = '';
  for (let i = 0; i < first; i++) cal += '<button type="button" class="blank" disabled></button>';
  for (let dd = 1; dd <= nd; dd++) {
    const k = keyOf(Y, M, dd); const past = k < tk; const dw = (first + dd - 1) % 7;
    cal += '<button type="button" class="' + (past ? 'past' : '') + (k === tk ? ' today' : '') + '"' + (past ? ' disabled' : '') + ' data-act="tmDate" data-v="' + k + '" aria-pressed="' + (k === dr.date) + '" style="' + (!past && k !== dr.date ? (dw === 0 ? 'color:var(--red)' : dw === 6 ? 'color:var(--blue)' : '') : '') + '">' + dd + '</button>';
  }
  const cols = [['시', 0, 24], ['분', 3, 60], ['초', 6, 60]].map(([name, at, n], i) => {
    const curV = +dr.time.slice(at, at + 2);
    let items = '';
    for (let v = 0; v < n; v++) items += '<button type="button" role="option" aria-selected="' + (v === curV) + '" data-act="tmTime" data-i="' + i + '" data-v="' + v + '">' + pad(v) + '</button>';
    return '<div style="display:flex;flex-direction:column;min-height:0"><div style="text-align:center;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px">' + name + '</div><div class="tcol" role="listbox" aria-label="' + name + '">' + items + '</div></div>';
  }).join('');
  const dl = Math.floor((dr.ms - nowMs()) / 1000);
  const T = d.timing;
  const summary = (dl > 0 ? (dl >= 86400 ? Math.floor(dl / 86400) + '일 ' : '') + (dl >= 3600 ? Math.floor((dl % 86400) / 3600) + '시간 ' : '') + Math.floor((dl % 3600) / 60) + '분 ' + (dl % 60) + '초 뒤' : '이미 지난 시각이에요')
    + ' · ' + T.pre_seconds + '초 전부터 확인하고 ' + T.rush_seconds + '초 동안 빠르게 시도해요 · 모든 계정의 목표를 이 시각에 진행';
  return '<div style="display:flex;align-items:baseline;justify-content:space-between"><div style="font-size:14px;font-weight:700">가상 오픈 시각' + (d.test_at ? ' <span class="pill limit">켜짐 · ' + fmtClock(Date.parse(d.test_at)) + '</span>' : '') + '</div><div class="num" style="font-size:22px;font-weight:700">' + md(dr.date) + ' ' + dr.time + '</div></div>'
    + '<div style="display:flex;gap:14px;align-items:stretch"><div aria-label="날짜 고르기" style="flex:0 0 280px;border:1px solid var(--line);border-radius:20px;padding:12px">'
    + '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px"><button type="button" class="circle-btn sm" style="width:30px;height:30px" data-act="tmCal" data-v="-1" aria-label="이전 달">' + SVG.prev + '</button><span style="font-size:14px;font-weight:700">' + Y + '년 ' + M + '월</span>'
    + '<button type="button" class="circle-btn sm" style="width:30px;height:30px" data-act="tmCal" data-v="1" aria-label="다음 달">' + SVG.next + '</button></div>'
    + '<div class="mini-cal"><div style="color:var(--red)">일</div><div class="sub">월</div><div class="sub">화</div><div class="sub">수</div><div class="sub">목</div><div class="sub">금</div><div style="color:var(--blue)">토</div>' + cal + '</div></div>'
    + '<div aria-label="시각 고르기" style="flex:1;min-width:0;border:1px solid var(--line);border-radius:20px;padding:12px 10px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px">' + cols + '</div></div>'
    + '<div style="display:flex;gap:6px;justify-content:center">' + [['1분 뒤', 1], ['3분 뒤', 3], ['10분 뒤', 10]].map(([l, m]) => '<button type="button" class="btn sm" style="height:32px;border-radius:16px" data-act="tmQuick" data-v="' + m + '">' + l + '</button>').join('') + '</div>'
    + '<div style="font-size:13px">' + summary + '</div>'
    + '<div class="warnbox">테스트여도 실제 사이트 장바구니에 담겨요. 담긴 칸은 장바구니 화면에서 바로 취소할 수 있어요. 예약 신청·결제는 하지 않아요.</div>'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">' + (d.test_at ? '<button type="button" class="btn" style="height:40px;border-radius:20px" data-act="tmOff">테스트 모드 끄기</button>' : '')
    + '<button type="button" class="btn danger" style="height:40px;border-radius:20px;padding:0 18px" data-act="tmApply" data-modal="' + (inModal ? 1 : 0) + '">' + (d.test_at ? '이 시각으로 바꾸기' : '테스트 모드 켜기') + '</button></div>';
}
function centerTimeCols() {
  document.querySelectorAll('.tcol').forEach((el) => {
    const s = el.querySelector('[aria-selected="true"]');
    if (s && !el.dataset.user) el.scrollTop = s.offsetTop - el.offsetTop - el.clientHeight / 2 + s.offsetHeight / 2;
  });
}

const PAGES = { home: homePage, book: bookPage, cart: cartPage, settings: settingsPage };

/* ------------------------------------------------------------ 모달 */
function renderModal() {
  const root = document.getElementById('modal-root');
  const m = S.modal;
  if (!m) { root.innerHTML = ''; return; }
  let inner = '';
  if (m.type === 'notice') {
    const NL = noticeList(); const n = NL[m.i] || NL[0];
    inner = '<div class="dialog" role="dialog" aria-modal="true" aria-label="' + esc(n.title) + '" style="width:min(560px,calc(100% - 32px))"><div style="display:flex;align-items:flex-start;gap:12px"><div style="flex:1"><span class="nbadge' + (n.badge === '고정' ? ' fix' : n.badge === '10월' ? ' month' : '') + '">' + esc(n.badge) + '</span>'
      + '<h2 style="margin:8px 0 2px;font-size:20px">' + esc(n.title) + '</h2><div class="sub" style="font-size:12.5px">게시일 ' + esc(n.date) + '</div></div><button type="button" class="circle-btn" data-act="modalClose" aria-label="닫기">✕</button></div>'
      + '<div style="padding-top:16px;border-top:1px solid var(--line);font-size:14px;line-height:1.75;color:var(--ink2);white-space:pre-line">' + esc(n.body) + '</div>'
      + '<div style="display:flex;justify-content:space-between;align-items:center"><button type="button" class="btn" data-act="noticeStep" data-v="-1">‹ 이전 공지</button><span class="sub">' + (m.i + 1) + ' / ' + NL.length + '</span><button type="button" class="btn" data-act="noticeStep" data-v="1">다음 공지 ›</button></div></div>';
  } else if (m.type === 'test') {
    inner = '<div class="dialog" role="dialog" aria-modal="true" aria-label="테스트 모드" style="width:640px"><div style="display:flex;align-items:center;justify-content:space-between"><h2 style="margin:0;font-size:18px">테스트 모드 <span class="sub" style="font-size:13px;font-weight:500">· 관리자</span></h2>'
      + '<button type="button" class="circle-btn sm" data-act="modalClose" aria-label="닫기">✕</button></div>' + (S.data.admin.ok ? testPicker(true) : adminForm()) + '</div>';
  } else if (m.type === 'export') {
    const k = kst(); const y = k.getUTCFullYear(); const mo = k.getUTCMonth() + 1;
    const months = [[y, mo, '이번 달'], [mo === 12 ? y + 1 : y, mo === 12 ? 1 : mo + 1, '다음 달']];
    const who = S.cart.acct === 'all' ? '전체 계정' : S.cart.acct + ' 계정';
    inner = '<div class="dialog" role="dialog" aria-modal="true" aria-label="엑셀 저장" style="width:420px"><div style="display:flex;align-items:center;justify-content:space-between"><h2 style="margin:0;font-size:18px">' + (m.kind === 'cart' ? '장바구니' : '예약 내역') + ' 엑셀 저장</h2>'
      + '<button type="button" class="circle-btn sm" data-act="modalClose" aria-label="닫기">✕</button></div><p class="sub" style="margin:0;font-size:13.5px">어느 달을 저장할까요? · ' + esc(who) + '<br>날짜, 시간(예: 10:00~12:00), 코트가 들어가요' + (m.kind === 'res' ? ' · 취소된 예약은 빼요' : '') + '.</p>'
      + months.map(([yy, mm, l]) => { const ms = yy + '-' + pad(mm); return '<a class="opt" data-act="modalClose" href="/api/export.csv?kind=' + m.kind + '&acct=' + encodeURIComponent(S.cart.acct) + '&month=' + ms + '"><div style="flex:1"><div style="font-size:16px;font-weight:700">' + l + '</div><div class="sub" style="font-size:12.5px;margin-top:2px">' + yy + '년 ' + mm + '월</div></div><span class="btn green sm" style="height:32px">저장</span></a>'; }).join('') + '</div>';
  } else if (m.type === 'rename') {
    inner = '<div class="dialog" role="dialog" aria-modal="true" aria-label="계정 이름 바꾸기" style="width:400px"><h2 style="margin:0;font-size:18px">계정 이름</h2><input id="renamein" class="input" maxlength="20" value="' + esc(m.name) + '" data-enter="renameDo" aria-label="새 이름">'
      + '<div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" class="btn" data-act="modalClose">취소</button><button type="button" class="btn dark" data-act="renameDo">바꾸기</button></div></div>';
  }
  root.innerHTML = '<div class="overlay" data-act="overlay">' + inner + '</div>';
  centerTimeCols();
  const f = root.querySelector('input'); if (f) f.focus();
}

/* ------------------------------------------------------------ 알림 */
function renderBell() {
  const notes = (S.data && S.data.notes) || [];
  const unread = notes.filter((n) => n.id > S.bellSeen).length;
  const b = document.getElementById('bell-count');
  b.hidden = unread === 0; b.textContent = unread > 99 ? '99+' : String(unread);
  const pop = document.getElementById('bell-pop');
  pop.hidden = !S.bellOpen;
  if (S.bellOpen) {
    const ic = { ok: '✓', warn: '!', err: '✕', info: '·' }; const col = { ok: '#2F6E12', warn: '#B4610E', err: 'var(--red)', info: 'var(--muted)' };
    const when = (t) => { const d = kst(t * 1000); const k = keyOf(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate()); return (k === todayKey() ? '' : (+k.slice(5, 7)) + '/' + (+k.slice(8)) + ' ') + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); };
    pop.innerHTML = notes.length ? notes.slice().reverse().map((n) => '<div class="row"' + (n.id > S.bellSeenBefore ? ' style="background:var(--soft);border-radius:10px"' : '') + '><span style="color:' + col[n.level] + ';font-weight:700">' + (ic[n.level] || '·') + '</span><span class="sub num" style="flex:0 0 auto">' + when(n.at) + '</span><span style="flex:1">'
      + esc((n.who && n.who !== '시스템' ? n.who + ' · ' : '') + n.msg) + (n.count > 1 ? ' <b class="sub">(' + n.count + '번)</b>' : '') + '</span></div>').join('') : '<div class="sub" style="padding:14px;text-align:center">알림이 없어요</div>';
  }
}

/* ------------------------------------------------------------ 동작 */
const H = {
  theme: (el) => { store.set('theme', el.dataset.v); render(); },
  bell: () => {
    S.bellOpen = !S.bellOpen;
    const notes = (S.data && S.data.notes) || [];
    S.bellSeenBefore = S.bellSeen;
    if (S.bellOpen && notes.length) { S.bellSeen = notes[notes.length - 1].id; store.set('bellSeen2', S.bellSeen); }
    renderBell();
  },
  pickAcct: (el) => { S.acct = el.dataset.v; store.set('acct', S.acct); S.book.courts = []; S.book.times = []; S.home.delAsk = false; render(); },
  addAcct: async () => {
    const j = await act('/api/accounts/add', {});
    if (j) { S.acct = j.name; store.set('acct', j.name); await act('/api/login/open', { name: j.name }, '열린 창에서 Google 계정을 고르면 나머지는 자동으로 돼요'); }
  },
  openLogin: () => act('/api/login/open', { name: cur().name }, '열린 창에서 Google 계정을 고르면 나머지는 자동으로 돼요'),
  checkLogin: () => act('/api/login/check', { name: cur().name }),
  delAsk: () => { S.home.delAsk = true; render(); },
  delCancel: () => { S.home.delAsk = false; render(); },
  delAcct: async () => { S.home.delAsk = false; await act('/api/accounts/remove', { name: cur().name }, '계정을 삭제했어요'); },
  rename: () => { S.modal = { type: 'rename', name: cur().name }; renderModal(); },
  renameDo: async () => {
    const v = document.getElementById('renamein').value.trim(); const old = S.modal.name;
    if (v && v !== old && await act('/api/accounts/rename', { name: old, new: v })) { S.acct = v; store.set('acct', v); }
    S.modal = null; renderModal(); render();
  },
  homeMonth: (el) => { const k = kst(); const base = S.home.ym ?? (k.getUTCFullYear() * 12 + k.getUTCMonth()); S.home.ym = base + Number(el.dataset.v); S.home.sel = null; render(); },
  homeToday: () => { S.home.ym = null; S.home.sel = todayKey(); render(); },
  homeSel: (el) => { S.home.sel = el.dataset.v; render(); },
  notice: (el) => { S.modal = { type: 'notice', i: Number(el.dataset.v) }; renderModal(); },
  noticeStep: (el) => { const L = noticeList().length; S.modal.i = (S.modal.i + Number(el.dataset.v) + L) % L; renderModal(); },
  modalClose: () => { S.modal = null; renderModal(); },
  overlay: (el, ev) => { if (ev.target === el) { S.modal = null; renderModal(); } },
  bookMonth: (el) => { const k = kst(); const min = k.getUTCFullYear() * 12 + k.getUTCMonth(); const base = S.book.ym ?? min + 1; S.book.ym = Math.max(min, base + Number(el.dataset.v)); S.book.courts = []; S.book.times = []; render(); },
  bookDate: (el) => { S.book.date = el.dataset.v; S.book.courts = []; S.book.times = []; render(); },
  bookCourt: (el) => {
    const c = Number(el.dataset.v); const B = S.book; const R = S.data.rules;
    if (B.courts.includes(c)) B.courts = B.courts.filter((x) => x !== c);
    else {
      const wk = ![0, 6].includes(dowOfKey(B.date)); const les = (x) => R.lesson.courts.includes(x);
      if (B.courts.length >= 2) return;
      if (wk && B.courts.length && les(c) !== les(B.courts[0])) return;
      B.courts = B.courts.concat(c);
    }
    render();
  },
  bookTime: (el) => {
    const t = Number(el.dataset.v); const B = S.book;
    if (B.times.includes(t)) B.times = B.times.filter((x) => x !== t); else if (B.times.length < 2) B.times = B.times.concat(t);
    render();
  },
  bookAdd: async () => {
    const B = S.book;
    const j = await act('/api/targets/add', { account: cur().name, date: B.date, courts: B.courts, starts: B.times });
    if (j) { B.courts = []; B.times = []; render(); toast('목표 ' + j.added + '개 추가'); }
  },
  tRemove: (el) => act('/api/targets/remove', { id: el.dataset.v }),
  run: async () => {
    if (S.data.running) await act('/api/stop', {});
    else await act('/api/start', {}, S.data.test_at ? '테스트 모드로 시작했어요' : '예약 시작 · 오픈 시각에 맞춰 진행해요');
  },
  openLogs: () => act('/api/logs/open', {}),
  cartAcct: (el) => { S.cart.acct = el.dataset.v; render(); },
  sort: (el) => {
    const key = el.dataset.which === 'c' ? 'csort' : 'rsort'; const curS = S.cart[key];
    S.cart[key] = curS[0] === el.dataset.v ? [curS[0], -curS[1]] : [el.dataset.v, 1]; render();
  },
  histTab: (el) => { S.cart.tab = el.dataset.v; render(); },
  cartAsk: (el) => { S.cart.asking = el.dataset.v; render(); },
  cartNo: () => { S.cart.asking = null; render(); },
  cartDo: async (el) => { S.cart.asking = null; el.disabled = true; await act('/api/cart/remove', { name: el.dataset.acct, sid: el.dataset.v }, '장바구니에서 취소했어요'); },
  exportOpen: (el) => { S.modal = { type: 'export', kind: el.dataset.v }; renderModal(); },
  setTab: (el) => { S.set.tab = el.dataset.v; S.tm.err = ''; if (el.dataset.v === 'log') loadLogs(); if (el.dataset.v === 'report') loadReports(); if (el.dataset.v === 'admin') loadDash(false); render(); },
  openReport: (el) => openReport(el.dataset.v),
  reportsReload: () => { S.set.rep = null; loadReports(); },
  knob: (el) => { const k = el.dataset.k; act('/api/timing', { [k]: S.data.timing[k] + Number(el.dataset.v) }); },
  knobReset: () => act('/api/timing', { reset: true }, '기본값으로 돌렸어요'),
  logKind: (el) => { S.set.kind = el.dataset.v; render(); },
  logsReload: () => loadLogs(),
  adminLogin: async () => {
    const pw = (document.getElementById('adminpw') || {}).value || '';
    try { await api('/api/admin/login', { pw }); S.tm.err = ''; } catch (e) { S.tm.err = e.message; }
    await poll(true); if (S.modal) renderModal();
    if (S.data.admin.ok && S.route === 'settings' && S.set.tab === 'admin') loadDash(false);
  },
  updateNow: () => act('/api/update/apply', {}, '업데이트를 받는 중이에요 · 끝나면 자동으로 다시 시작해요'),
  adminLock: () => { S.dash.data = null; S.dash.err = ''; S.dash.at = 0; return act('/api/admin/lock', {}); },
  testOpen: () => { S.tm.err = ''; S.modal = { type: 'test' }; renderModal(); },
  tmDate: (el) => { const d = tmDraft(); S.tm.date = el.dataset.v; S.tm.time = d.time; rerenderTm(); },
  tmCal: (el) => { const d = tmDraft(); const p = d.date.split('-').map(Number); S.tm.cal = (S.tm.cal ?? (p[0] * 12 + p[1] - 1)) + Number(el.dataset.v); S.tm.date = d.date; S.tm.time = d.time; rerenderTm(); },
  tmTime: (el) => {
    const d = tmDraft(); const t = d.time.split(':'); t[Number(el.dataset.i)] = pad(Number(el.dataset.v));
    S.tm.date = d.date; S.tm.time = t.join(':');
    document.querySelectorAll('.tcol').forEach((c) => { c.dataset.user = '1'; });
    rerenderTm();
  },
  tmQuick: (el) => { const k = kst(Math.ceil((nowMs() + Number(el.dataset.v) * 60e3) / 60e3) * 60e3); S.tm.date = keyOf(k.getUTCFullYear(), k.getUTCMonth() + 1, k.getUTCDate()); S.tm.time = pad(k.getUTCHours()) + ':' + pad(k.getUTCMinutes()) + ':00'; S.tm.cal = null; rerenderTm(); },
  tmApply: async (el) => {
    const d = tmDraft();
    const ok = await act('/api/test', { at: d.date + 'T' + d.time + '+09:00' }, '테스트 모드 · 가상 오픈 ' + d.time + ' · 예약 시작을 누르면 진행해요');
    if (ok && el.dataset.modal === '1') { S.modal = null; renderModal(); }
  },
  tmOff: async () => { await act('/api/test', { off: true }, '테스트 모드를 껐어요'); if (S.modal) { S.modal = null; renderModal(); } },
};
function rerenderTm() {
  if (S.modal && S.modal.type === 'test') renderModal(); else render();
}
async function loadLogs() {
  try {
    const r = await fetch('/api/logs' + (S.set.file ? '?file=' + encodeURIComponent(S.set.file) : ''), { cache: 'no-store' });
    const j = await r.json(); S.set.rows = j.rows || []; S.set.files = j.files || [];
  } catch (_) {}
  render();
}
const fileLabel = (n) => { const m = /^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})/.exec(n); return m ? (+m[2]) + '/' + (+m[3]) + ' ' + m[4] + ':' + m[5] : n; };
async function loadReports() {
  try { const r = await fetch('/api/reports', { cache: 'no-store' }); S.set.reports = (await r.json()).reports || []; } catch (_) {}
  if (!S.set.rep && S.set.reports && S.set.reports.length) await openReport(S.set.reports[0].file); else render();
}
async function openReport(file) {
  try { const r = await fetch('/api/report?file=' + encodeURIComponent(file), { cache: 'no-store' }); S.set.rep = { file, ...(await r.json()) }; } catch (_) {}
  render();
}
const RESULT = { done: ['담김', 'ok'], ended: ['못 담음', 'gray'], stopped: ['중지', 'gray'], removed: ['직접 취소', 'gray'], limit: ['한도', 'limit'], blocked: ['로그인 필요', 'warn'] };
function tLabel(l) { const m = /^(\d{4}-\d{2}-\d{2}) (\d+)번 (\d{2}:\d{2})$/.exec(l || ''); return m ? (+m[1].slice(5, 7)) + '/' + (+m[1].slice(8)) + ' ' + m[3] + ' · ' + m[2] + '번' : l; }
function sec(ms) { return ms == null ? '—' : (ms < 0 ? '-' : '+') + (Math.abs(ms) / 1000).toFixed(1) + '초'; }
function reportBody() {
  const T = S.set; const list = T.reports || [];
  const items = list.map((r) => {
    const on = T.rep && T.rep.file === r.file; const t = r.totals || {};
    return '<button type="button" class="opt" style="width:100%;text-align:left;padding:10px 12px;' + (on ? 'border-color:var(--ink);box-shadow:inset 0 0 0 1px var(--ink)' : '') + '" data-act="openReport" data-v="' + esc(r.file) + '"><div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:700">'
      + esc(fileLabel(r.file)) + ' · ' + esc((r.events || []).join(', ')) + (r.test ? ' <span class="pill limit">테스트</span>' : '') + '</div><div class="sub" style="font-size:12px;margin-top:2px">담김 ' + (t.done ?? 0) + '/' + (t.targets ?? 0) + ' · 시도 ' + (t.attempts ?? 0) + ' · 거절 ' + (t.rejected ?? 0) + (t.lat_avg != null ? ' · 평균 ' + t.lat_avg + 'ms' : '') + '</div></div></button>';
  }).join('');
  let detail = '<div class="center-msg">실행이 끝나면 여기에 요약이 생겨요</div>';
  const R = T.rep;
  if (R && R.targets) {
    const t = R.totals || {}; const h = R.http || {};
    const card = (label, v, sub) => '<div style="flex:1;min-width:0;background:var(--soft);border-radius:16px;padding:12px 14px"><div class="sub" style="font-size:12px">' + label + '</div><div class="num" style="font-size:22px;font-weight:700;margin-top:2px">' + v + '</div><div class="sub" style="font-size:11.5px">' + (sub || '') + '</div></div>';
    detail = '<div style="display:flex;gap:10px">' + card('담김', (t.done ?? 0) + ' / ' + (t.targets ?? 0), '목표 중 장바구니에 들어간 수')
      + card('담기 시도', t.attempts ?? 0, '거절 ' + (t.rejected ?? 0) + ' · 응답 불확실 ' + (t.unknown ?? 0)) + card('담기 응답', t.lat_avg != null ? t.lat_avg + 'ms' : '—', '평균(요청→응답)')
      + card('슬롯 조회', h.polls ?? 0, '평균 ' + (h.avg_ms ?? '—') + 'ms · 최대 ' + (h.max_ms ?? '—') + 'ms' + (h.rate_limited ? ' · 429 ' + h.rate_limited + '번' : '') + (h.errors ? ' · 오류 ' + h.errors : '')) + '</div>'
      + '<div class="sub" style="font-size:12px">' + (R.events || []).map((e) => esc(e.name) + ' 오픈 ' + esc((e.at || '').slice(5, 16).replace('T', ' ')) + (e.source && e.source !== '공지 규칙' ? ' (' + esc(e.source) + ')' : '')).join(' · ') + ' · 기록 파일 ' + esc(R.log_file || '') + '</div>'
      + '<div class="logtable" style="flex:1 1 0"><div class="hd" style="grid-template-columns:minmax(0,1fr) 60px 80px 40px 40px 70px 70px 76px"><span>목표</span><span>계정</span><span>열림 감지</span><span>시도</span><span>거절</span><span>평균 응답</span><span>담김 시각</span><span>결과</span></div><div style="flex:1 1 0;min-height:0;overflow-y:auto">'
      + R.targets.map((x) => { const r2 = RESULT[x.result] || [x.result || '—', 'gray']; return '<div class="r" style="grid-template-columns:minmax(0,1fr) 60px 80px 40px 40px 70px 70px 76px" title="' + esc((x.reject_reasons || []).join(' / ')) + '"><span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(tLabel(x.label)) + '</span><span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(x.account) + '</span><span class="num">' + sec(x.first_open_ms) + '</span><span class="num">' + x.attempts + '</span><span class="num">' + x.rejected + '</span><span class="num">' + (x.lat_avg != null ? x.lat_avg + 'ms' : '—') + '</span><span class="num">' + sec(x.done_ms) + '</span><span><span class="pill ' + r2[1] + '">' + r2[0] + '</span></span></div>'; }).join('')
      + '</div></div><div class="sub" style="font-size:12px">열림 감지·담김 시각은 오픈 시각 기준이에요(+0.8초 = 오픈 0.8초 뒤). 거절 이유는 줄에 마우스를 올리면 보여요.</div>';
  }
  return '<div class="row-between" style="align-items:center"><h2 class="h2" style="font-size:20px">실행 기록</h2><button type="button" class="btn sm" data-act="reportsReload">새로고침</button></div>'
    + '<div style="flex:1 1 0;min-height:0;display:flex;gap:16px"><div style="flex:0 0 280px;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:8px">' + (items || '<div class="sub" style="padding:20px 4px">아직 실행 기록이 없어요</div>') + '</div>'
    + '<div style="flex:1 1 0;min-width:0;min-height:0;display:flex;flex-direction:column;gap:12px">' + detail + '</div></div>';
}
function refreshAccounts() {
  const now = Date.now() / 1000;
  accts().forEach((a) => { if (a.linked && a.profile && !a.login_open && (!a.synced_at || now - a.synced_at > 120) && !['checking', 'error', 'login'].includes(a.state)) api('/api/accounts/refresh', { name: a.name }).catch(() => {}); });
}

document.addEventListener('click', (ev) => {
  const el = ev.target.closest('[data-act]');
  if (!el) { if (S.bellOpen && !ev.target.closest('.bell-wrap')) { S.bellOpen = false; renderBell(); } return; }
  const f = H[el.dataset.act];
  if (f) { if (el.tagName !== 'A') ev.preventDefault(); f(el, ev); }
});
document.addEventListener('input', (ev) => {
  const el = ev.target;
  if (el.dataset.input === 'logq') { S.set.q = el.value; render(); }
});
document.addEventListener('change', (ev) => {
  const el = ev.target;
  if (el.dataset && el.dataset.change === 'logFile') {
    const f = (S.set.files || []).find((x) => x.name === el.value);
    S.set.file = f && !f.current ? f.name : ''; loadLogs();
  }
});
document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape' && S.modal) { S.modal = null; renderModal(); }
  const el = ev.target;
  if (ev.key === 'Enter' && el.dataset && el.dataset.enter && H[el.dataset.enter]) { ev.preventDefault(); H[el.dataset.enter](el, ev); }
});
document.addEventListener('pointerdown', dragStart);
document.addEventListener('pointermove', dragMove);
document.addEventListener('pointerup', dragEnd);
document.addEventListener('pointercancel', dragEnd);
function route() {
  S.route = (location.hash || '#home').slice(1);
  if (S.route === 'settings' && S.set.tab === 'log') loadLogs();
  if (S.route === 'settings' && S.set.tab === 'report') loadReports();
  if (S.route === 'settings' && S.set.tab === 'admin') loadDash(false);
  if (S.route === 'cart' || S.route === 'home') refreshAccounts();
  render();
}
window.addEventListener('hashchange', route);
/* 화면 맞추기: 기준 1440×1040에서 짧은 쪽 비율로 전체를 키우고 줄이며, 남는 쪽은 칸이 늘어나 꽉 채운다 */
function fit() {
  const w = window.innerWidth; const h = window.innerHeight;
  const raw = Math.min(w / 1440, h / 1040);
  const z = Math.max(0.72, Math.min(2.2, raw));
  document.body.style.zoom = z;
  const frame = document.querySelector('.frame');
  const page = document.querySelector('.page');
  const padY = 0, padX = 0;   // 보라색 틀이 창 전체를 채움
  page.style.padding = padY + 'px ' + padX + 'px';
  frame.style.width = Math.max(1100, w / z - padX * 2) + 'px';
  frame.style.height = Math.max(820, h / z - padY * 2) + 'px';
  document.body.classList.toggle('small', raw < 0.72 || w / z < 1100 + padX * 2 || h / z < 820 + padY * 2);
}
window.addEventListener('resize', fit);
/* 화면(탭)을 닫으면 프로그램에 알려서 꺼지게 한다(새로고침이면 곧바로 다시 연결돼서 안 꺼짐. 예약 중엔 계속 실행) */
window.addEventListener('pagehide', () => { try { if (S.data) navigator.sendBeacon('/api/bye?c=' + encodeURIComponent(S.data.csrf)); } catch (_) {} });
/* 화면 오류는 프로그램 기록으로 보내 관리자 대시보드에 남긴다(한 번 켤 때 최대 5번) */
let clientErrs = 0;
function reportClientError(msg, src, line) {
  if (clientErrs++ >= 5 || !S.data) return;
  api('/api/clientlog', { msg: String(msg || '').slice(0, 200), src: String(src || ''), line: line || 0 }).catch(() => {});
}
window.addEventListener('error', (e) => reportClientError(e.message, e.filename, e.lineno));
window.addEventListener('unhandledrejection', (e) => reportClientError('Promise: ' + ((e.reason && e.reason.message) || e.reason), '', 0));
fit();
setInterval(() => poll(false), 1000);
setInterval(updateLive, 250);
setInterval(() => { if (S.route === 'cart' || S.route === 'home') refreshAccounts(); }, 60e3);
poll(true).then(route);
