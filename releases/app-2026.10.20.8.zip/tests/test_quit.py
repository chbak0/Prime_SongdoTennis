"""화면의 '프로그램 끄기' 버튼과 다시 켜기용 주소 등록."""
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core.engine import Engine
from core.journal import Journal
from test_engine import FakeServer, FakeTransport


class QuitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=d, engine=self.eng, start_threads=False)
        self.down = []
        self.app.request_shutdown = lambda: self.down.append(time.time())
        self.app.auto_exit = True

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_quit_now(self):
        t0 = time.time()
        self.app.quit()
        time.sleep(0.7)
        self.assertEqual(len(self.down), 1)
        self.assertLess(self.down[0] - t0, 1.0)            # 15초 기다리지 않음
        self.assertFalse(self.app.auto_exit)

    def test_running_needs_force(self):
        self.eng.running = True
        stopped = []
        self.eng.stop = lambda: stopped.append(1)
        with self.assertRaises(ValueError):
            self.app.quit()
        self.app.quit(force=True)
        time.sleep(0.6)
        self.assertEqual(stopped, [1])
        self.assertEqual(len(self.down), 1)

    def test_protocol_registration_skipped_off_windows(self):
        self.assertFalse(appmod.App.register_protocol(Path(self.tmp.name)))


if __name__ == "__main__":
    unittest.main()
