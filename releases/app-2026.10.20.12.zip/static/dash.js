'use strict';
/* 관리자 대시보드(설정 → 관리자). Supabase에 모인 모든 PC의 사용 현황·예약 성과·안정성, 그리고 원격 제어.
   app.js의 S, H, esc, pad, kst, render, api, act, toast를 함께 쓴다. */

S.dash = { issue: null, relNotes: '', relAuto: true, calM: 0, calSel: null, sub: 'pc', data: null, err: '', loading: false, at: 0, skew: 0, test: false, notice: '', minv: '', ask: '' };

const DASH_ONLINE_MS = 3 * 60e3;      // 하트비트 1분 → 3분 안에 소식이 있으면 '켜져 있음'
const nowSrv = () => Date.now() + S.dash.skew;
function ago(iso) {
  const s = Math.max(0, Math.floor((nowSrv() - Date.parse(iso)) / 1000));
  if (s < 60) return '방금';
  if (s < 3600) return Math.floor(s / 60) + '분 전';
  if (s < 86400) return Math.floor(s / 3600) + '시간 전';
  return Math.floor(s / 86400) + '일 전';
}
function whenK(iso) { const d = kst(Date.parse(iso)); return (d.getUTCMonth() + 1) + '/' + d.getUTCDate() + ' ' + pad(d.getUTCHours()) + ':' + pad(d.getUTCMinutes()); }
const pct = (a, b) => (b ? Math.round((a / b) * 100) + '%' : '—');
const avg = (xs) => { const v = xs.filter((x) => x != null && isFinite(x)); return v.length ? Math.round(v.reduce((s, x) => s + x, 0) / v.length) : null; };

async function loadDash(quiet) {
  if (!S.data || !S.data.admin.ok || !S.data.cloud.enabled || S.dash.loading) return;
  S.dash.loading = true; if (!quiet) render();
  try {
    const r = await fetch('/api/admin/dash?days=60', { cache: 'no-store' });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || '불러오기 실패');
    S.dash.data = j; S.dash.err = ''; S.dash.at = Date.now();
    S.dash.skew = Date.parse(j.server_time) - Date.now();
    if (!S.dash.minvTouched) S.dash.minv = (j.control && j.control.min_version) || '';
  } catch (e) { S.dash.err = e.message; }
  S.dash.loading = false; render();
}

/* ---------------------------------------------------------------- 데이터 정리 */
function dashModel() {
  const D = S.dash.data; const ctrl = D.control || {};
  const stopIds = new Set(ctrl.stop_ids || []);
  const pcs = (D.installs || []).map((i) => ({ ...i, online: nowSrv() - Date.parse(i.last_seen) < DASH_ONLINE_MS, stopped: stopIds.has(i.id) }));
  const pcName = {}; pcs.forEach((p) => { pcName[p.id] = p.pc || 'PC'; });
  const runs = (D.runs || []).filter((r) => S.dash.test || !r.test);
  const since = (days) => nowSrv() - days * 86400e3;
  const tgts = (rs) => rs.flatMap((r) => (r.report.targets || []).map((t) => ({ ...t, _run: r })));
  const issues = D.issues || [];
  return { D, ctrl, pcs, pcName, runs, since, tgts, issues, stopIds };
}
function targetParts(t) {
  if (t.court != null) return { date: t.date, court: t.court, start: t.start };
  const m = /^(\d{4}-\d{2}-\d{2}) (\d+)번 (\d{2}):(\d{2})$/.exec(t.label || '');
  return m ? { date: m[1], court: +m[2], start: +m[3] * 60 + +m[4] } : { date: '', court: null, start: null };
}
const kpi = (label, v, sub, tone) => '<div class="kpi' + (tone ? ' ' + tone : '') + '"><div class="sub" style="font-size:12px">' + label + '</div><div class="num" style="font-size:24px;font-weight:700;margin-top:2px">' + v + '</div><div class="sub" style="font-size:11.5px">' + (sub || '') + '</div></div>';
function hbars(rows, max) {
  // rows: [label, value(0~1 or count), text]
  return rows.map(([l, v, t]) => '<div class="hbar"><span class="l">' + esc(l) + '</span><span class="b"><i style="width:' + Math.max(1.5, Math.min(100, (v / (max || 1)) * 100)) + '%"></i></span><span class="t num">' + esc(t) + '</span></div>').join('')
    || '<div class="sub" style="font-size:12.5px;padding:8px 0">아직 자료가 없어요</div>';
}

/* ---------------------------------------------------------------- 화면 */
function adminBody() {
  const d = S.data; const X = S.dash;
  const head = (right) => '<div class="row-between" style="align-items:center"><h2 class="h2" style="font-size:20px">관리자 대시보드</h2><div style="display:flex;gap:8px;align-items:center">' + (right || '')
    + (d.admin.ok ? '<button type="button" class="btn sm" data-act="adminLock">관리자 잠그기</button>' : '') + '</div></div>';
  if (!d.admin.ok) return head() + '<div style="max-width:460px;border:1px solid var(--line);border-radius:20px;padding:20px">' + adminForm() + '</div>';
  if (!d.cloud.enabled) {
    return head() + '<div class="warnbox" style="max-width:640px">대시보드 서버가 아직 연결되지 않았어요. 프로그램 폴더에 <b>cloud.json</b>(Supabase 주소·공개 키)을 넣고 프로그램을 다시 켜 주세요. 만드는 방법은 README의 "관리자 대시보드" 부분에 있어요.</div>';
  }
  const subBtn = (k, l) => '<button type="button" data-act="dashSub" data-v="' + k + '" aria-pressed="' + (X.sub === k) + '">' + l + '</button>';
  const right = '<div class="tabs" role="group" aria-label="대시보드 보기">' + subBtn('pc', 'PC 현황') + subBtn('cal', '예약 현황') + subBtn('perf', '예약 성과') + subBtn('health', '안정성') + subBtn('ctrl', '원격 제어') + '</div>'
    + '<span class="sub" style="font-size:12px;white-space:nowrap">' + (X.loading ? '불러오는 중…' : X.at ? fmtClock(X.at).slice(0, 5) + ' 기준' : '') + '</span>'
    + '<button type="button" class="btn sm" data-act="dashReload">새로고침</button>';
  if (!X.data) return head(right) + (X.err ? '<div class="warnbox">' + esc(X.err) + '</div>' : '<div class="center-msg">불러오는 중…</div>');
  const M = dashModel();
  const body = X.sub === 'cal' ? dashCal(M) : X.sub === 'perf' ? dashPerf(M) : X.sub === 'health' ? dashHealth(M) : X.sub === 'ctrl' ? dashCtrl(M) : dashPcs(M);
  return head(right) + (X.err ? '<div class="warnbox">' + esc(X.err) + '</div>' : '') + body;
}

function dashPcs(M) {
  const X = S.dash; const me = M.D.me;
  const latest = M.pcs.reduce((v, p) => (vt(p.version) > vt(v) ? p.version : v), '');
  const accts = new Set(M.pcs.flatMap((p) => (p.accounts || []).filter((a) => a && a[0] !== '(')));
  const wk = M.runs.filter((r) => Date.parse(r.started) > M.since(7));
  const byPc = {}; wk.forEach((r) => { const b = byPc[r.install_id] || (byPc[r.install_id] = { done: 0, n: 0 }); b.done += r.report.totals.done || 0; b.n += r.report.totals.targets || 0; });
  const cols = 'grid-template-columns:minmax(0,1.1fr) minmax(0,1.6fr) 104px 64px 96px 74px 86px 128px';
  const rows = M.pcs.map((p) => {
    const st = p.stopped ? ['정지됨', 'warn'] : !p.online ? ['꺼짐', 'gray'] : p.running ? [p.state || '예약 중', 'run'] : ['켜짐', 'ok'];
    const b = byPc[p.id];
    const asking = X.ask === 'pc:' + p.id;
    const btns = asking
      ? '<button type="button" class="btn danger sm" data-act="dashPcStop" data-v="' + p.id + '">' + (p.stopped ? '해제' : '정지') + '</button><button type="button" class="btn sm" data-act="dashAskNo">아니요</button>'
      : '<button type="button" class="btn sm' + (p.stopped ? '' : ' danger-line') + '" data-act="dashAsk" data-v="pc:' + p.id + '">' + (p.stopped ? '정지 해제' : '정지') + '</button>'
        + (!p.online && p.id !== me ? '<button type="button" class="btn sm" data-act="dashForget" data-v="' + p.id + '" title="목록에서 지우기(다시 켜면 다시 나타나요)">지우기</button>' : '');
    return '<div class="r" style="' + cols + ';align-items:center"><span style="min-width:0"><b style="font-size:13px">' + esc(p.pc || 'PC') + '</b>' + (p.id === me ? ' <span class="pill wait">이 PC</span>' : '') + '<div class="sub" style="font-size:11px">' + esc(p.os) + '</div></span>'
      + '<span style="min-width:0;font-size:12px;line-height:1.5;overflow:hidden">' + ((p.accounts || []).map((a) => esc(a)).join('<br>') || '<span class="sub">계정 없음</span>') + '</span>'
      + '<span class="num">' + esc(p.version || '—') + (p.version && p.version !== latest ? ' <span class="pill limit" title="최신 아님">구버전</span>' : '') + '</span>'
      + '<span class="num" style="font-size:12px' + (p.clock_ms != null && Math.abs(p.clock_ms) >= 1000 ? ';color:var(--red);font-weight:700' : '') + '" title="사이트 서버보다 PC 시계가 느리면 +, 빠르면 −">' + (p.clock_ms == null ? '—' : (p.clock_ms > 0 ? '+' : p.clock_ms < 0 ? '−' : '') + (Math.abs(p.clock_ms) / 1000).toFixed(1) + '초') + '</span>'
      + '<span><span class="pill ' + st[1] + '">' + esc(st[0]) + '</span><div class="sub" style="font-size:11px;margin-top:3px">목표 ' + (p.targets || 0) + '개</div></span>'
      + '<span class="sub" style="font-size:12px">' + ago(p.last_seen) + '</span>'
      + '<span class="num" style="font-size:12.5px">' + (b ? b.done + '/' + b.n + ' (' + pct(b.done, b.n) + ')' : '—') + '</span>'
      + '<span style="display:flex;gap:6px;justify-content:flex-end">' + btns + '</span></div>';
  }).join('');
  return '<div class="kpis">' + kpi('켜져 있는 PC', M.pcs.filter((p) => p.online).length + ' / ' + M.pcs.length, '3분 안에 소식이 온 PC')
    + kpi('예약 실행 중', M.pcs.filter((p) => p.online && p.running).length + '대', '지금 감시·담기 중인 PC')
    + kpi('연결된 계정', accts.size + '개', '사이트 아이디 기준')
    + kpi('최신 버전 사용', M.pcs.filter((p) => p.version === latest).length + ' / ' + M.pcs.length, '최신 ' + (latest || '—'))
    + kpi('정지 상태', (M.ctrl.stop_all ? '전체' : M.stopIds.size + '대'), M.ctrl.stop_all ? '모든 PC 실행 막힘' : '원격 제어 탭에서 전체 정지', M.ctrl.stop_all || M.stopIds.size ? 'bad' : '') + '</div>'
    + '<div class="logtable"><div class="hd" style="' + cols + '"><span>PC</span><span>계정 아이디</span><span>버전</span><span>시계 오차</span><span>상태</span><span>마지막 접속</span><span>7일 담김</span><span style="text-align:right">제어</span></div>'
    + '<div style="flex:1 1 0;min-height:0;overflow-y:auto" data-keep-scroll="dashpc">' + (rows || '<div class="center-msg">아직 접속한 PC가 없어요</div>') + '</div></div>'
    + '<div class="sub" style="font-size:12px">각 PC는 프로그램이 켜져 있는 동안 1분마다 소식을 보내요 · 정지·해제는 1분 안에 그 PC에 반영돼요 · 예약 신청·결제는 원격으로도 하지 않아요</div>';
}
function vt(v) { return String(v || '').split('.').map((x) => pad(+x || 0).padStart(4, '0')).join('.'); }

function dashPerf(M) {
  const X = S.dash;
  const r7 = M.runs.filter((r) => Date.parse(r.started) > M.since(7)); const r30 = M.runs.filter((r) => Date.parse(r.started) > M.since(30));
  const sum = (rs, k) => rs.reduce((s, r) => s + ((r.report.totals || {})[k] || 0), 0);
  const t30 = M.tgts(r30);
  const lat = avg(r30.map((r) => (r.report.totals || {}).lat_avg));
  const opened = avg(t30.map((t) => t.first_open_ms));
  // 주간 추이(최근 8주)
  const wk = [];
  for (let i = 7; i >= 0; i--) {
    const a = M.since((i + 1) * 7); const b = M.since(i * 7);
    const rs = M.runs.filter((r) => { const t = Date.parse(r.started); return t > a && t <= b; });
    const d = kst(b); wk.push({ l: (d.getUTCMonth() + 1) + '/' + d.getUTCDate(), done: sum(rs, 'done'), n: sum(rs, 'targets') });
  }
  const trend = '<div class="vbars">' + wk.map((w) => { const r = w.n ? w.done / w.n : 0; return '<div class="vb" title="' + w.done + '/' + w.n + '"><span class="num">' + (w.n ? Math.round(r * 100) + '%' : '') + '</span><i style="height:' + (w.n ? Math.max(3, r * 100) : 0) + '%"></i><small>' + w.l + '</small></div>'; }).join('') + '</div>';
  // 코트·시간대별 경쟁(30일)
  const group = (keyf) => { const g = {}; t30.forEach((t) => { const k = keyf(targetParts(t)); if (k == null) return; const b = g[k] || (g[k] = { n: 0, done: 0 }); b.n++; if (t.result === 'done') b.done++; }); return g; };
  const gc = group((p) => p.court); const gt = group((p) => p.start);
  const courtRows = Object.keys(gc).sort((a, b) => a - b).map((k) => [k + '번', gc[k].done / gc[k].n, gc[k].done + '/' + gc[k].n]);
  const timeRows = Object.keys(gt).sort((a, b) => a - b).map((k) => [hm(+k), gt[k].done / gt[k].n, gt[k].done + '/' + gt[k].n]);
  // 결과·거절 이유
  const RES = { done: '담김', ended: '못 담음', stopped: '중지', removed: '직접 취소', limit: '한도', blocked: '로그인 필요' };
  const rc = {}; t30.forEach((t) => { const k = RES[t.result] || t.result || '기타'; rc[k] = (rc[k] || 0) + 1; });
  const rr = {}; t30.forEach((t) => (t.reject_reasons || []).forEach((x) => { const k = String(x).slice(0, 40); rr[k] = (rr[k] || 0) + 1; }));
  const rcMax = Math.max(1, ...Object.values(rc)); const rrTop = Object.entries(rr).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const runRows = M.runs.slice(0, 40).map((r) => {
    const T = r.report.totals || {};
    return '<div class="r" style="grid-template-columns:84px minmax(0,1fr) minmax(0,1fr) 64px 46px 64px"><span class="num">' + whenK(r.started) + '</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(M.pcName[r.install_id] || 'PC') + (r.test ? ' <span class="pill limit">테스트</span>' : '') + '</span>'
      + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc((r.report.events || []).map((e) => e.name).join(', ')) + '</span><span class="num">' + (T.done || 0) + '/' + (T.targets || 0) + '</span><span class="num">' + (T.rejected || 0) + '</span><span class="num">' + (T.lat_avg != null ? T.lat_avg + 'ms' : '—') + '</span></div>';
  }).join('');
  return '<div class="kpis">' + kpi('7일 성공률', pct(sum(r7, 'done'), sum(r7, 'targets')), '담김 ' + sum(r7, 'done') + ' / 목표 ' + sum(r7, 'targets'))
    + kpi('30일 성공률', pct(sum(r30, 'done'), sum(r30, 'targets')), '실행 ' + r30.length + '번')
    + kpi('열림 감지', opened != null ? (opened / 1000).toFixed(1) + '초' : '—', '오픈 시각 → 열림 확인(평균)')
    + kpi('담기 응답', lat != null ? lat + 'ms' : '—', '요청 → 응답(평균)')
    + kpi('거절', sum(r30, 'rejected') + '번', '30일 · 응답 불확실 ' + sum(r30, 'unknown') + '번') + '</div>'
    + '<div class="dgrid"><section class="dcard"><div class="dh">최근 실행 <label class="sub" style="font-size:12px;font-weight:500;margin-left:auto"><input type="checkbox" data-act="dashTest"' + (X.test ? ' checked' : '') + '> 테스트 포함</label></div>'
    + '<div class="logtable" style="border:0;border-radius:0"><div class="hd" style="grid-template-columns:84px minmax(0,1fr) minmax(0,1fr) 64px 46px 64px"><span>시작</span><span>PC</span><span>오픈</span><span>담김</span><span>거절</span><span>응답</span></div><div style="flex:1 1 0;min-height:0;overflow-y:auto" data-keep-scroll="dashruns">' + (runRows || '<div class="center-msg">아직 실행 기록이 없어요</div>') + '</div></div></section>'
    + '<div class="dcol"><section class="dcard" style="flex:0 0 auto"><div class="dh">주간 성공률 <span class="sub" style="font-size:12px;font-weight:500">최근 8주</span></div>' + trend + '</section>'
    + '<div style="display:flex;gap:12px;flex:1 1 0;min-height:0"><section class="dcard"><div class="dh">코트별 담김 <span class="sub" style="font-size:12px;font-weight:500">30일</span></div><div class="scrolly">' + hbars(courtRows, 1) + '</div></section>'
    + '<section class="dcard"><div class="dh">시간대별 담김</div><div class="scrolly">' + hbars(timeRows, 1) + '</div></section>'
    + '<section class="dcard"><div class="dh">결과 · 거절 이유</div><div class="scrolly">' + hbars(Object.entries(rc).sort((a, b) => b[1] - a[1]).map(([k, v]) => [k, v, v + '개']), rcMax)
    + (rrTop.length ? '<div class="sub" style="font-size:11.5px;margin-top:8px;line-height:1.6">' + rrTop.map(([k, v]) => esc(k) + ' · ' + v).join('<br>') + '</div>' : '') + '</div></section></div></div></div>';
}

function dashHealth(M) {
  const X = S.dash;
  const i7 = M.issues.filter((x) => Date.parse(x.at) > M.since(7));
  const r7 = M.runs.filter((r) => Date.parse(r.started) > M.since(7));
  const rl = r7.reduce((s, r) => s + ((r.report.http || {}).rate_limited || 0), 0);
  const he = r7.reduce((s, r) => s + ((r.report.http || {}).errors || 0), 0);
  const poll = avg(r7.map((r) => (r.report.http || {}).avg_ms));
  const loginFail = i7.filter((x) => /로그인/.test(x.msg)).length;
  // 일별(14일) 주의·오류
  const days = [];
  for (let i = 13; i >= 0; i--) {
    const d = kst(nowSrv() - i * 86400e3); const k = keyOf(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
    const xs = M.issues.filter((x) => { const t = kst(Date.parse(x.at)); return keyOf(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()) === k; });
    days.push({ l: (+k.slice(8)) + '', w: xs.filter((x) => x.level === 'warn').length, e: xs.filter((x) => x.level === 'err').length });
  }
  const mx = Math.max(1, ...days.map((d) => d.w + d.e));
  const chart = '<div class="vbars">' + days.map((d) => '<div class="vb" title="주의 ' + d.w + ' · 오류 ' + d.e + '"><span class="num">' + (d.w + d.e || '') + '</span><i style="height:' + ((d.w + d.e) / mx) * 100 + '%;background:linear-gradient(to top,var(--red) ' + (d.w + d.e ? (d.e / (d.w + d.e)) * 100 : 0) + '%,#F2A65A 0)"></i><small>' + d.l + '</small></div>').join('') + '</div>';
  const freq = {}; i7.forEach((x) => { const k = x.msg.replace(/\d+/g, 'N').slice(0, 50); freq[k] = (freq[k] || 0) + 1; });
  const top = Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const LV = { warn: ['주의', 'warn'], err: ['오류', 'err'] };
  const list = M.issues.slice(0, 200).map((x) => '<div class="r' + (x.has_ctx ? ' clickable' : '') + (X.issue && X.issue.id === x.id ? ' on' : '') + '" style="grid-template-columns:84px minmax(0,0.8fr) minmax(0,1fr) 46px minmax(0,2fr)"' + (x.has_ctx ? ' data-act="dashIssue" data-v="' + x.id + '" title="눌러서 직전 기록 보기"' : '') + '><span class="num">' + whenK(x.at) + '</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(M.pcName[x.install_id] || 'PC') + '</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(x.account || '-') + '</span><span class="lvl ' + (LV[x.level] || ['', 'info'])[1] + '">' + (LV[x.level] || [x.level])[0] + '</span><span style="word-break:break-all">' + esc(x.msg) + (x.has_ctx ? ' <span class="pill wait">기록</span>' : '') + '</span></div>').join('');
  const LV2 = { info: '정보', ok: '성공', warn: '주의', err: '오류' };
  const ctxPanel = X.issue ? '<section class="dcard"><div class="dh">' + esc(whenK(X.issue.at)) + ' 오류 직전 기록 <span class="sub" style="font-size:12px;font-weight:500">' + esc(M.pcName[X.issue.install_id] || 'PC') + '</span><button type="button" class="btn sm" style="margin-left:auto" data-act="dashIssueClose">닫기</button></div>'
    + '<div class="sub" style="font-size:12.5px">' + esc(X.issue.msg) + '</div><div class="logtable" style="border:0;border-radius:0"><div class="hd" style="grid-template-columns:88px 40px minmax(0,0.6fr) 44px minmax(0,2.6fr)"><span>시각</span><span>종류</span><span>계정</span><span>분류</span><span>내용</span></div><div style="flex:1 1 0;min-height:0;overflow-y:auto">'
    + (X.issue.context || []).map((r) => '<div class="r" style="grid-template-columns:88px 40px minmax(0,0.6fr) 44px minmax(0,2.6fr)"><span class="mono" style="color:var(--muted)">' + esc(String(r.ts).slice(-12)) + '</span><span class="lvl ' + esc(r.lvl) + '">' + (LV2[r.lvl] || esc(r.lvl)) + '</span><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(r.acct) + '</span><span class="sub" style="font-size:12px">' + esc(r.cat) + '</span><span class="mono" style="word-break:break-all">' + esc(r.msg) + '</span></div>').join('') + '</div></div></section>' : '';
  return '<div class="kpis">' + kpi('주의 · 오류', i7.filter((x) => x.level === 'warn').length + ' · ' + i7.filter((x) => x.level === 'err').length, '최근 7일', i7.some((x) => x.level === 'err') ? 'bad' : '')
    + kpi('로그인 문제', loginFail + '번', '최근 7일 · 로그인 필요')
    + kpi('요청 제한(429)', rl + '번', '최근 7일 실행 중', rl ? 'bad' : '')
    + kpi('통신 오류', he + '번', '최근 7일 슬롯 조회 실패')
    + kpi('슬롯 조회 지연', poll != null ? poll + 'ms' : '—', '최근 7일 평균') + '</div>'
    + '<div class="dgrid"><section class="dcard"><div class="dh">최근 주의·오류</div><div class="logtable" style="border:0;border-radius:0"><div class="hd" style="grid-template-columns:84px minmax(0,0.8fr) minmax(0,1fr) 46px minmax(0,2fr)"><span>시각</span><span>PC</span><span>계정</span><span>종류</span><span>내용</span></div>'
    + '<div style="flex:1 1 0;min-height:0;overflow-y:auto" data-keep-scroll="dashiss">' + (list || '<div class="center-msg">문제가 없어요</div>') + '</div></div></section>'
    + (ctxPanel ? '<div class="dcol">' + ctxPanel + '</div></div>' : '')
    + (ctxPanel ? '' : '<div class="dcol"><section class="dcard" style="flex:0 0 auto"><div class="dh">일별 주의·오류 <span class="sub" style="font-size:12px;font-weight:500">최근 14일 · 빨강=오류</span></div>' + chart + '</section>'
    + '<section class="dcard"><div class="dh">자주 나는 문제 <span class="sub" style="font-size:12px;font-weight:500">7일</span></div><div class="scrolly wide">' + hbars(top.map(([k, v]) => [k, v, v + '번']), Math.max(1, ...top.map((t) => t[1]))) + '</div></section></div></div>');
}

function dashCtrl(M) {
  const X = S.dash; const c = M.ctrl; const ver = S.data.cloud.version;
  const ask = (k, yes, label, cls) => X.ask === k
    ? '<button type="button" class="btn ' + (cls || 'danger') + '" data-act="' + yes + '">' + label + '</button><button type="button" class="btn" data-act="dashAskNo">아니요</button>'
    : '';
  const stopCard = '<section class="dcard ctl"><div class="dh">긴급 정지 ' + (c.stop_all ? '<span class="pill warn">켜짐</span>' : '<span class="pill ok">꺼짐</span>') + '</div>'
    + '<div class="sub" style="font-size:12.5px;line-height:1.6">켜면 모든 PC에서 진행 중인 예약이 1분 안에 멈추고, 새로 시작할 수 없어요. 사이트 문제나 규칙 변경이 있을 때 쓰세요. PC 한 대만 멈추려면 PC 현황 탭에서 하세요.</div>'
    + '<div style="display:flex;gap:8px;margin-top:auto">' + (X.ask === 'stopall' ? ask('stopall', 'dashStopAll', c.stop_all ? '정지 풀기' : '모두 정지', c.stop_all ? 'dark' : 'danger')
      : '<button type="button" class="btn ' + (c.stop_all ? 'dark' : 'danger') + '" data-act="dashAsk" data-v="stopall">' + (c.stop_all ? '정지 풀기' : '모든 PC 정지') + '</button>') + '</div></section>';
  const verCard = '<section class="dcard ctl"><div class="dh">최소 버전 ' + (c.min_version ? '<span class="pill limit">' + esc(c.min_version) + ' 이상</span>' : '<span class="pill gray">제한 없음</span>') + '</div>'
    + '<div class="sub" style="font-size:12.5px;line-height:1.6">이보다 낮은 버전의 PC는 "새 버전으로 업데이트해 주세요" 알림이 뜨고 예약을 시작할 수 없어요. 이 PC 버전: <b class="num">' + esc(ver) + '</b></div>'
    + '<div style="display:flex;gap:8px;margin-top:auto"><input id="dashminv" class="input" style="flex:1" placeholder="예: ' + esc(ver) + '" value="' + esc(X.minv) + '" data-input="dashMinv" data-enter="dashMinvSet" aria-label="최소 버전">'
    + '<button type="button" class="btn dark" data-act="dashMinvSet">적용</button>' + (c.min_version ? '<button type="button" class="btn" data-act="dashMinvClear">해제</button>' : '') + '</div></section>';
  const noteCard = '<section class="dcard ctl"><div class="dh">공지 보내기</div>'
    + '<div class="sub" style="font-size:12.5px;line-height:1.6">모든 PC의 알림(종)에 한 번 떠요. 꺼져 있던 PC는 다음에 켤 때 받아요.'
    + (c.notice ? '<div style="margin-top:8px;padding:10px 12px;background:var(--soft);border-radius:12px;color:var(--ink)"><b>지금 공지</b> · ' + esc(c.notice) + '</div>' : '') + '</div>'
    + '<div style="display:flex;gap:8px;margin-top:auto"><input id="dashnotice" class="input" style="flex:1" maxlength="300" placeholder="예: 이번 주 토요일 오픈은 10시 5분으로 바뀌었어요" value="' + esc(X.notice) + '" data-input="dashNotice" data-enter="dashNoticeSend" aria-label="공지 내용">'
    + '<button type="button" class="btn dark" data-act="dashNoticeSend">보내기</button>' + (c.notice ? '<button type="button" class="btn" data-act="dashNoticeClear">내리기</button>' : '') + '</div></section>';
  const mv = c.min_version || '';
  const cols = 'grid-template-columns:minmax(0,1.2fr) 80px 96px minmax(0,1.6fr)';
  const rows = M.pcs.map((p) => {
    const old = mv && vt(p.version) < vt(mv);
    const relV = (M.D.releases || [])[0];
    const behind = relV && vt(p.version) < vt(relV.version);
    const res = c.stop_all ? ['전체 정지로 막힘', 'warn'] : p.stopped ? ['이 PC만 정지', 'warn'] : old ? ['구버전이라 막힘', 'limit'] : behind ? [(relV.auto ? '업데이트 예정 → ' : '새 버전 알림 → ') + relV.version, 'wait'] : ['정상 사용', 'ok'];
    return '<div class="r" style="' + cols + ';align-items:center"><span><b style="font-size:13px">' + esc(p.pc || 'PC') + '</b></span><span class="num">' + esc(p.version || '—') + '</span>'
      + '<span><span class="pill ' + (p.online ? 'ok' : 'gray') + '">' + (p.online ? '켜짐' : '꺼짐 · ' + ago(p.last_seen)) + '</span></span><span><span class="pill ' + res[1] + '">' + res[0] + '</span></span></div>';
  }).join('');
  const applied = '<section class="dcard" style="padding-bottom:0"><div class="dh">PC별 적용 결과 <span class="sub" style="font-size:12px;font-weight:500">지금 제어 값으로 각 PC가 어떻게 되는지</span></div>'
    + '<div class="logtable" style="border:0;border-radius:0"><div class="hd" style="' + cols + '"><span>PC</span><span>버전</span><span>연결</span><span>결과</span></div><div style="flex:1 1 0;min-height:0;overflow-y:auto">' + (rows || '<div class="center-msg">아직 접속한 PC가 없어요</div>') + '</div></div></section>';
  const rels = M.D.releases || []; const top = rels[0];
  const relCard = '<section class="dcard ctl"><div class="dh">업데이트 배포 ' + (top ? '<span class="pill run">' + esc(top.version) + '</span>' : '<span class="pill gray">배포 없음</span>') + '</div>'
    + '<div class="sub" style="font-size:12.5px;line-height:1.6">이 PC의 프로그램(' + esc(ver) + ')을 모든 PC에 배포해요. 자동 적용이면 각 PC가 예약 중이 아닐 때 받아서 바꾸고 다시 시작해요(계정·기록·cloud.json은 그대로).'
    + (top ? '<br>마지막 배포 ' + whenK(top.created_at) + ' · ' + Math.round(top.size / 1024) + 'KB' + (top.notes ? ' · ' + esc(top.notes) : '') : '') + '</div>'
    + '<label class="sub" style="font-size:12.5px;display:flex;align-items:center;gap:6px"><input type="checkbox" data-act="dashRelAuto"' + (X.relAuto ? ' checked' : '') + '> 자동 적용(끄면 각 PC에 알림만)</label>'
    + '<input id="dashrel" class="input" style="margin-top:auto" maxlength="200" placeholder="바뀐 점(선택) · 각 PC 알림에 보여요" value="' + esc(X.relNotes) + '" data-input="dashRel" aria-label="바뀐 점">'
    + '<div style="display:flex;gap:8px;justify-content:flex-end">'
    + (X.ask === 'publish' ? '<button type="button" class="btn danger" data-act="dashPublish">배포</button><button type="button" class="btn" data-act="dashAskNo">아니요</button>'
      : '<button type="button" class="btn dark" data-act="dashAsk" data-v="publish"' + (top && vt(top.version) >= vt(ver) ? ' disabled title="이 PC 버전이 이미 배포돼 있어요"' : '') + '>' + esc(ver) + ' 배포</button>') + '</div></section>';
  return '<div class="ctlgrid">' + stopCard + verCard + noteCard + relCard + '</div>' + applied
    + '<div class="sub" style="font-size:12px">마지막 변경 ' + (c.updated_at ? whenK(c.updated_at) : '—') + ' · 제어 값은 각 PC가 1분마다 받아 가요 · 인터넷이 끊긴 PC는 마지막으로 받은 값을 그대로 지켜요</div>';
}

/* 예약 현황: 모든 PC 계정의 예약·장바구니(이번 달·다음 달). 관리자가 켜면 각 PC 홈 달력 '모임 일정'에 보임 */
const ACOL = ['#5F5AA6', '#2F8F5B', '#C2410C', '#2450C8', '#A21CAF', '#0E7490', '#B45309', '#BE123C'];
function dashCal(M) {
  const X = S.dash; const c = M.ctrl; const R = S.data.rules;
  const items = M.D.bookings || [];
  const accs = [...new Set(items.map((x) => x.account))].sort();
  const colA = (a) => ACOL[accs.indexOf(a) % ACOL.length];
  const k = kst(nowSrv()); const base = k.getUTCFullYear() * 12 + k.getUTCMonth() + X.calM;
  const Y = Math.floor(base / 12); const Mo = (base % 12) + 1; const pre = Y + '-' + pad(Mo);
  const inM = items.filter((x) => String(x.date).startsWith(pre));
  const first = new Date(Date.UTC(Y, Mo - 1, 1)).getUTCDay(); const nd = new Date(Date.UTC(Y, Mo, 0)).getUTCDate();
  const tk = todayKey();
  let cells = '';
  for (let i = 0; i < first; i++) cells += '<div></div>';
  for (let d = 1; d <= nd; d++) {
    const key = keyOf(Y, Mo, d); const xs = inM.filter((x) => x.date === key); const dw = (first + d - 1) % 7;
    const nr = xs.filter((x) => x.kind === 'res').length; const nc = xs.length - nr;
    const dots = [...new Set(xs.map((x) => x.account))].slice(0, 5).map((a) => '<i style="background:' + colA(a) + '"></i>').join('');
    cells += '<button type="button" class="dc' + (key === tk ? ' today' : '') + (X.calSel === key ? ' sel' : '') + '" data-act="dashCalSel" data-v="' + key + '"' + (dw === 0 || HOL[key] ? ' style="color:var(--red)"' : dw === 6 ? ' style="color:var(--blue)"' : '') + '>'
      + '<span class="n">' + d + '</span>' + (xs.length ? '<span class="cnt">' + (nr ? '예약 ' + nr : '') + (nr && nc ? ' · ' : '') + (nc ? '담김 ' + nc : '') + '</span><span class="dots">' + dots + '</span>' : '') + '</button>';
  }
  const sel = X.calSel && X.calSel.startsWith(pre) ? X.calSel : null;
  const list = (sel ? inM.filter((x) => x.date === sel) : inM);
  const KIND = (x) => (x.kind === 'cart' ? ['장바구니', 'limit'] : [RES_STATUS[String(x.status || '').toLowerCase()] || '예약', 'ok']);
  const cols = 'grid-template-columns:' + (sel ? '' : '44px ') + '86px 40px 66px minmax(0,1.5fr) minmax(0,1fr)';
  const rows = list.map((x) => { const kd = KIND(x); return '<div class="r" style="' + cols + ';align-items:center">' + (sel ? '' : '<span class="num">' + md(x.date).replace(/ \(.\)/, '') + '</span>')
    + '<span class="num">' + (x.start_min != null ? hm(x.start_min) + '~' + hm(x.end_min ?? x.start_min + 120) : '—') + '</span><span>' + (x.court ? x.court + '번' : '—') + '</span><span><span class="pill ' + kd[1] + '">' + kd[0] + '</span></span>'
    + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><span class="dot" style="display:inline-block;width:8px;height:8px;margin-right:6px;background:' + colA(x.account) + '"></span>' + esc(x.account) + '</span>'
    + '<span class="sub" style="font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(x.pc || '') + (x.synced_at ? ' · ' + ago(x.synced_at) : '') + '</span></div>'; }).join('');
  // 계정별 갱신 상태
  const fresh = accs.map((a) => { const xs = items.filter((x) => x.account === a); const at = xs.map((x) => x.synced_at).filter(Boolean).sort().pop();
    return '<div class="hbar" style="grid-template-columns:minmax(0,1fr) auto"><span class="l"><span class="dot" style="display:inline-block;width:8px;height:8px;margin-right:6px;background:' + colA(a) + '"></span>' + esc(a) + '</span><span class="t">' + xs.filter((x) => x.kind === 'res').length + '건 · ' + (at ? ago(at) : '—') + '</span></div>'; }).join('');
  const nR = inM.filter((x) => x.kind === 'res').length;
  const share = c.share_calendar;
  const pubBtn = X.ask === 'share'
    ? '<button type="button" class="btn ' + (share ? 'dark' : 'green') + ' sm" data-act="dashShare">' + (share ? '배포 중지' : '배포하기') + '</button><button type="button" class="btn sm" data-act="dashAskNo">아니요</button>'
    : '<button type="button" class="btn sm ' + (share ? '' : 'green') + '" data-act="dashAsk" data-v="share">' + (share ? '배포 중지' : '홈 달력에 배포') + '</button>';
  const monBtn = (v, l) => '<button type="button" data-act="dashCalM" data-v="' + v + '" aria-pressed="' + (X.calM === v) + '">' + l + '</button>';
  return '<div class="pubbar"><div class="tabs" role="group" aria-label="달">' + monBtn(0, '이번 달') + monBtn(1, '다음 달') + '</div>'
    + '<b style="font-size:15px">' + Y + '년 ' + Mo + '월</b><span class="sub" style="font-size:12.5px">예약 ' + nR + '건 · 장바구니 ' + (inM.length - nR) + '건 · 계정 ' + accs.length + '개</span>'
    + '<span style="margin-left:auto;display:flex;align-items:center;gap:8px"><span class="pill ' + (share ? 'run' : 'gray') + '">' + (share ? '홈 달력 배포 중' : '배포 안 함') + '</span>' + pubBtn + '</span></div>'
    + '<div class="dgrid" style="grid-template-columns:minmax(0,1fr) minmax(0,1.15fr)"><section class="dcard"><div class="dcal"><div style="color:var(--red)">일</div><div>월</div><div>화</div><div>수</div><div>목</div><div>금</div><div style="color:var(--blue)">토</div>' + cells + '</div>'
    + '<div class="sub" style="font-size:11.5px">점 색 = 계정 · 날짜를 누르면 오른쪽에 그날 내역 · 다시 누르면 그 달 전체</div></section>'
    + '<div class="dcol"><section class="dcard" style="flex:2 1 0"><div class="dh">' + (sel ? md(sel) + ' 내역' : Mo + '월 전체 내역') + ' <span class="sub" style="font-size:12px;font-weight:500">' + list.length + '건</span></div>'
    + '<div class="logtable" style="border:0;border-radius:0"><div class="hd" style="' + cols + '">' + (sel ? '' : '<span>날짜</span>') + '<span>시간</span><span>코트</span><span>상태</span><span>계정</span><span>PC·갱신</span></div>'
    + '<div style="flex:1 1 0;min-height:0;overflow-y:auto" data-keep-scroll="dashcal">' + (rows || '<div class="center-msg">' + (sel ? '이날은 예약·장바구니가 없어요' : '이 달은 아직 없어요') + '</div>') + '</div></div></section>'
    + '<section class="dcard" style="flex:1 1 0"><div class="dh">계정별 마지막 갱신</div><div class="scrolly">' + (fresh || '<div class="sub" style="font-size:12.5px">아직 올라온 내역이 없어요</div>') + '</div>'
    + '<div class="sub" style="font-size:11.5px">각 PC가 켜져 있고 로그인돼 있을 때 갱신돼요(바뀌면 1분 안, 아니면 10분마다)</div></section></div></div>';
}

/* ---------------------------------------------------------------- 동작 */
async function dashControl(patch, msg) {
  try {
    const j = await api('/api/admin/control', patch);
    if (S.dash.data) S.dash.data.control = j.control;
    S.dash.ask = ''; toast(msg); await poll(true); loadDash(true);
  } catch (e) { toast(e.message, true); }
}
Object.assign(H, {
  dashSub: (el) => { S.dash.sub = el.dataset.v; S.dash.ask = ''; render(); },
  dashReload: () => loadDash(false),
  dashTest: (el) => { S.dash.test = !S.dash.test; el.checked = S.dash.test; render(); },
  dashAsk: (el) => { S.dash.ask = el.dataset.v; render(); },
  dashAskNo: () => { S.dash.ask = ''; render(); },
  dashPcStop: (el) => {
    const id = el.dataset.v; const cur2 = new Set((S.dash.data.control || {}).stop_ids || []);
    const was = cur2.has(id); if (was) cur2.delete(id); else cur2.add(id);
    dashControl({ stop_ids: [...cur2] }, was ? '그 PC의 정지를 풀었어요' : '그 PC를 정지했어요 · 1분 안에 반영돼요');
  },
  dashIssue: async (el) => {
    try { const r = await fetch('/api/admin/issue?id=' + encodeURIComponent(el.dataset.v), { cache: 'no-store' }); const j = await r.json(); if (!r.ok) throw new Error(j.error || '불러오기 실패'); S.dash.issue = j; } catch (e) { toast(e.message, true); }
    render();
  },
  dashIssueClose: () => { S.dash.issue = null; render(); },
  dashRelAuto: (el) => { S.dash.relAuto = !S.dash.relAuto; el.checked = S.dash.relAuto; render(); },
  dashPublish: async () => {
    S.dash.ask = ''; toast('묶어서 올리는 중…');
    try { await api('/api/admin/publish', { notes: S.dash.relNotes, auto: S.dash.relAuto }); S.dash.relNotes = ''; toast('배포했어요 · 각 PC가 1분 안에 받아요'); loadDash(true); } catch (e) { toast(e.message, true); render(); }
  },
  dashCalM: (el) => { S.dash.calM = Number(el.dataset.v); S.dash.calSel = null; render(); },
  dashCalSel: (el) => { S.dash.calSel = S.dash.calSel === el.dataset.v ? null : el.dataset.v; render(); },
  dashShare: () => { const on = !(S.dash.data.control || {}).share_calendar; dashControl({ share_calendar: on }, on ? '모임 일정을 모든 PC 홈 달력에 배포했어요 · 1분 안에 보여요' : '홈 달력 배포를 멈췄어요'); },
  dashStopAll: () => { const on = !(S.dash.data.control || {}).stop_all; dashControl({ stop_all: on }, on ? '모든 PC를 정지했어요 · 1분 안에 반영돼요' : '전체 정지를 풀었어요'); },
  dashMinvSet: () => { S.dash.minvTouched = false; dashControl({ min_version: S.dash.minv.trim() }, S.dash.minv.trim() ? '최소 버전을 정했어요' : '최소 버전 제한을 없앴어요'); },
  dashMinvClear: () => { S.dash.minv = ''; S.dash.minvTouched = false; dashControl({ min_version: '' }, '최소 버전 제한을 없앴어요'); },
  dashNoticeSend: () => { const t = S.dash.notice.trim(); if (!t) { toast('공지 내용을 적어 주세요', true); return; } S.dash.notice = ''; dashControl({ notice: t }, '공지를 보냈어요'); },
  dashNoticeClear: () => dashControl({ notice: '' }, '공지를 내렸어요'),
  dashForget: async (el) => { try { await api('/api/admin/forget', { id: el.dataset.v }); toast('목록에서 지웠어요'); loadDash(true); } catch (e) { toast(e.message, true); } },
});
document.addEventListener('input', (ev) => {
  const el = ev.target;
  if (el.dataset.input === 'dashNotice') S.dash.notice = el.value;
  if (el.dataset.input === 'dashRel') S.dash.relNotes = el.value;
  if (el.dataset.input === 'dashMinv') { S.dash.minv = el.value; S.dash.minvTouched = true; }
});
setInterval(() => { if (S.route === 'settings' && S.set.tab === 'admin' && S.data && S.data.admin.ok && Date.now() - S.dash.at > 60e3) loadDash(true); }, 5e3);
