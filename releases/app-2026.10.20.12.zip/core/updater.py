"""자동 업데이트: 프로그램 파일 묶기(관리자) · 검증 · 백업 · 적용(각 PC).

- 묶는 파일은 아래 ALLOWED 목록뿐. data 폴더(계정·로그인·기록), cloud.json, 시작.bat은 묶지도 덮어쓰지도 않는다.
  (시작.bat은 실행 중에 바꾸면 Windows가 엉뚱한 줄을 실행할 수 있어서 제외)
- 적용 전: sha256 확인 → 파일 이름 검사 → app.py의 VERSION이 배포 버전과 같은지 확인 → 지금 파일을 data/backup/에 zip으로 백업.
"""
from __future__ import annotations

import base64
import hashlib
import io
import re
import zipfile
from datetime import datetime
from pathlib import Path

ALLOWED = re.compile(r"^(app\.py|requirements\.txt|README\.md|PROGRESS\.md|cloud\.example\.json|"
                     r"core/[a-z_]+\.py|static/[a-z_]+\.(js|css|html)|supabase/[a-z_]+\.sql|tests/[a-z_]+\.py)$")
MAX_SIZE = 5_000_000


class UpdateError(Exception):
    pass


def program_files(root: Path) -> list[str]:
    out = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            rel = p.relative_to(root).as_posix()
            if ALLOWED.match(rel):
                out.append(rel)
    return out


def build_package(root: Path) -> tuple[bytes, str]:
    """관리자 PC의 프로그램 파일을 zip으로. (zip 바이트, sha256)"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in program_files(root):
            z.write(root / rel, rel)
    raw = buf.getvalue()
    if len(raw) > MAX_SIZE:
        raise UpdateError("묶음이 너무 커요")
    return raw, hashlib.sha256(raw).hexdigest()


def version_in(app_source: str) -> str:
    m = re.search(r'^VERSION\s*=\s*"([0-9.]+)"', app_source, re.M)
    return m[1] if m else ""


def verify(raw: bytes, sha256: str, version: str) -> list[str]:
    if len(raw) > MAX_SIZE:
        raise UpdateError("묶음이 너무 커요")
    if hashlib.sha256(raw).hexdigest() != (sha256 or "").lower():
        raise UpdateError("받은 파일이 손상됐어요(해시 불일치)")
    try:
        z = zipfile.ZipFile(io.BytesIO(raw))
    except zipfile.BadZipFile:
        raise UpdateError("zip 형식이 아니에요") from None
    names = [i.filename for i in z.infolist() if not i.is_dir()]
    bad = [n for n in names if not ALLOWED.match(n)]
    if bad:
        raise UpdateError(f"허용되지 않은 파일이 들어 있어요: {bad[0][:60]}")
    if "app.py" not in names:
        raise UpdateError("app.py가 없어요")
    if version_in(z.read("app.py").decode("utf-8", "replace")) != version:
        raise UpdateError("묶음 안 버전이 배포 버전과 달라요")
    return names


def backup(root: Path, folder: Path, tag: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{re.sub(r'[^0-9A-Za-z.]', '_', tag)}_{datetime.now():%Y%m%d-%H%M%S}.zip"
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in program_files(root):
            z.write(root / rel, rel)
    olds = sorted(folder.glob("*.zip"))
    for old in olds[:-5]:                     # 백업은 최근 5개만
        try:
            old.unlink()
        except OSError:
            pass
    return path


def apply(root: Path, raw: bytes, sha256: str, version: str, backup_dir: Path, current: str) -> dict:
    names = verify(raw, sha256, version)
    bk = backup(root, backup_dir, current)
    z = zipfile.ZipFile(io.BytesIO(raw))
    written = []
    for n in names:
        dest = (root / n).resolve()
        if root.resolve() not in dest.parents:
            raise UpdateError("잘못된 경로")
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".new")
        tmp.write_bytes(z.read(n))
        tmp.replace(dest)
        written.append(n)
    return {"files": len(written), "backup": bk.name}


def to_b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def from_b64(text: str) -> bytes:
    return base64.b64decode(text or "", validate=True)
