"""사이트 규칙과 입력 검증. 통신이 없는 순수 함수만 둔다(테스트 대상).

근거(2026-10-13 사이트 관찰):
- 공지 '사이트 예약일정 변경안내': 20일 10시 평일 06~18시, 20일 20시 평일 18~22시, 23일 10시 주말.
- 공지 '하루 예약 건 수 제한'(2026-04-02): 만든 날 기준 하루 5건, 자정 초기화.
- 장바구니 화면 규칙 상자: 같은 날짜 대상으로 최대 3개.
- 5·6번 코트는 평일 16시 이후 레슨용(평일 06~16시만 예약 가능).
값은 settings.json에서 바꿀 수 있고, API가 공개 시각을 주면 그 값을 우선한다.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import date, datetime, timedelta, timezone
import uuid

KST = timezone(timedelta(hours=9))
TENANT = "songdo-tennis"

# 이 프로그램이 부를 수 있는 서버 함수의 전부. 예약 생성·확정·취소·전체 비우기는 없다.
ALLOWED_QUERIES = frozenset({
    "facilities/queries:listByTenantSlug",
    "slots/queries:listByFacilityAndDatePublic",
    "slots/queries:getMonthSlotCountsPublic",
    "slotOpenRules/queries:getNextOpenForMonth",
    "slotReleaseWindows/queries:getEffectiveForMonth",
    "tenantAnnouncements/queries:listByTenantSlug",
    "users/queries:currentUser",                      # 내 프로필(이름·이메일만 사용, 나머지는 버림)   # 공지(팝업 공지 ID를 알아 로그인 창에서 '오늘 하루 보지 않기' 처리)
    "cart/queries:list",
    "cart/queries:listMySlotIds",
    "reservations/queries:listMyReservationsPaginated",
})
ALLOWED_MUTATIONS = frozenset({"cart/mutations:add", "cart/mutations:remove"})
FORBIDDEN_HINTS = ("createFromSlots", "createOnBehalfOf", "cancelMyReservation", "cart/mutations:clear",
                   "OnBehalfOf", "captcha")


def check_allowed(kind: str, path: str) -> None:
    if any(h in path for h in FORBIDDEN_HINTS):
        raise PermissionError(f"금지된 서버 함수입니다: {path}")
    allowed = ALLOWED_QUERIES if kind == "query" else ALLOWED_MUTATIONS if kind == "mutation" else frozenset()
    if path not in allowed:
        raise PermissionError(f"허용 목록에 없는 서버 함수입니다: {kind} {path}")


DEFAULT_RULES = {
    "daily_create_limit": 5,
    "per_date_limit": 3,
    "courts": list(range(5, 18)),
    "weekday_evening_blocked_courts": {"courts": [5, 6], "from_minute": 960},
    # 대회 막힘(사이트 공지). all = 전 코트 대회(06·08시 시작만 가능), part = 5~14번 대회(15~17번 가능)
    "blocks": {"2026-10-17": "all", "2026-10-21": "all", "2026-10-23": "part", "2026-10-24": "all", "2026-10-25": "part"},
    "open_events": [
        {"key": "weekday_day", "name": "평일 주간", "day": 20, "time": "10:00", "days": "weekday", "from": 360, "to": 1080},
        {"key": "weekday_evening", "name": "평일 저녁", "day": 20, "time": "20:00", "days": "weekday", "from": 1080, "to": 1440},
        {"key": "weekend", "name": "주말", "day": 23, "time": "10:00", "days": "weekend", "from": 0, "to": 1440},
    ],
}

MAX_TARGETS = 5          # 계정당 예약 목표 최대 개수
COURT_KIND = {**{c: "하드" for c in range(5, 9)}, **{c: "잔디" for c in range(9, 15)}, **{c: "클레이" for c in range(15, 18)}}
BLOCK_NOTE = {"all": "전 코트 대회 · 06·08시만 예약 가능", "part": "5~14번 대회 · 15~17번만 예약 가능"}

SLOT_STARTS = list(range(360, 1201, 120))  # 06:00~20:00 시작(2시간, 22시 종료). 서버 응답이 다르면 서버를 따른다.


def hm(minute: int) -> str:
    return f"{minute // 60:02d}:{minute % 60:02d}"


def parse_date(value: str) -> date:
    try:
        d = datetime.strptime(str(value), "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError("날짜는 YYYY-MM-DD 형식이어야 합니다.") from exc
    return d


def open_event_for(d: date, start_minute: int, rules: dict = DEFAULT_RULES) -> dict:
    """이용일·시작 시각이 어느 오픈에 열리는지와 그 시각(KST)을 계산."""
    weekend = d.weekday() >= 5
    for ev in rules["open_events"]:
        if (ev["days"] == "weekend") != weekend:
            continue
        if ev["from"] <= start_minute < ev["to"]:
            first = d.replace(day=1)
            prev_month_last = first - timedelta(days=1)
            h, m = map(int, ev["time"].split(":"))
            at = datetime(prev_month_last.year, prev_month_last.month, ev["day"], h, m, tzinfo=KST)
            return {"key": ev["key"], "name": ev["name"], "at": at}
    raise ValueError("이 시간대가 열리는 오픈 규칙을 찾지 못했습니다.")


def price(start_minute: int) -> int:
    return 7500 if start_minute == 360 or start_minute >= 1080 else 5000


def block_rules(v) -> list[dict]:
    """날짜의 대회 막힘 → 막힘 목록. 예전 형식('all'/'part')도 받는다."""
    if v == "all":
        return [{"courts": list(range(5, 18)), "from": 600, "to": 1440, "note": BLOCK_NOTE["all"]}]
    if v == "part":
        return [{"courts": list(range(5, 15)), "from": 0, "to": 1440, "note": BLOCK_NOTE["part"]}]
    return [r for r in v if isinstance(r, dict)] if isinstance(v, list) else []


def tour_blocked(rules: dict, iso: str, court: int, start_minute: int) -> dict | None:
    for r in block_rules((rules.get("blocks") or {}).get(iso)):
        if court in r.get("courts", ()) and start_minute < r.get("to", 1440) and start_minute + 120 > r.get("from", 0):
            return r
    return None


def court_blocked(d: date, court: int, start_minute: int, rules: dict = DEFAULT_RULES) -> str | None:
    if court not in rules["courts"]:
        return f"{court}번 코트는 온라인 예약 대상이 아닙니다."
    r = tour_blocked(rules, d.isoformat(), court, start_minute)
    if r:
        return f"{d.isoformat()} {r.get('note') or '대회'}"
    blk = rules["weekday_evening_blocked_courts"]
    if d.weekday() < 5 and court in blk["courts"] and start_minute >= blk["from_minute"]:
        return f"{court}번 코트는 평일 16시 이후 레슨용입니다."
    return None


@dataclass
class Target:
    account: str
    date: str
    court: int
    start: int            # 시작 분(자정 기준)
    priority: int = 0     # 작을수록 먼저
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])

    @property
    def key(self) -> tuple:
        return (self.date, self.court, self.start)

    @property
    def label(self) -> str:
        return f"{self.date} {self.court}번 {hm(self.start)}"

    def to_dict(self) -> dict:
        return asdict(self)


def parse_target(raw: dict, accounts: set[str], rules: dict = DEFAULT_RULES) -> Target:
    if not isinstance(raw, dict) or raw.get("account") not in accounts:
        raise ValueError("등록된 계정을 선택하세요.")
    d = parse_date(raw.get("date", ""))
    try:
        court, start = int(raw["court"]), int(raw["start"])
        priority = int(raw.get("priority", 0))
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("코트·시간을 확인하세요.") from exc
    if not 0 <= start < 1440:
        raise ValueError("시작 시각이 올바르지 않습니다.")
    if (why := court_blocked(d, court, start, rules)):
        raise ValueError(why)
    open_event_for(d, start, rules)
    return Target(account=raw["account"], date=d.isoformat(), court=court, start=start, priority=priority, id=str(raw.get("id") or uuid.uuid4().hex[:10]))


def validate_targets(raw: list, accounts: set[str], today: date | None = None, rules: dict = DEFAULT_RULES) -> list[Target]:
    if not isinstance(raw, list) or len(raw) > 200:
        raise ValueError("목표는 200개 이하로 등록하세요.")
    targets = [parse_target(r, accounts, rules) for r in raw]
    today = today or datetime.now(KST).date()
    per: dict[str, int] = {}
    for t in targets:
        per[t.account] = per.get(t.account, 0) + 1
        if per[t.account] > MAX_TARGETS:
            raise ValueError(f"'{t.account}' 계정의 예약 목표는 최대 {MAX_TARGETS}개입니다.")
    owner: dict[tuple, str] = {}
    for t in targets:
        if t.date < today.isoformat():
            raise ValueError(f"{t.label}: 지난 날짜입니다.")
        if t.key in owner and owner[t.key] != t.account:
            raise ValueError(f"{t.label}: 같은 슬롯이 '{owner[t.key]}' 계정에도 있습니다. 한 계정에만 지정하세요.")
        if t.key in owner:
            raise ValueError(f"{t.label}: 같은 계정에 중복 등록되었습니다.")
        owner[t.key] = t.account
    return targets


def slot_available(slot: dict) -> bool | None:
    """True=담을 수 있음, False=불가, None=응답이 불완전해 판단 불가."""
    flags = ("isBooked", "isPast", "cartHeldByAnyone")
    if not isinstance(slot, dict) or not all(isinstance(slot.get(k), bool) for k in flags):
        return None
    return not any(slot[k] for k in flags)


def is_cancelled(status: str | None) -> bool:
    return bool(status) and any(w in str(status).lower() for w in ("cancel", "취소", "expired", "reject"))


def capacity(reservations: list[dict], cart: list[dict], today: date, target_date: str, rules: dict = DEFAULT_RULES) -> dict:
    """계정의 남은 한도. 둘 다 장바구니 포함(사용자 결정: 확정 기준 보수적 관리).

    reservations: {date, createdAt(ms), status}; cart: {date}
    """
    def created_today(r):
        ms = r.get("createdAt") or r.get("_creationTime")
        return isinstance(ms, (int, float)) and datetime.fromtimestamp(ms / 1000, KST).date() == today

    live = [r for r in reservations if not is_cancelled(r.get("status"))]
    daily_used = sum(1 for r in live if created_today(r)) + len(cart)
    date_used = sum(1 for r in live if r.get("date") == target_date) + sum(1 for c in cart if c.get("date") == target_date)
    return {"daily_used": daily_used, "daily_left": max(0, rules["daily_create_limit"] - daily_used),
            "date_used": date_used, "date_left": max(0, rules["per_date_limit"] - date_used)}
