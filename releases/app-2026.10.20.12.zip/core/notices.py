"""사이트 공지(tenantAnnouncements/queries:listByTenantSlug, 공개 조회)를 화면용으로 정리.

사이트가 공지를 바꾸면 홈의 '사이트 공지'도 따라 바뀌게 한다. 공지 항목 이름은 사이트가 바꿀 수 있어서
흔히 쓰는 이름을 두루 살펴본다(title/subject, content/body, createdAt, isPinned 등).
"""
from __future__ import annotations

import html
import re
from datetime import datetime

from .rules import KST

TITLE = ("title", "subject", "name", "headline")
BODY = ("content", "body", "text", "description", "message", "contents")
DATE = ("publishedAt", "postedAt", "startAt", "startsAt", "createdAt", "updatedAt", "_creationTime")
PINNED = ("isPinned", "pinned", "isFixed", "fixed", "isImportant", "important", "isNotice", "isTop")
HIDDEN = (("isActive", False), ("active", False), ("isPublished", False), ("published", False), ("isVisible", False),
          ("visible", False), ("isDeleted", True), ("deleted", True), ("isHidden", True))
CATEGORY = ("category", "type", "label", "tag", "badge")


def _first(d: dict, keys):
    for k in keys:
        v = d.get(k)
        if v not in (None, "", []):
            return v
    return None


def _text(v) -> str:
    """문자열·HTML·리치 텍스트(JSON 블록) 모두 글자만."""
    if v is None:
        return ""
    if isinstance(v, (list, tuple)):
        return "\n".join(t for t in (_text(x) for x in v) if t)
    if isinstance(v, dict):
        if isinstance(v.get("text"), str):
            return v["text"]
        for k in ("children", "content", "blocks", "root", "ops", "insert"):
            if k in v:
                return _text(v[k])
        return ""
    s = str(v)
    s = re.sub(r"(?i)<br\s*/?>|</p>|</div>|</li>|</h\d>", "\n", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t ]+", " ", s)
    return re.sub(r"\n\s*\n+", "\n", s).strip()


def _date(v) -> tuple[str, float]:
    """(화면용 'YY.MM.DD', 정렬용 초)"""
    ts = None
    if isinstance(v, (int, float)):
        ts = v / 1000 if v > 1e11 else float(v)
    elif isinstance(v, str):
        try:
            ts = datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
        except ValueError:
            m = re.match(r"(\d{4})-(\d{2})-(\d{2})", v)
            if m:
                ts = datetime(int(m[1]), int(m[2]), int(m[3]), tzinfo=KST).timestamp()
    if ts is None:
        return "", 0.0
    d = datetime.fromtimestamp(ts, KST)
    return d.strftime("%y.%m.%d"), ts


def normalize(raw, now: float | None = None) -> list[dict]:
    out = []
    now = now or datetime.now(KST).timestamp()
    for a in raw if isinstance(raw, list) else []:
        if not isinstance(a, dict):
            continue
        if any(a.get(k) is v for k, v in HIDDEN):
            continue
        end = _date(_first(a, ("endAt", "endsAt", "expiresAt", "until")))[1]
        if end and end < now:
            continue
        title = _text(_first(a, TITLE))
        body = _text(_first(a, BODY))
        if not title and not body:
            continue
        if not title:
            title = body.split("\n", 1)[0][:40]
        date, ts = _date(_first(a, DATE))
        pinned = any(bool(a.get(k)) for k in PINNED) or (isinstance(a.get("priority"), (int, float)) and a["priority"] > 0)
        cat = _first(a, CATEGORY)
        badge = "고정" if pinned else (str(cat)[:6] if isinstance(cat, str) and cat else ("팝업" if a.get("isPopup") else "공지"))
        out.append({"id": str(a.get("_id", "")), "title": title[:80], "body": body[:2000], "date": date, "ts": ts,
                    "badge": badge, "pinned": pinned, "popup": bool(a.get("isPopup"))})
    out.sort(key=lambda n: (not n["pinned"], -n["ts"]))
    return out[:10]


def field_names(raw) -> str:
    """기록용: 공지 항목 이름만(내용은 남기지 않음)."""
    keys = set()
    for a in raw if isinstance(raw, list) else []:
        if isinstance(a, dict):
            keys.update(a.keys())
    return ",".join(sorted(keys))[:300]
