"""사이트 공지 속 '대회 일정'을 읽어 날짜별 막힌 코트·시간으로 바꾼다.

공지는 사람이 쓰는 글이라 형식이 매번 조금씩 다르다. 아래처럼 흔한 표현만 알아듣는다.
  - 2,3일 ... (오전 9~18시) 9면 (새벽예약가능, 저녁 6시 이후예약가능, 클레이는 전시간 예약가능)
  - 13,14,15일 카타 전국 대회 전 코트 사용(새벽 예약 가능)
  - 22일 ... (5~8번만 12~18시만 사용) 나머지 시간은 예약 가능
  - 28일 ... (새벽만 예약 가능)
  - 10월 ,21,23,24,25(새벽은 예약가능,23일25일은 클레이는 예약가능)
해석 규칙
  - 코트: 'A~B번' → 그 코트, 'N면'만 있으면 클레이를 뺀 5~14번, 그 밖엔 전 코트(5~17번)
  - 시간: 'H~H시'가 있으면 그 시간, 없으면 하루 종일. '새벽(만) 예약 가능'은(시간이 따로 없을 때) 06·08시 시작은 가능
  - '저녁 N시 이후 예약가능' → 그 시각부터는 가능, '클레이 ... 가능' → 15~17번은 가능(괄호 안에 날짜가 있으면 그 날짜만)
막힘 하나 = {"courts": [...], "from": 분, "to": 분, "note": 요약, "src": 공지 원문 줄}
2시간 칸 [시작, 시작+120)이 [from, to)와 겹치고 코트가 courts에 있으면 막힌 칸.
"""
from __future__ import annotations

import re
from datetime import date, datetime

from .notices import _text
from .rules import KST

ALL = list(range(5, 18))
NONCLAY = list(range(5, 15))
CLAY = {15, 16, 17}
DAY_FROM, DAY_TO = 0, 1440
DAWN_OK_UNTIL = 600            # '새벽 예약 가능' = 06·08시 시작은 가능(예전 고정 규칙과 같게)

_LEAD = re.compile(r"^[\s\-–·•*>]+")
_DAYS = re.compile(r"^(?:(\d{1,2})\s*월)?[\s,]*((?:\d{1,2}\s*일?\s*[,~·.]\s*)*\d{1,2})\s*(일)?")
_SLASH = re.compile(r"^(\d{1,2})\s*/\s*((?:\d{1,2}\s*[,~]\s*)*\d{1,2})(?!\d)")
_COURTS = re.compile(r"(\d{1,2})\s*~\s*(\d{1,2})\s*번")
_TIME = re.compile(r"(오전|오후)?\s*(\d{1,2})\s*시?\s*~\s*(오전|오후)?\s*(\d{1,2})\s*시")
_EVENING = re.compile(r"저녁\s*(\d{1,2})\s*시\s*(?:이후|부터)[^,)]*가능")
_CLAY_OK = re.compile(r"클레이[^,)]*가능")
_MONTH_CTX = re.compile(r"(\d{1,2})\s*월\s*(?:대회|대회\s*일정|대회\s*공지)")


def _ts(v) -> float | None:
    if isinstance(v, (int, float)) and v > 0:
        return v / 1000 if v > 1e11 else float(v)
    return None


def _year(month: int, ref: date) -> int:
    if month < ref.month - 6:
        return ref.year + 1
    if month > ref.month + 6:
        return ref.year - 1
    return ref.year


def _days(spec: str) -> list[int]:
    out = []
    spec = spec.replace("일", "")
    for part in re.split(r"[,·.]", spec):
        part = part.strip()
        if not part:
            continue
        if "~" in part:
            a, _, b = part.partition("~")
            if a.strip().isdigit() and b.strip().isdigit() and int(a) <= int(b) <= 31:
                out += list(range(int(a), int(b) + 1))
        elif part.isdigit():
            out.append(int(part))
    return [d for d in out if 1 <= d <= 31]


def _hour(ampm: str | None, h: int) -> int:
    return h + 12 if ampm == "오후" and h < 12 else h


def _label(courts: list[int]) -> str:
    if courts == ALL:
        return "전 코트"
    if courts == list(range(courts[0], courts[-1] + 1)):
        return f"{courts[0]}~{courts[-1]}번"
    return ",".join(map(str, courts)) + "번"


def _hm(m: int) -> str:
    return f"{m // 60:02d}"


def summary(courts: list[int], frm: int, to: int) -> str:
    if frm == DAWN_OK_UNTIL and to >= 1320:
        return f"{_label(courts)} 대회 · 06·08시 시작만 가능"
    if frm <= 360 and to >= 1320:
        t = "종일"
    else:
        t = f"{_hm(max(frm, 360))}~{_hm(min(to, 1320))}시"
    return f"{_label(courts)} {t} 대회"


def parse_line(line: str, month_ctx: int | None) -> tuple[int | None, list[int], list[dict]] | None:
    """한 줄 → (월, 날짜들, 막힘 목록[날짜별 다를 수 있어 (날짜, 막힘)]) · 날짜 줄이 아니면 None."""
    line = _LEAD.sub("", line).strip()
    line = _SLASH.sub(r"\1월 \2일", line)          # 11/7,8 → 11월 7,8일
    main = re.sub(r"\([^)]*\)?", " ", line)
    m = _DAYS.match(main)
    if not m or not (m[1] or m[3]):
        return None
    month = int(m[1]) if m[1] else month_ctx
    days = _days(m[2])
    if not month or not 1 <= month <= 12 or not days:
        return None
    rest = line[m.end():] if not m[1] else line
    cm = _COURTS.search(rest)
    if cm and 5 <= int(cm[1]) <= int(cm[2]) <= 17:
        courts = list(range(int(cm[1]), int(cm[2]) + 1))
    elif re.search(r"\d+\s*면", rest) and "전 코트" not in rest and "전코트" not in rest:
        courts = list(NONCLAY)
    else:
        courts = list(ALL)
    frm, to, timed = DAY_FROM, DAY_TO, False
    tm = _TIME.search(_COURTS.sub(" ", rest))
    if tm:
        a, b = _hour(tm[1], int(tm[2])), _hour(tm[3] or tm[1], int(tm[4]))
        if b <= a and b < 12:
            b += 12
        if 0 <= a < b <= 24:
            frm, to, timed = a * 60, b * 60, True
    if not timed and re.search(r"새벽\s*(?:은|는)?\s*(?:만)?\s*예약\s*(?:만)?\s*가능|새벽\s*만", rest):
        frm = max(frm, DAWN_OK_UNTIL)
    em = _EVENING.search(rest)
    if em:
        to = min(to, _hour("오후", int(em[1])) * 60)
    clay_days: set[int] | None = None          # None = 클레이 예외 없음, 빈 집합 = 모든 날짜
    for seg in [s for s in re.findall(r"\(([^)]*)\)?", line)] + [main]:
        for piece in re.split(r",", seg):
            if _CLAY_OK.search(piece):
                ds = {int(x) for x in re.findall(r"(\d{1,2})\s*일", piece)}
                clay_days = (clay_days or set()) | ds if ds else set()
                if not ds:
                    break
    out = []
    for d in days:
        cs = courts
        if clay_days is not None and (not clay_days or d in clay_days):
            cs = [c for c in courts if c not in CLAY]
        if cs and frm < to:
            out.append({"day": d, "courts": cs, "from": frm, "to": to})
    return month, days, out


def parse(raw, today: date | None = None) -> tuple[dict, list[str]]:
    """공지 원본 목록 → ({'YYYY-MM-DD': [막힘, ...]}, 해석하지 못한 대회 공지 제목들)"""
    today = today or datetime.now(KST).date()
    blocks: dict[str, list[dict]] = {}
    missed = []
    for a in raw if isinstance(raw, list) else []:
        if not isinstance(a, dict) or a.get("isDeleted") or a.get("isActive") is False:
            continue
        title = _text(a.get("title"))
        body = _text(a.get("content") or a.get("body"))
        if "대회" not in title + body:
            continue
        ts = _ts(a.get("updatedAt")) or _ts(a.get("createdAt")) or _ts(a.get("_creationTime"))
        ref = datetime.fromtimestamp(ts, KST).date() if ts else today
        mc = _MONTH_CTX.search(title)
        month_ctx = int(mc[1]) if mc else None
        found = 0
        for line in body.split("\n"):
            c = _MONTH_CTX.search(line)
            if c:
                month_ctx = int(c[1])
            r = parse_line(line, month_ctx)
            if not r:
                continue
            month, _, rows = r
            src = _LEAD.sub("", line).strip()[:120]
            for row in rows:
                try:
                    d = date(_year(month, ref), month, row["day"])
                except ValueError:
                    continue
                found += 1
                if not -7 <= (d - today).days <= 150:
                    continue
                blocks.setdefault(d.isoformat(), []).append(
                    {"courts": row["courts"], "from": row["from"], "to": row["to"],
                     "note": summary(row["courts"], row["from"], row["to"]), "src": src})
        if not found and re.search(r"\d+\s*일", body) and re.search(r"대회\s*(?:일정|공지)", title + body):
            missed.append(title[:40])
    return blocks, missed
