"""PC 시계와 사이트 서버 시계의 차이 재기.

서버 응답의 Date 헤더(초 단위)를 몇 번 받아, 요청을 보낸 시각·받은 시각과 겹치는 범위를 좁혀 오차를 구한다.
  서버 시각 = PC 시각 + offset
한 번 잴 때 가벼운 GET 요청 8번(0.25초 간격, 약 2초). 사이트 함수는 부르지 않는다.
"""
from __future__ import annotations

import time
from email.utils import parsedate_to_datetime

import requests

SAMPLES = 8
GAP = 0.25
MAX_OFFSET = 300.0          # 이보다 크면 측정이 잘못된 것으로 본다


def _sample(session, url: str, timeout: float = 3.0):
    t0 = time.time()
    r = session.get(url, timeout=timeout, allow_redirects=False)
    t1 = time.time()
    d = r.headers.get("Date")
    if not d:
        return None
    return t0, t1, parsedate_to_datetime(d).timestamp()


def measure(url: str, session=None, samples: int = SAMPLES, gap: float = GAP, sample=None, sleep=time.sleep) -> dict | None:
    """{'offset': 초, 'error': ±초, 'rtt': 평균 왕복 초, 'n': 표본 수}. 실패하면 None."""
    session = session or requests.Session()
    take = sample or (lambda: _sample(session, url))
    lo, hi, rtts, mids = -1e9, 1e9, [], []
    for i in range(samples):
        if i:
            sleep(gap)
        try:
            s = take()
        except (requests.RequestException, ValueError, TypeError):
            continue
        if not s:
            continue
        t0, t1, d = s
        if t1 < t0 or t1 - t0 > 3:
            continue
        # 서버가 Date를 찍은 순간 s는 PC 시각 [t0, t1] 사이, 서버 시각 [d, d+1) 사이 → offset ∈ [d - t1, d + 1 - t0]
        lo, hi = max(lo, d - t1), min(hi, d + 1 - t0)
        rtts.append(t1 - t0)
        mids.append(d + 0.5 - (t0 + t1) / 2)
    if not rtts:
        return None
    if lo <= hi:
        off, err = (lo + hi) / 2, (hi - lo) / 2
    else:                                   # 범위가 어긋나면(서버 여러 대 등) 가운데 값으로
        mids.sort()
        off, err = mids[len(mids) // 2], 0.5 + max(rtts) / 2
    if abs(off) > MAX_OFFSET:
        return None
    return {"offset": round(off, 3), "error": round(err, 3), "rtt": round(sum(rtts) / len(rtts), 3), "n": len(rtts)}


def describe(offset: float) -> str:
    """사람이 읽는 말: PC 시계가 서버보다 n초 빠름/느림."""
    a = abs(offset)
    if a < 0.05:
        return "PC 시계가 사이트와 맞아요"
    return f"PC 시계가 사이트보다 {a:.1f}초 {'느려요' if offset > 0 else '빨라요'}"
