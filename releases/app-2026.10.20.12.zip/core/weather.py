"""날씨(Open-Meteo, 무료·키 없음, 비상업 이용 · CC-BY 4.0 출처 표시).

송도국제도시 좌표의 지금 날씨 + 16일 일별·시간별(06~22시) 예보를 30분마다 받아 data/weather.json에 보관한다.
받지 못하면 마지막으로 받은 것을 그대로 쓰고 10분 뒤 다시 시도한다.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import requests

URL = "https://api.open-meteo.com/v1/forecast"
LAT, LON = 37.389, 126.645           # 송도국제도시(송도 테니스장 근처)
REFRESH = 1800
RETRY = 600
HOURS = range(6, 23)                  # 코트 이용 시간대만 보관
PARAMS = {
    "latitude": LAT, "longitude": LON, "timezone": "Asia/Seoul", "forecast_days": 16, "wind_speed_unit": "ms",
    "current": "temperature_2m,apparent_temperature,weather_code,precipitation,wind_speed_10m",
    "hourly": "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m",
    "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum",
}


def _num(v, nd=1):
    return round(float(v), nd) if isinstance(v, (int, float)) else None


def normalize(raw: dict, now: float | None = None) -> dict:
    """Open-Meteo 응답 → 화면용 작은 형태."""
    cur = raw.get("current") or {}
    out = {"at": now or time.time(), "source": "Open-Meteo",
           "current": {"time": cur.get("time"), "temp": _num(cur.get("temperature_2m")), "feels": _num(cur.get("apparent_temperature")),
                       "code": cur.get("weather_code"), "rain": _num(cur.get("precipitation")), "wind": _num(cur.get("wind_speed_10m"))},
           "days": {}, "hours": {}}
    d = raw.get("daily") or {}
    for i, day in enumerate(d.get("time") or []):
        g = lambda k: (d.get(k) or [None] * (i + 1))[i] if i < len(d.get(k) or []) else None
        out["days"][day] = {"code": g("weather_code"), "tmax": _num(g("temperature_2m_max")), "tmin": _num(g("temperature_2m_min")),
                            "pop": g("precipitation_probability_max"), "rain": _num(g("precipitation_sum"))}
    h = raw.get("hourly") or {}
    for i, t in enumerate(h.get("time") or []):
        try:
            hour = int(str(t)[11:13])
        except ValueError:
            continue
        if hour not in HOURS:
            continue
        g = lambda k: (h.get(k) or [])[i] if i < len(h.get(k) or []) else None
        out["hours"][str(t)[:13]] = [_num(g("temperature_2m")), g("precipitation_probability"), g("weather_code"),
                                     _num(g("wind_speed_10m")), _num(g("precipitation"))]
    return out


class Weather:
    def __init__(self, data: Path, session: requests.Session | None = None):
        self.path = data / "weather.json"
        self.http = session or requests.Session()
        self.error = ""
        try:
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.data = None

    def fetch(self) -> dict:
        r = self.http.get(URL, params=PARAMS, timeout=10)
        r.raise_for_status()
        out = normalize(r.json())
        if out["current"]["temp"] is None and not out["days"]:
            raise ValueError("날씨 응답이 비어 있어요")
        self.data = out
        self.error = ""
        try:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.path)
        except OSError:
            pass
        return out

    def due(self) -> bool:
        return not self.data or time.time() - float(self.data.get("at") or 0) > REFRESH

    def loop(self, stop: threading.Event | None = None):
        stop = stop or threading.Event()
        wait = 2.0
        while not stop.wait(wait):
            if not self.due():
                wait = 60
                continue
            try:
                self.fetch()
                wait = 60
            except (requests.RequestException, ValueError) as exc:
                self.error = type(exc).__name__
                wait = RETRY

    def start(self):
        threading.Thread(target=self.loop, daemon=True, name="weather").start()

    def stamp(self) -> float:
        return float((self.data or {}).get("at") or 0)
