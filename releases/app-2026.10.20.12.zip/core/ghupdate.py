"""GitHub(chbak0/Prime_SongdoTennis 공개 저장소)에서 새 버전 받기.

저장소의 releases/latest.json:
  {"version": "2026.10.19.7", "sha256": "...", "size": 123, "file": "releases/app-2026.10.19.7.zip",
   "notes": "바뀐 점", "auto": true}
zip은 core/updater.py의 build_package로 만든 것과 같고, 적용 전에 sha256·파일 이름·VERSION을 다시 확인한다.
요청은 30분마다 작은 JSON 한 번(새 버전이 있을 때만 zip을 받음). 사이트에는 요청하지 않는다.
"""
from __future__ import annotations

import re

import requests

REPO = "chbak0/Prime_SongdoTennis"
BRANCH = "main"
RAW = f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/"
MANIFEST = "releases/latest.json"
EVERY = 1800
FILE_RE = re.compile(r"^releases/app-[0-9.]+\.zip$")


class GhError(Exception):
    pass


def manifest(session: requests.Session | None = None, timeout: float = 8) -> dict:
    s = session or requests
    r = s.get(RAW + MANIFEST, timeout=timeout, headers={"Cache-Control": "no-cache"})
    if r.status_code == 404:
        raise GhError("배포 정보가 아직 없어요")
    r.raise_for_status()
    m = r.json()
    if not isinstance(m, dict) or not re.fullmatch(r"[0-9.]+", str(m.get("version") or "")):
        raise GhError("배포 정보 형식이 이상해요")
    if not FILE_RE.match(str(m.get("file") or "")) or not re.fullmatch(r"[0-9a-f]{64}", str(m.get("sha256") or "")):
        raise GhError("배포 정보 형식이 이상해요")
    return {"version": m["version"], "sha256": m["sha256"], "file": m["file"], "notes": str(m.get("notes") or "")[:300],
            "auto": m.get("auto", True) is not False, "size": int(m.get("size") or 0)}


def download(m: dict, session: requests.Session | None = None, timeout: float = 60) -> bytes:
    s = session or requests
    r = s.get(RAW + m["file"], timeout=timeout)
    r.raise_for_status()
    return r.content
