"""오프라인 테스트: 가짜 서버로 엔진·한도·교체·허용 목록을 검증한다. 실제 사이트에 접속하지 않는다."""
import asyncio
import os
import sys
import tempfile
import threading
import time
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.engine import Engine, FALLBACK_FACILITIES, DONE
from core.journal import Journal
from core.rules import DEFAULT_RULES, KST, Target, capacity, check_allowed, open_event_for, validate_targets
from core.transport import Rejected, Unknown

FAC12 = FALLBACK_FACILITIES[12]
DAY = (datetime.now(KST) + timedelta(days=10)).date().isoformat()


class FakeServer:
    def __init__(self):
        self.lock = threading.Lock()
        self.version = 0
        self.slots = {}          # (facility, date) -> list
        self.carts = {}          # token -> list[slotId]
        self.calls = []
        self.add_behavior = {}   # slotId -> "reject" | "unknown_applied" | "unknown_lost"
        self.held = set()
        self.slow = {}

    def make_slots(self, facility, d, open_=False, booked=()):
        rows = []
        for i, start in enumerate(range(360, 1321, 120)):
            sid = f"{facility[-4:]}-{d}-{start}"
            # 실제 서버처럼 숫자를 실수로 보낸다(2026-10-13 확인: "startMinute":360.0)
            rows.append({"_id": sid, "date": d, "facilityId": facility, "startMinute": float(start), "endMinute": float(start + 120),
                         "isBooked": (not open_) or start in booked, "isPast": False, "cartHeldByAnyone": False, "price": 5000.0,
                         "_creationTime": 1789780981427.49})
        self.slots[(facility, d)] = rows
        self.version += 1

    def open_all(self, facility, d):
        with self.lock:
            for s in self.slots[(facility, d)]:
                s["isBooked"] = False
            self.version += 1

    def release(self, sid):
        with self.lock:
            for rows in self.slots.values():
                for s in rows:
                    if s["_id"] == sid:
                        s["isBooked"] = False
                        s["cartHeldByAnyone"] = False
            self.version += 1

    def _find(self, sid):
        for rows in self.slots.values():
            for s in rows:
                if s["_id"] == sid:
                    return s
        return None

    def query(self, token, path, args):
        with self.lock:
            self.calls.append(("query", path))
            if path.startswith("slots/queries:listByFacilityAndDatePublic"):
                return [dict(s) for s in self.slots.get((args["facilityId"], args["date"]), [])]
            if path == "cart/queries:listMySlotIds":
                return list(self.carts.get(token, []))
            if path == "cart/queries:list":
                return []
            if path.startswith("reservations/"):
                return {"page": [], "isDone": True, "continueCursor": ""}
            if path.startswith("facilities/"):
                return [{"_id": f, "name": f"{c}번 코트"} for c, f in FALLBACK_FACILITIES.items()]
            if path.startswith("slotOpenRules/"):
                return {"openAtUtcMs": None, "source": "none"}
            return None

    def mutation(self, token, path, args):
        with self.lock:
            self.calls.append(("mutation", path, args.get("slotId")))
            sid = args["slotId"]
            s = self._find(sid)
            cart = self.carts.setdefault(token, [])
            if path == "cart/mutations:remove":     # 실제 응답 형식(2026-10-13 관찰): {"success": true}
                if sid in cart:
                    cart.remove(sid)
                    if s:
                        s["cartHeldByAnyone"] = False
                self.version += 1
                return {"success": True}
            beh = self.add_behavior.get(sid)
            if s is not None and sum(1 for x in cart if (self._find(x) or {}).get("date") == s["date"]) >= 3:
                raise Rejected("같은 날짜는 최대 3개까지 예약할 수 있습니다")   # 사이트가 한도를 막는 것처럼
            if beh == "reject" or s is None or s["isBooked"] or s["cartHeldByAnyone"]:
                raise Rejected("이미 다른 사용자가 선택한 시간대입니다")
            if beh == "unknown_lost":
                raise Unknown("응답 시간 초과")
            cart.append(sid)
            s["cartHeldByAnyone"] = True
            self.version += 1
            if beh == "unknown_applied":
                raise Unknown("응답 시간 초과")
            return None


class FakeTransport:
    def __init__(self, server, token):
        self.server, self.token = server, token

    def set_token(self, t):
        self.token = t

    async def subscribe(self, path, args):
        check_allowed("query", path)
        last = -1
        while True:
            if self.server.version != last:
                last = self.server.version
                yield self.server.query(self.token, path, args)
            await asyncio.sleep(0.03)

    async def query(self, path, args, timeout=4.0, urgent=False, skip_gate=False):
        check_allowed("query", path)
        await asyncio.sleep(0.005)
        return self.server.query(self.token, path, args)

    async def mutation(self, path, args, timeout=6.0):
        check_allowed("mutation", path)
        await asyncio.sleep(0.01)
        delay = self.server.slow.get(args.get("slotId"))
        if delay:   # 응답이 늦는 요청: 시간 초과로 끝나지만 실제로는 delay초 뒤 반영
            from concurrent.futures import Future
            fut = Future()
            def later():
                time.sleep(delay)
                try:
                    fut.set_result(self.server.mutation(self.token, path, args))
                except Exception as e:
                    fut.set_exception(e)
            threading.Thread(target=later, daemon=True).start()
            raise Unknown("응답 시간 초과", inflight=fut)
        return self.server.mutation(self.token, path, args)

    def close(self):
        pass


def jwt(sub, exp=None):
    import base64, json
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")
    return f"{b({'alg':'none'})}.{b({'sub': sub, 'exp': exp or time.time() + 3600})}.sig"


class Base(unittest.TestCase):
    TIMING = {"prepare_minutes": 0, "pre_seconds": 0, "rush_seconds": 2.5, "after_minutes": 0,
              "rush_poll": 0.1, "verify_seconds": 1.5, "now_delay": 0.3, "http_rps": 50, "reject_cooldown": 0.3}

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.server = FakeServer()
        self.server.make_slots(FAC12, DAY, open_=True)
        self.journal = Journal(Path(self.tmp.name))
        self.engine = Engine(self.journal, lambda tok: FakeTransport(self.server, tok), timing=self.TIMING)
        self.engine.facilities = dict(FALLBACK_FACILITIES)
        self.engine.link_token("A", jwt("user-a"))

    def tearDown(self):
        self.engine.stop()
        self.journal.close()
        self.tmp.cleanup()

    def run_targets(self, targets, extra_wait=0.0, during=None):
        self.engine.arm(targets, start_now=True)
        if during:
            during()
        end = time.time() + 6 + extra_wait
        while time.time() < end and self.engine.running:
            time.sleep(0.05)
        return self.labels()

    def labels(self):
        snap = self.engine.snapshot()["targets"]
        return {st.target.label: snap[tid] for tid, st in self.engine.states.items()}

    def T(self, start, prio=0, account="A", d=DAY, court=12):
        return Target(account=account, date=d, court=court, start=start, priority=prio)


class RulesTests(unittest.TestCase):
    def test_open_event_assignment(self):
        wk = date(2026, 11, 3)    # 화요일
        we = date(2026, 11, 7)    # 토요일
        self.assertEqual(open_event_for(wk, 360)["at"], datetime(2026, 10, 20, 10, 0, tzinfo=KST))
        self.assertEqual(open_event_for(wk, 1080)["at"], datetime(2026, 10, 20, 20, 0, tzinfo=KST))
        self.assertEqual(open_event_for(we, 1200)["at"], datetime(2026, 10, 23, 10, 0, tzinfo=KST))
        self.assertEqual(open_event_for(date(2027, 1, 5), 600)["at"], datetime(2026, 12, 20, 10, 0, tzinfo=KST))

    def test_forbidden_functions_are_blocked(self):
        for path in ("reservations/mutations:createFromSlots", "cart/mutations:clear",
                     "reservations/mutations:cancelMyReservation", "cart/mutations:addOnBehalfOf"):
            with self.assertRaises(PermissionError):
                check_allowed("mutation", path)
        check_allowed("mutation", "cart/mutations:add")
        check_allowed("mutation", "cart/mutations:remove")

    def test_capacity_counts_created_today_and_cart(self):
        today = date(2026, 10, 20)
        ms = datetime(2026, 10, 20, 10, 1, tzinfo=KST).timestamp() * 1000
        res = [{"date": "2026-11-03", "createdAt": ms, "status": "pending"},
               {"date": "2026-11-03", "createdAt": ms - 86400e3, "status": "confirmed"},
               {"date": "2026-11-04", "createdAt": ms, "status": "cancelled"}]
        cap = capacity(res, [{"date": "2026-11-03"}, {"date": "2026-11-05"}], today, "2026-11-03")
        self.assertEqual((cap["daily_used"], cap["date_used"]), (3, 3))
        self.assertEqual((cap["daily_left"], cap["date_left"]), (2, 0))

    def test_same_slot_two_accounts_rejected_and_lesson_court_blocked(self):
        with self.assertRaises(ValueError):
            validate_targets([{"account": "A", "date": DAY, "court": 12, "start": 600},
                              {"account": "B", "date": DAY, "court": 12, "start": 600}], {"A", "B"})
        wk = (datetime.now(KST) + timedelta(days=30))
        while wk.weekday() >= 5:
            wk += timedelta(days=1)
        with self.assertRaises(ValueError):
            validate_targets([{"account": "A", "date": wk.date().isoformat(), "court": 5, "start": 1080}], {"A"})

    def test_max_five_targets_and_tournament_block(self):
        many = [{"account": "A", "date": DAY, "court": c, "start": 600} for c in range(7, 13)]
        with self.assertRaises(ValueError):
            validate_targets(many, {"A"})
        rules = {**DEFAULT_RULES, "blocks": {DAY: "part"}}
        with self.assertRaises(ValueError):
            validate_targets([{"account": "A", "date": DAY, "court": 12, "start": 600}], {"A"}, rules=rules)
        validate_targets([{"account": "A", "date": DAY, "court": 15, "start": 600}], {"A"}, rules=rules)


class EngineTests(Base):
    def test_open_slot_is_added_and_confirmed(self):
        r = self.run_targets([self.T(600)])
        self.assertEqual(r[f"{DAY} 12번 10:00"]["status"], DONE)
        adds = [c for c in self.server.calls if c[0] == "mutation"]
        self.assertEqual(len(adds), 1)

    def test_slot_opens_late_and_is_caught(self):
        self.server.make_slots(FAC12, DAY, open_=False)
        r = self.run_targets([self.T(600)], during=lambda: (time.sleep(1.0), self.server.open_all(FAC12, DAY)))
        self.assertEqual(r[f"{DAY} 12번 10:00"]["status"], DONE)

    def test_per_date_limit_three_respects_priority(self):
        ts = [self.T(s, prio=i) for i, s in enumerate([360, 480, 600, 720, 840])]
        r = self.run_targets(ts)
        done = sorted(k for k, v in r.items() if v["status"] == DONE)
        self.assertEqual(len(done), 3)
        self.assertEqual(done, sorted([f"{DAY} 12번 06:00", f"{DAY} 12번 08:00", f"{DAY} 12번 10:00"]))
        self.assertEqual(r[f"{DAY} 12번 12:00"]["status"], "ended")

    def test_lost_response_not_resent(self):
        sid = f"{FAC12[-4:]}-{DAY}-600"
        self.server.add_behavior[sid] = "unknown_applied"
        r = self.run_targets([self.T(600)])
        self.assertEqual(r[f"{DAY} 12번 10:00"]["status"], DONE)
        self.assertEqual(sum(1 for c in self.server.calls if c[0] == "mutation"), 1)

    def test_parallel_adds_within_account_respect_date_limit(self):
        ts = [self.T(s, prio=i) for i, s in enumerate([360, 480, 600, 720, 840])]
        r = self.run_targets(ts)
        adds = [c for c in self.server.calls if c[:2] == ("mutation", "cart/mutations:add")]
        self.assertGreaterEqual(len(adds), 5)                # 5개 모두 바로 보냄(넘친 건 사이트가 거절)
        self.assertEqual(sum(v["status"] == DONE for v in r.values()), 3)

    def test_attempts_are_limited_until_slot_reopens(self):
        sid = f"{FAC12[-4:]}-{DAY}-600"
        self.server.add_behavior[sid] = "reject"
        self.engine.timing.update({"max_attempts": 2, "reject_cooldown": 0.2, "rush_seconds": 3})
        self.run_targets([self.T(600)])
        adds = [c for c in self.server.calls if c[:2] == ("mutation", "cart/mutations:add")]
        self.assertEqual(len(adds), 2)

    def test_limit_waits_without_removing_anything(self):
        tok = self.engine.accounts["A"].token
        r = self.run_targets([self.T(s, i) for i, s in enumerate([360, 480, 600, 720])])
        self.assertEqual(sum(v["status"] == DONE for v in r.values()), 3)
        self.assertFalse(any(c[:2] == ("mutation", "cart/mutations:remove") for c in self.server.calls))
        self.assertEqual(len(self.server.carts[tok]), 3)

    def test_test_mode_runs_at_given_time(self):
        at = datetime.now(KST) + timedelta(seconds=1.0)
        t = self.T(600)
        self.engine.arm([t], test_at=at)
        self.assertTrue(self.engine.snapshot()["test_mode"])
        end = time.time() + 7
        while time.time() < end and self.engine.running:
            time.sleep(0.05)
        self.assertEqual(self.engine.snapshot()["targets"][t.id]["status"], DONE)

    def test_run_report_is_saved(self):
        sid = f"{FAC12[-4:]}-{DAY}-720"
        self.server.add_behavior[sid] = "reject"
        self.engine.timing.update({"max_attempts": 2, "reject_cooldown": 0.2})
        self.run_targets([self.T(600, 0), self.T(720, 1)])
        time.sleep(0.5)
        rep = self.engine.last_report
        self.assertIsNotNone(rep)
        self.assertEqual(rep["totals"]["done"], 1)
        self.assertEqual(rep["totals"]["rejected"], 2)
        by = {t["label"]: t for t in rep["targets"]}
        self.assertIsNotNone(by[f"{DAY} 12번 10:00"]["first_open_ms"])
        self.assertTrue(list(self.engine.report_dir.glob("*.json")))
        self.assertTrue(any("실행 요약" in n["msg"] for n in self.journal.recent_notes()))

    def test_two_accounts_share_reads(self):
        self.engine.link_token("B", jwt("user-b"))
        r = self.run_targets([self.T(600, account="A"), self.T(720, account="B")])
        self.assertTrue(all(v["status"] == DONE for v in r.values()))

    def test_same_login_cannot_link_twice(self):
        with self.assertRaises(ValueError):
            self.engine.link_token("B", jwt("user-a"))


class UserRemoveTests(Base):
    def test_user_remove_during_run_is_not_re_added(self):
        sid = f"{FAC12[-4:]}-{DAY}-600"
        def scenario():
            time.sleep(1.0)
            self.engine.remove_by_user("A", sid).result(10)
        self.engine.timing["rush_seconds"] = 4
        r = self.run_targets([self.T(600)], during=scenario)
        tok = self.engine.accounts["A"].token
        self.assertNotIn(sid, self.server.carts[tok])
        self.assertEqual(r[f"{DAY} 12번 10:00"]["status"], "removed")
        adds = [c for c in self.server.calls if c[:2] == ("mutation", "cart/mutations:add")]
        self.assertEqual(len(adds), 1)

    def test_user_can_remove_item_added_on_site_when_idle(self):
        tok = self.engine.accounts["A"].token
        mine = "site-added-item"
        self.server.carts[tok] = [mine]
        self.engine.call(self.engine.refresh_account(self.engine.accounts["A"]), timeout=5)
        self.engine.remove_by_user("A", mine).result(10)
        self.assertEqual(self.server.carts[tok], [])

    def test_remove_rejects_unknown_item(self):
        with self.assertRaises(ValueError):
            self.engine.remove_by_user("A", "not-in-cart")


class ReviewRegressionTests(Base):
    def test_inflight_add_is_not_resent(self):
        slow = f"{FAC12[-4:]}-{DAY}-360"
        self.server.slow[slow] = 2.5            # verify_seconds(1.5)보다 길게 걸림
        self.engine.timing["rush_seconds"] = 5.5
        r = self.run_targets([self.T(360, 0), self.T(480, 1), self.T(600, 2), self.T(720, 3)])
        sent = [c for c in self.server.calls if c[:2] == ("mutation", "cart/mutations:add") and c[2] == slow]
        self.assertEqual(len(sent), 1)
        tok = self.engine.accounts["A"].token
        self.assertLessEqual(len(self.server.carts[tok]), 3)      # 넘친 건 사이트(가짜 서버)가 거절

    def test_stop_then_immediate_arm_is_refused_or_clean(self):
        self.engine.arm([self.T(600)], start_now=True)
        self.engine.stop()
        try:
            self.engine.arm([self.T(720)], start_now=True)
        except ValueError:
            time.sleep(1.0)
            self.engine.arm([self.T(720)], start_now=True)
        end = time.time() + 6
        while time.time() < end and self.engine.running:
            time.sleep(0.05)
        self.assertEqual(self.labels()[f"{DAY} 12번 12:00"]["status"], DONE)


if __name__ == "__main__":
    unittest.main(verbosity=2)
