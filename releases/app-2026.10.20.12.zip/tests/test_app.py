"""서버 쪽 로직(목표 추가·순서·관리자·내보내기·설정 이전) 오프라인 테스트."""
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core.engine import Engine, FALLBACK_FACILITIES
from core.journal import Journal
from core.rules import KST
from test_engine import FakeServer, FakeTransport

DAY = (datetime.now(KST) + timedelta(days=12))
while DAY.weekday() >= 5:
    DAY += timedelta(days=1)
DAY = DAY.date().isoformat()


class AppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        self.make()

    def make(self):
        j = Journal(self.data / "logs")
        self.eng = Engine(j, lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=self.data, engine=self.eng, start_threads=False)

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_account_names_and_colors(self):
        a = self.app.add_account()
        b = self.app.add_account()
        self.assertEqual((a, b), ("계정1", "계정2"))
        cols = [x["color"] for x in self.app.settings["accounts"]]
        self.assertEqual(len(set(cols)), 2)
        self.app.rename_account("계정1", "철환")
        self.assertEqual(self.app.names(), ["철환", "계정2"])

    def test_add_targets_combos_limits_and_blocks(self):
        self.app.add_account("A")
        with self.assertRaises(ValueError):       # 같은 날 3건 넘음
            self.app.add_targets({"account": "A", "date": DAY, "courts": [12, 13], "starts": [600, 720]})
        n = self.app.add_targets({"account": "A", "date": DAY, "courts": [12, 13], "starts": [600]})
        self.assertEqual(n, 2)
        with self.assertRaises(ValueError):       # 이미 2 + 2 > 3
            self.app.add_targets({"account": "A", "date": DAY, "courts": [9, 10], "starts": [720]})
        self.assertEqual(len(self.app.settings["targets"]), 2)

    def test_lesson_courts_are_skipped(self):
        self.app.add_account("A")
        with self.assertRaises(ValueError):
            self.app.add_targets({"account": "A", "date": DAY, "courts": [5, 6], "starts": [1080]})
        self.assertEqual(self.app.add_targets({"account": "A", "date": DAY, "courts": [5], "starts": [600, 1080]}), 1)

    def test_same_slot_other_account_is_skipped_and_reorder(self):
        self.app.add_account("A"); self.app.add_account("B")
        self.app.add_targets({"account": "A", "date": DAY, "courts": [12], "starts": [600, 720]})
        self.assertEqual(self.app.add_targets({"account": "B", "date": DAY, "courts": [12], "starts": [600, 840]}), 1)
        ids = [t["id"] for t in self.app.settings["targets"] if t["account"] == "A"]
        self.app.reorder_targets("A", ids[::-1])
        mine = [t for t in self.app.settings["targets"] if t["account"] == "A"]
        self.assertEqual([t["id"] for t in mine], ids[::-1])
        self.assertEqual([t["priority"] for t in mine], [0, 1])

    def test_admin_password_is_hashed(self):
        self.app.admin_login("abcd")
        raw = (self.data / "admin.json").read_text()
        self.assertNotIn("abcd", raw)
        self.app.admin_until = 0
        with self.assertRaises(ValueError):
            self.app.admin_login("wrong")
        self.app.admin_login("abcd")
        self.assertTrue(self.app.admin_ok())
        self.app.set_test({"at": (datetime.now(KST) + timedelta(minutes=2)).isoformat()})
        self.assertIsNotNone(self.app.test_at)

    def test_test_mode_needs_admin(self):
        with self.assertRaises(ValueError):
            self.app.set_test({"at": (datetime.now(KST) + timedelta(minutes=2)).isoformat()})

    def test_timing_clamped(self):
        self.app.set_timing({"pre_seconds": 99, "rush_seconds": 5})
        self.assertEqual(self.eng.timing["pre_seconds"], 30)
        self.assertEqual(self.eng.timing["rush_seconds"], 10)
        self.app.set_timing({"reset": True})
        self.assertEqual(self.eng.timing["pre_seconds"], 5)

    def test_export_reservations_excludes_cancelled(self):
        self.app.add_account("A")
        acct = self.eng.accounts["A"]
        acct.reservations = [
            {"_id": "1", "date": "2026-11-03", "startMinute": 600.0, "endMinute": 720.0, "facilityId": FALLBACK_FACILITIES[12], "status": "confirmed"},
            {"_id": "2", "date": "2026-11-04", "startMinute": 600.0, "endMinute": 720.0, "facilityId": FALLBACK_FACILITIES[9], "status": "cancelled"},
        ]
        name, body = self.app.export_csv("A", "2026-11", "res")
        self.assertEqual(name, "songdo-reservations_acct1_2026-11.csv")
        text = body.decode("utf-8-sig")
        self.assertIn("2026-11-03,10:00~12:00,12번", text)
        self.assertNotIn("2026-11-04", text)

    def test_profile_name_used_for_auto_named_accounts(self):
        a = self.app.add_account(); b = self.app.add_account(); c = self.app.add_account("내계정")
        self.eng.accounts[a].profile = {"name": "박철환", "email": "a@x.com"}
        self.eng.accounts[b].profile = {"name": "박철환", "email": "b@x.com"}
        self.eng.accounts[c].profile = {"name": "김민수", "email": "c@x.com"}
        self.app._sync_profiles()
        self.assertEqual(self.app.names(), ["박철환", "박철환2", "내계정"])
        acc = {x["name"]: x for x in self.app.settings["accounts"]}
        self.assertEqual(acc["내계정"]["display_name"], "김민수")
        self.assertEqual(acc["박철환2"]["login_id"], "b@x.com")

    def test_old_settings_are_migrated(self):
        self.app.journal.close()
        (self.data / "settings.json").write_text(json.dumps({"accounts": ["철환"], "targets": [
            {"account": "철환", "date": DAY, "court": 12, "start": 600, "priority": 0, "swap": True, "id": "x1"}],
            "timing": {"rush_seconds": 180, "accel_seconds": 120}}), encoding="utf-8")
        self.make()
        self.assertEqual(self.app.settings["accounts"][0]["name"], "철환")
        self.assertNotIn("swap", self.app.settings["targets"][0])
        self.assertNotIn("accel_seconds", self.app.settings["timing"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
