"""로그인 창 도우미 테스트(가짜 사이트). SONGDO_CHROME에 Chrome/Chromium 경로가 있을 때만 실행.
화면 없는 환경이면 SONGDO_CHROME_HEADLESS=1로 숨은 창으로 연다."""
import base64
import http.server
import json
import os
import stat
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def jwt():
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")
    return f"{b({'alg': 'none'})}.{b({'sub': 'u', 'exp': time.time() + 3600})}.sig"


HOME = """<header><button aria-label="로그인" onclick="location.href = GOOGLE + '?back=' + encodeURIComponent(location.href)">L</button></header>
<script>if (location.search.includes('code=')) localStorage.setItem('convex_auth_token', JSON.stringify(TOK));</script>
<script>
// 실제 사이트처럼: 저장소에 오늘 날짜로 기록된 팝업은 띄우지 않음. 버튼으로 닫힌 횟수는 clicks에 기록
const seen = JSON.parse(localStorage.getItem('prime_reserve_dismissed_popups') || '{}');
if (seen.p1 !== DAY) document.write('<div role="dialog"><button onclick="localStorage.setItem(\\'clicks\\', 1); this.parentNode.remove()">오늘 하루 보지 않기</button></div>');
</script>"""
PROFILE = """<input id="profile-name"><input id="profile-email"><input id="profile-phone" value="01000000000">
<script>setTimeout(()=>{document.querySelector('#profile-name').value='박철환';document.querySelector('#profile-email').value='a@b.c'},500)</script>"""


@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class LoginWatcherTests(unittest.TestCase):
    def setUp(self):
        tok = jwt()
        self.tok = tok

        class G(http.server.BaseHTTPRequestHandler):      # 다른 주소(가짜 Google): 1.5초 뒤 code를 붙여 되돌려 보냄
            def log_message(self, *a): pass
            def do_GET(self):
                self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers()
                self.wfile.write(b"<script>setTimeout(()=>{const b=new URLSearchParams(location.search).get('back');location.href=b+(b.includes('?')?'&':'?')+'code=1'},1500)</script>")
        self.g = http.server.HTTPServer(("127.0.0.1", 0), G)
        threading.Thread(target=self.g.serve_forever, daemon=True).start()
        google = f"http://localhost:{self.g.server_port}/o"

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                body = PROFILE if self.path.startswith("/profile") else "<script>const TOK=" + json.dumps(tok) + ";const DAY='2026-10-14';const GOOGLE=" + json.dumps(google) + "</script>" + HOME
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
                self.wfile.write(body.encode())
        self.srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.tmp = tempfile.TemporaryDirectory()
        real = os.environ["SONGDO_CHROME"]
        if os.environ.get("SONGDO_CHROME_HEADLESS"):
            wrap = Path(self.tmp.name) / "chrome.sh"
            wrap.write_text(f'#!/bin/sh\nexec "{real}" --headless=new --no-sandbox "$@"\n')
            wrap.chmod(wrap.stat().st_mode | stat.S_IEXEC)
            os.environ["SONGDO_CHROME"] = str(wrap)
        self.real = real
        # 가짜 사이트 주소에 songdotennis.co.kr가 들어가야 도우미가 그 페이지를 본다 → hosts 대신 경로로 표시
        os.environ["SONGDO_SITE_OVERRIDE"] = f"http://127.0.0.1:{self.srv.server_port}/songdotennis.co.kr"
        import importlib, core.browser
        importlib.reload(core.browser)
        self.b = core.browser

    def tearDown(self):
        os.environ["SONGDO_CHROME"] = self.real
        self.srv.shutdown(); self.g.shutdown(); self.tmp.cleanup()

    def test_auto_popup_login_profile_and_close(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        port = self.b.free_port()
        prof.open_login("A", debug_port=port)
        done, status = [], []
        logs = []
        w = self.b.LoginWatcher(prof, "A", port, lambda t, p: done.append((t, p)), lambda s, m: status.append(m), timeout=40,
                                on_log=lambda m, level="info": logs.append(m), popup_ids=lambda: ["p1"], today="2026-10-14")
        w.start(); w.join(60)
        self.assertEqual(len(done), 1, (status, logs))
        self.assertTrue(any("보지 않기 처리" in m for m in logs), logs)
        self.assertEqual(done[0][0], self.tok)
        self.assertEqual(done[0][1], {"name": "박철환", "email": "a@b.c"})
        self.assertTrue(any("창 숨김(화면 밖)" in m or "창 숨김(최소화)" in m for m in logs), logs)   # 로그인되자마자 숨김
        self.assertIn("로그인 완료 · 이름과 아이디를 불러오는 중", status)
        for _ in range(40):
            if not prof.window_open("A"):
                break
            time.sleep(0.25)
        self.assertFalse(prof.window_open("A"))


    def test_slow_popup_list_does_not_delay(self):
        """공지 목록이 늦어도(5초) 기다리지 않고 버튼 누르기로 닫고 로그인까지 진행."""
        prof = self.b.Profiles(Path(self.tmp.name))
        port = self.b.free_port()
        prof.open_login("A", debug_port=port)
        done, logs, t0 = [], [], time.monotonic()
        clicked = []

        def slow():
            time.sleep(5)
            return ["p1"]

        def log(m, level="info"):
            logs.append(m)
            if "로그인 버튼 누름" in m:
                clicked.append(time.monotonic() - t0)
        w = self.b.LoginWatcher(prof, "A", port, lambda t, p: done.append((t, p)), lambda s, m: None, timeout=40,
                                on_log=log, popup_ids=slow, today="2026-10-14")
        w.start(); w.join(60)
        self.assertEqual(len(done), 1, logs)
        self.assertTrue(clicked and clicked[0] < 4.5, (clicked, logs))
        for _ in range(40):
            if not prof.window_open("A"):
                break
            time.sleep(0.25)


if __name__ == "__main__":
    unittest.main(verbosity=2)
