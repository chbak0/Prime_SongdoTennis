"""숨은 Chrome 토큰 읽기 테스트(로컬 가짜 페이지). SONGDO_CHROME 환경변수에 Chrome/Chromium 경로가 있을 때만 실행."""
import base64
import http.server
import json
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def jwt(n, life=3600):
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")
    return f"{b({'alg': 'none'})}.{b({'sub': 'u', 'exp': time.time() + life, 'n': n})}.sig"


PAGE = """<script>
let n=0;function put(){n++;localStorage.setItem('convex_auth_token', JSON.stringify(TOK[Math.min(n-1,TOK.length-1)]));}
put();setInterval(put,1500);</script>"""


@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class KeeperTests(unittest.TestCase):
    TOKS = None

    def setUp(self):
        toks = self.TOKS or [jwt(1), jwt(2)]
        body = ("<script>const TOK=" + json.dumps(toks) + ";</script>" + PAGE).encode()

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                self.send_response(200); self.send_header("Content-Type", "text/html"); self.end_headers(); self.wfile.write(body)
        self.srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        os.environ["SONGDO_SITE_OVERRIDE"] = f"http://127.0.0.1:{self.srv.server_port}/"
        import importlib, core.browser
        importlib.reload(core.browser)
        self.b = core.browser
        self.tmp = tempfile.TemporaryDirectory()
        self.toks = toks

    def tearDown(self):
        self.srv.shutdown(); self.tmp.cleanup()

    def test_reads_token_and_follows_refresh(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        prof.path("A").mkdir(parents=True)
        got, status = [], []
        k = self.b.Keeper(prof, "A", got.append, lambda s, m: status.append((s, m)), interval=1.0)
        k.start(); time.sleep(6); k.stop(); k.join(10)
        self.assertGreaterEqual(len(got), 2, status)
        self.assertEqual(got[0], self.toks[0]); self.assertEqual(got[-1], self.toks[1])

    def test_missing_profile_reports_login_needed(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        status = []
        k = self.b.Keeper(prof, "nobody", lambda t: None, lambda s, m: status.append(m), once=True)
        k.start(); k.join(10)
        self.assertIn("로그인", status[0])


@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class ExpiredFirstTests(KeeperTests):
    """밤새 지난 토큰이 먼저 보이고, 사이트가 곧 새 토큰으로 바꾸는 경우: 지난 토큰은 쓰지 않는다."""
    TOKS = [jwt("old", life=-600), jwt("new")]

    def test_reads_token_and_follows_refresh(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        prof.path("A").mkdir(parents=True)
        got, status = [], []
        k = self.b.Keeper(prof, "A", got.append, lambda s, m: status.append((s, m)), once=True)
        k.start(); k.join(30)
        self.assertEqual(got, [self.toks[1]], status)



@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class NearExpiryTests(KeeperTests):
    """끝나기 1분 전 토큰인데 사이트가 아직 안 바꿔 줌: 기다리다 시간이 다 돼도 '만료'로 보지 않고 지금 토큰을 쓴다."""
    TOKS = [jwt("soon", life=60)]

    def test_reads_token_and_follows_refresh(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        prof.path("A").mkdir(parents=True)
        got, status = [], []
        k = self.b.Keeper(prof, "A", got.append, lambda s, m: status.append((s, m)), once=True, wait_seconds=3)
        k.start(); k.join(30)
        self.assertEqual(got, [self.toks[0]])
        self.assertEqual(status, [])


@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class ExpiredNoRefreshTests(KeeperTests):
    """이미 끝난 토큰만 있고 사이트가 새로 못 줌(갱신 정보 만료): 로그인 필요."""
    TOKS = [jwt("dead", life=-60)]

    def test_reads_token_and_follows_refresh(self):
        prof = self.b.Profiles(Path(self.tmp.name))
        prof.path("A").mkdir(parents=True)
        got, status = [], []
        k = self.b.Keeper(prof, "A", got.append, lambda s, m: status.append((s, m)), once=True, wait_seconds=3)
        k.start(); k.join(30)
        self.assertEqual(got, [])
        self.assertEqual(status[0][0], "error")


if __name__ == "__main__":
    unittest.main(verbosity=2)
