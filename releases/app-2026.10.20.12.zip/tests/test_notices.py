"""사이트 공지 정리 오프라인 테스트(여러 형태의 공지 데이터)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core import notices
from core.engine import Engine
from core.journal import Journal
from test_engine import FakeServer, FakeTransport

RAW = [
    {"_id": "a1", "_creationTime": 1760000000000.0, "title": "주차장 안내", "content": "<p>꼬리물기 금지</p><p>단속 예정</p>", "isPopup": True},
    {"_id": "a2", "createdAt": "2026-10-18T09:00:00+09:00", "title": "11월 대회 일정", "content": "11/7 전 코트 불가", "isPinned": True},
    {"_id": "a3", "createdAt": 1761000000000, "subject": "숨김 공지", "body": "x", "isActive": False},
    {"_id": "a4", "createdAt": 1761100000000, "title": "지난 공지", "content": "y", "endAt": "2020-01-01T00:00:00Z"},
    {"_id": "a5", "createdAt": 1761200000000, "content": {"blocks": [{"text": "첫 줄 제목처럼"}, {"text": "둘째 줄"}]}},
    "이상한 값",
]


class NoticeTests(unittest.TestCase):
    def test_normalize(self):
        out = notices.normalize(RAW)
        self.assertEqual([n["id"] for n in out][0], "a2")                 # 고정이 먼저
        ids = {n["id"] for n in out}
        self.assertEqual(ids, {"a1", "a2", "a5"})                           # 숨김·기간 지난 공지는 뺌
        a1 = next(n for n in out if n["id"] == "a1")
        self.assertEqual(a1["body"], "꼬리물기 금지\n단속 예정")             # HTML → 글자
        self.assertTrue(a1["popup"])
        a2 = next(n for n in out if n["id"] == "a2")
        self.assertEqual((a2["badge"], a2["date"]), ("고정", "26.10.18"))
        a5 = next(n for n in out if n["id"] == "a5")
        self.assertEqual(a5["title"], "첫 줄 제목처럼")                     # 제목 없으면 본문 첫 줄

    def test_field_names_only(self):
        self.assertNotIn("꼬리물기", notices.field_names(RAW))
        self.assertIn("title", notices.field_names(RAW))


class AppNoticeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        self.eng = Engine(Journal(self.data / "logs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=self.data, engine=self.eng, start_threads=False)

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_refresh_saves_and_updates_popups(self):
        self.eng.announcements = lambda timeout=8: RAW
        self.assertTrue(self.app.refresh_notices())
        self.assertEqual(len(self.app.notices), 3)
        self.assertEqual(json.loads((self.data / "popup_ids.json").read_text())["ids"], ["a1"])
        app2 = appmod.App(data=self.data, engine=self.eng, start_threads=False)   # 다시 켜도 저장된 공지
        self.assertEqual(len(app2.notices), 3)
        app2.journal.close()

    def test_failure_keeps_old(self):
        self.eng.announcements = lambda timeout=8: RAW
        self.app.refresh_notices()
        self.eng.announcements = lambda timeout=8: None
        self.assertFalse(self.app.refresh_notices())
        self.assertEqual(len(self.app.notices), 3)


if __name__ == "__main__":
    unittest.main()
