"""사이트 공지 속 대회 일정 해석 오프라인 테스트(실제 공지 문장 형식)."""
import json
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core import tournaments as T
from core.engine import Engine
from core.journal import Journal
from core.rules import DEFAULT_RULES, court_blocked
from test_engine import FakeServer, FakeTransport

OCT = {"title": "이용 안내", "createdAt": 1766193555207, "updatedAt": 1792225405120,
       "content": "<h3>코트 종류 안내</h3><h1>10월 대회공지: 카타 ,연수구청장배</h1>"
                  "<h1>10월 ,21,23,24,25(새벽은 예약가능,23일25일은 클레이는 예약가능)</h1>"
                  "<ul><li><p><strong>하드코트</strong>: (1~4번코트레슨전용 ,5,6번 (평일4시이후 레슨코트로사용</p></li></ul>"
                  "<h3>5번, 6번 코트는 평일 오전 6시부터 오후 4시까지 예약 가능하며, 주말은 전시간 예약 가능합니다.</h3>"}
NOV = {"title": "11월 대회일정", "updatedAt": 1792373690047, "isPopup": True,
       "content": "<p>안녕하세요</p><h1>-11월 대회일정-</h1>"
                  "<p>- 2,3일 인천연수구연합회 (월,화 오전 9~18시)9면 (새벽예약가능,저녁 6시 이후예약가능, 클레이는 전시간 예약가능)</p>"
                  "<p>- 13,14,15일 카타 전국 대회 전 코트 사용(새벽 예약 가능)</p>"
                  "<p>- 22일 송클회장배 대회 (5~8번만 12~18시만 사용) 나머지 시간은 예약 가능</p>"
                  "<p>- 28일 연수구 경찰 청 대회 (새벽만 예약 가능)</p><p></p>"}
RULES = {"title": "유의사항", "content": "<h2>20일예약: 오전 10시: 평일 오전,오후 (오전6~오후6시)</h2><h2>23일예약: 주말 (토,일 오전6시~저녁 22시)</h2>"}
TODAY = date(2026, 10, 19)


def blocked(b, iso, court, start):
    return court_blocked(date.fromisoformat(iso), court, start, {**DEFAULT_RULES, "blocks": b}) is not None


class ParseTests(unittest.TestCase):
    def setUp(self):
        self.b, self.missed = T.parse([OCT, NOV, RULES], TODAY)

    def test_dates_found(self):
        self.assertEqual(sorted(self.b), ["2026-10-21", "2026-10-23", "2026-10-24", "2026-10-25", "2026-11-02", "2026-11-03",
                                          "2026-11-13", "2026-11-14", "2026-11-15", "2026-11-22", "2026-11-28"])
        self.assertEqual(self.missed, [])

    def test_nov_2_partial_courts_and_hours(self):
        b = self.b
        self.assertTrue(blocked(b, "2026-11-02", 9, 600))       # 잔디 10시 막힘
        self.assertTrue(blocked(b, "2026-11-02", 9, 480))       # 08~10 칸은 9시와 겹침
        self.assertFalse(blocked(b, "2026-11-02", 9, 360))      # 새벽
        self.assertFalse(blocked(b, "2026-11-02", 9, 1080))     # 저녁 6시 이후
        self.assertFalse(blocked(b, "2026-11-02", 16, 720))     # 클레이 전시간

    def test_full_and_dawn_only(self):
        for iso in ("2026-11-13", "2026-11-28"):
            self.assertFalse(blocked(self.b, iso, 12, 360))
            self.assertFalse(blocked(self.b, iso, 12, 480))
            self.assertTrue(blocked(self.b, iso, 12, 600))
            self.assertTrue(blocked(self.b, iso, 17, 1200))

    def test_nov_22_only_5_to_8_midday(self):
        self.assertTrue(blocked(self.b, "2026-11-22", 7, 720))
        self.assertTrue(blocked(self.b, "2026-11-22", 5, 960))
        self.assertFalse(blocked(self.b, "2026-11-22", 7, 1080))
        self.assertFalse(blocked(self.b, "2026-11-22", 9, 720))

    def test_october_clay_exception_by_date(self):
        self.assertTrue(blocked(self.b, "2026-10-24", 16, 720))
        self.assertFalse(blocked(self.b, "2026-10-25", 16, 720))
        self.assertTrue(blocked(self.b, "2026-10-25", 10, 720))
        self.assertFalse(blocked(self.b, "2026-10-21", 10, 360))

    def test_non_tournament_notice_ignored(self):
        b, _ = T.parse([RULES], TODAY)
        self.assertEqual(b, {})

    def test_slash_dates_and_year_rollover(self):
        n = {"title": "1월 대회 일정", "updatedAt": 1797000000000, "content": "1/4,5 전 코트 대회"}
        b, _ = T.parse([n], date(2026, 12, 20))
        self.assertEqual(sorted(b), ["2027-01-04", "2027-01-05"])

    def test_unreadable_tournament_notice_reported(self):
        n = {"title": "12월 대회일정", "updatedAt": 1792373690047, "content": "다음 주 셋째 주말에 대회가 있어요 (14일쯤)"}
        b, missed = T.parse([n], TODAY)
        self.assertEqual(b, {})
        self.assertEqual(missed, ["12월 대회일정"])


class AppTourTests(unittest.TestCase):
    def setUp(self):
        self.saved = dict(DEFAULT_RULES["blocks"])
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)
        self.eng = Engine(Journal(self.data / "logs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=self.data, engine=self.eng, start_threads=False)

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()
        DEFAULT_RULES["blocks"] = self.saved

    def test_refresh_applies_blocks_and_persists(self):
        self.eng.announcements = lambda timeout=8: [OCT, NOV, RULES]
        self.assertTrue(self.app.refresh_notices())
        self.assertIn("2026-11-13", DEFAULT_RULES["blocks"])
        snap = json.loads(json.dumps(self.app.state()))
        self.assertEqual(snap["rules"]["blocks"]["2026-11-22"][0]["courts"], [5, 6, 7, 8])
        saved = json.loads((self.data / "notices.json").read_text(encoding="utf-8"))
        self.assertIn("2026-11-22", saved["tours"])
        DEFAULT_RULES["blocks"] = dict(self.saved)
        app2 = appmod.App(data=self.data, engine=self.eng, start_threads=False)
        self.assertIn("2026-11-22", DEFAULT_RULES["blocks"])
        app2.journal.close()
        self.assertTrue(snap is None or isinstance(snap, dict))

    def test_bad_notice_text_does_not_break_notices(self):
        self.eng.announcements = lambda timeout=8: [{"title": "대회", "content": {"weird": 1}}, RULES]
        self.assertTrue(self.app.refresh_notices())
        self.assertEqual(len(self.app.notices), 2)


if __name__ == "__main__":
    unittest.main()
