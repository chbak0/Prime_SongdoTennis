"""자세한 로그: 날짜별 파일 · 예전 형식 묶어 읽기 · 예약 실행 구간 표시 · 자정 넘김."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.journal import Journal


class DailyLogTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self.tmp.name) / "logs"
        self.folder.mkdir()
        old = [{"ts": "2026-10-20T09:39:30.000+09:00", "kind": "phase", "detail": "run start · weekday_day"},
               {"ts": "2026-10-20T09:41:46.000+09:00", "kind": "log", "who": "시스템", "cat": "화면", "msg": "화면 오류", "level": "err"},
               {"ts": "2026-10-20T10:00:12.000+09:00", "kind": "add_result", "account": "A", "target": "t", "result": "성공응답", "ms": 300},
               {"ts": "2026-10-20T10:00:59.000+09:00", "kind": "phase", "detail": "종료"},
               {"ts": "2026-10-20T10:01:00.000+09:00", "kind": "http_poll", "slot": "x", "ms": 1}]
        (self.folder / "20261019-120730.jsonl").write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in old) + "\n", encoding="utf-8")
        later = [{"ts": "2026-10-20T10:31:16.000+09:00", "kind": "session", "detail": "프로그램 시작 · 버전 x"}]
        (self.folder / "20261020-103116.jsonl").write_text(json.dumps(later, ensure_ascii=False)[1:-1] + "\n", encoding="utf-8")
        self.j = Journal(self.folder)

    def tearDown(self):
        self.j.close()
        self.tmp.cleanup()

    def test_today_file_name(self):
        self.assertRegex(self.j.path.name, r"^\d{4}-\d{2}-\d{2}\.jsonl$")

    def test_old_files_grouped_by_day_and_run_flag(self):
        self.assertIn("2026-10-20", self.j.days())
        rows = self.j.read_day("2026-10-20")
        msgs = [r["msg"] for r in rows]
        self.assertTrue(any("화면 오류" in m for m in msgs))
        self.assertTrue(any("프로그램 시작" in m for m in msgs))
        self.assertFalse(any("http_poll" in m for m in msgs))
        run = [r for r in rows if r["run"]]
        self.assertEqual(len(run), 4)                       # 시작 ~ 종료(종료 줄 포함)
        self.assertFalse(rows[-1]["run"])

    def test_midnight_rollover(self):
        self.j._write({"ts": "2099-01-02T00:00:01.000+09:00", "kind": "log", "msg": "x"})
        self.assertEqual(self.j.path.name, "2099-01-02.jsonl")
        self.assertTrue((self.folder / "2099-01-02.jsonl").exists())

    def test_bad_day_rejected(self):
        with self.assertRaises(ValueError):
            self.j.read_day("../x")


if __name__ == "__main__":
    unittest.main()
