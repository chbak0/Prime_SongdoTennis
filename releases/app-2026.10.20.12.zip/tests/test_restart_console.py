"""업데이트 뒤 재시작: 출력 통로가 끊긴 채(창 없는 재시작) 떠도 멈추지 않아야 한다(2026-10-20 OSError 재현)."""
import io
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import app as appmod


class Broken(io.TextIOBase):
    def write(self, s):
        raise OSError(22, "Invalid argument")

    def flush(self):
        raise OSError(22, "Invalid argument")


class ConsoleTests(unittest.TestCase):
    def test_say_survives_broken_stdout(self):
        old = sys.stdout
        sys.stdout = Broken()
        try:
            appmod._say("Songdo Tennis 시작")             # 예전엔 여기서 OSError로 프로그램이 꺼졌음
        finally:
            sys.stdout = old

    def test_say_with_no_stdout(self):
        old = sys.stdout
        sys.stdout = None                                  # pythonw
        try:
            appmod._say("x")
        finally:
            sys.stdout = old

    def test_main_has_no_bare_print(self):
        src = Path(appmod.__file__).read_text(encoding="utf-8")
        body = src[src.index("def main():"):]
        self.assertNotIn("print(", body)


if __name__ == "__main__":
    unittest.main()
