"""시계 보정 · 토큰 자동 갱신 · 오류 자동 전송 · 자동 업데이트 오프라인 테스트."""
import base64
import io
import json
import shutil
import sys
import tempfile
import time
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core import clock, updater
from core.engine import Engine
from core.journal import Journal
from test_cloud import KEY, FakeSupabase
from test_engine import FakeServer, FakeTransport, jwt

ROOT = Path(__file__).resolve().parents[1]


class ClockTests(unittest.TestCase):
    def fake(self, offset, rtt=0.04):
        """PC 시각 base에서 시작하는 가짜 표본: 서버 시각 = PC 시각 + offset, Date는 초 단위 내림."""
        state = {"t": 1_000_000.37}

        def sample():
            t0 = state["t"]
            t1 = t0 + rtt
            server_stamp = (t0 + rtt / 2) + offset
            state["t"] = t1
            return t0, t1, float(int(server_stamp))

        def sleep(g):
            state["t"] += g
        return sample, sleep

    def test_measures_offset_within_error(self):
        for off in (0.0, 0.73, -1.42, 3.05):
            sample, sleep = self.fake(off)
            m = clock.measure("x", sample=sample, sleep=sleep)
            self.assertLessEqual(abs(m["offset"] - off), m["error"] + 1e-6, (off, m))
            self.assertLess(m["error"], 0.3)

    def test_failures(self):
        self.assertIsNone(clock.measure("x", sample=lambda: None, sleep=lambda g: None))
        sample, sleep = self.fake(1000)
        self.assertIsNone(clock.measure("x", sample=sample, sleep=sleep))     # 너무 크면 무시

    def test_describe(self):
        self.assertIn("느려요", clock.describe(1.2))
        self.assertIn("빨라요", clock.describe(-0.5))


class EngineClockTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.j = Journal(Path(self.tmp.name) / "logs")
        self.eng = Engine(self.j, lambda tok: FakeTransport(FakeServer(), tok))

    def tearDown(self):
        self.j.close()
        self.tmp.cleanup()

    def test_offset_applied_to_now(self):
        before = self.eng.now()
        self.eng.apply_clock({"offset": 2.0, "error": 0.1, "rtt": 0.05, "n": 8})
        self.assertAlmostEqual((self.eng.now() - before).total_seconds(), 2.0, delta=0.2)
        self.assertTrue(any(n["key"] == "clock" for n in self.j.notes))       # 1초 넘으면 알림

    def test_uncertain_measurement_not_applied(self):
        self.eng.apply_clock({"offset": 2.0, "error": 0.9, "rtt": 1.5, "n": 3})
        self.assertEqual(self.eng.clock_offset, 0.0)

    def test_check_clock_runs_measure(self):
        self.eng.measure_clock = lambda: {"offset": -0.4, "error": 0.1, "rtt": 0.05, "n": 8}
        self.eng.call(self.eng.check_clock(), timeout=5)
        self.assertEqual(self.eng.clock_offset, -0.4)
        self.assertEqual(self.eng.snapshot()["clock"]["offset"], -0.4)


class FakeKeeper:
    made = []

    def __init__(self, profiles, account, on_token, on_status, interval=30, once=False, wait_seconds=10):
        self.account, self.on_token, self.once, self.wait_seconds = account, on_token, once, wait_seconds
        self.on_status = on_status
        FakeKeeper.made.append(self)
        self.alive = False

    def start(self):
        self.on_token(jwt("u1", exp=time.time() + 3600))

    def is_alive(self):
        return self.alive

    def stop(self):
        pass


class AppOpsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name) / "data"
        self.data.mkdir()
        (self.data / "cloud.json").write_text(json.dumps({"url": "https://abc.supabase.co", "anon_key": KEY}), encoding="utf-8")
        self.sb = FakeSupabase()
        orig = appmod.Cloud
        appmod.Cloud = lambda path, data, version, **kw: orig(path, data, version, session=self.sb, **kw)
        self.addCleanup(setattr, appmod, "Cloud", orig)
        orig_k = appmod.Keeper
        appmod.Keeper = FakeKeeper
        self.addCleanup(setattr, appmod, "Keeper", orig_k)
        FakeKeeper.made = []
        self.eng = Engine(Journal(self.data / "logs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=self.data, engine=self.eng, start_threads=False)

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    # ---- 토큰 자동 갱신
    def test_auto_refresh_near_expiry_only(self):
        name = self.app.add_account("A")
        self.app.profiles.path(name).mkdir(parents=True)
        self.eng.link_token(name, jwt("u1", exp=time.time() + 1800))
        self.app._auto_refresh()
        self.assertEqual(FakeKeeper.made, [])                 # 아직 30분 남음
        self.eng.accounts[name].exp = time.time() + 30
        self.app._auto_refresh()
        self.assertEqual(len(FakeKeeper.made), 1)
        self.assertTrue(FakeKeeper.made[0].once)
        self.assertEqual(FakeKeeper.made[0].wait_seconds, 100)
        self.assertGreater(self.eng.accounts[name].exp - time.time(), 3000)   # 새 토큰
        self.assertEqual(self.app.acct_status[name]["state"], "ready")

    def test_auto_refresh_retries_then_reports(self):
        name = self.app.add_account("A")
        self.app.profiles.path(name).mkdir(parents=True)
        self.eng.link_token(name, jwt("u1", exp=time.time() + 30))
        orig = FakeKeeper.start
        FakeKeeper.start = lambda k: k.on_status("error", "로그인이 만료됐어요")
        self.addCleanup(setattr, FakeKeeper, "start", orig)
        for i in range(1, 4):
            self.app._auto_refresh()
            self.assertEqual(len(FakeKeeper.made), i)
            if i < 3:
                self.assertNotEqual(self.app.acct_status[name]["state"], "error")   # 중간 실패는 조용히
                self.app._auto_refresh()
                self.assertEqual(len(FakeKeeper.made), i)                         # 2분 간격
                self.app._ar[name]["at"] -= 121
        self.assertEqual(self.app.acct_status[name]["state"], "error")             # 3번 다 실패 → 로그인 필요
        self.app._ar[name]["at"] -= 121
        self.app._auto_refresh()
        self.assertEqual(len(FakeKeeper.made), 3)

    def test_screen_refresh_does_not_race_token_refresh(self):
        name = self.app.add_account("A")
        self.app.profiles.path(name).mkdir(parents=True)
        self.eng.link_token(name, jwt("u1", exp=time.time() + 60))   # 1분 남음 → 화면 새로고침은 숨은 Chrome을 안 띄움
        calls = []
        self.eng.refresh_now = lambda n: calls.append(n)
        orig = appmod.Keeper
        made = []
        appmod.Keeper = lambda *a, **kw: made.append(kw) or FakeKeeper(*a, **kw)
        self.addCleanup(setattr, appmod, "Keeper", orig)
        self.app.refresh(name)
        self.assertEqual(calls, [name])
        self.assertEqual(made, [])
        self.eng.accounts[name].exp = time.time() - 10                   # 이미 끝났으면 확인(30초 기다림)
        self.app.refresh(name)
        self.assertEqual(made[-1].get("wait_seconds"), 30)

    def test_auto_refresh_skips_login_needed(self):
        name = self.app.add_account("A")
        self.app.profiles.path(name).mkdir(parents=True)
        self.eng.link_token(name, jwt("u1", exp=time.time() + 30))
        self.app.status(name, "error", "로그인 필요")
        self.app._auto_refresh()
        self.assertEqual(FakeKeeper.made, [])

    # ---- 화면을 닫으면 끄기
    def test_idle_exit(self):
        shut = []
        self.app.request_shutdown = lambda: shut.append(1)
        self.app.auto_exit = True
        now = time.time()
        self.app.last_poll = now
        self.assertEqual(self.app._idle_exit_check(), "")               # 화면 열려 있음
        self.app.bye_at = now + 1                                       # 탭 닫음 → 15초 기다림
        self.assertEqual(self.app._idle_exit_check(), "")
        self.app.last_poll = now + 2                                    # 새로고침(다시 연결) → 취소
        self.app.bye_at = now + 1 - 20
        self.assertEqual(self.app._idle_exit_check(), "")
        self.app.bye_at, self.app.last_poll = now - 20, now - 30         # 닫고 15초 넘게 화면 없음
        self.app.engine.running = True                                  # 예약 중이면 안 끔
        self.assertEqual(self.app._idle_exit_check(), "")
        self.app.engine.running = False
        self.app.login_busy.add("A")                                    # 로그인 창 열려 있으면 안 끔
        self.assertEqual(self.app._idle_exit_check(), "")
        self.app.login_busy.clear()
        self.assertEqual(self.app._idle_exit_check(), "화면을 닫아서")
        self.assertEqual(shut, [1])
        self.assertEqual(self.app._idle_exit_check(), "")               # 한 번만

    def test_idle_exit_without_bye(self):
        shut = []
        self.app.request_shutdown = lambda: shut.append(1)
        self.app.auto_exit = True
        self.app.started_at = self.app.last_poll = time.time() - 200
        self.assertIn("3분", self.app._idle_exit_check())
        self.assertEqual(shut, [1])

    # ---- 공지 팝업 ID 저장
    def test_popup_ids_cached(self):
        calls = []
        self.eng.popup_ids = lambda timeout=5: calls.append(timeout) or ["p1", "p2"]
        self.assertEqual(self.app.popup_ids_cached(), ["p1", "p2"])       # 처음: 받아서 저장
        self.assertEqual(calls, [3])
        self.eng.popup_ids = lambda timeout=5: (time.sleep(2), calls.append(timeout), ["p3"])[2]
        t0 = time.monotonic()
        self.assertEqual(self.app.popup_ids_cached(), ["p1", "p2"])       # 다음: 저장된 것 바로(뒤에서 갱신)
        self.assertLess(time.monotonic() - t0, 0.5)

    # ---- 오류 자동 전송
    def test_error_sends_context_once(self):
        name = self.app.add_account("A")
        self.app.settings["accounts"][0]["login_id"] = "a@x.com"
        for i in range(50):
            self.app.journal.log(name, f"평범한 기록 {i}")
        self.app.journal.log(name, "슬롯 조회 실패 12", "error")
        self.app.journal.log(name, "슬롯 조회 실패 13", "error")        # 숫자만 다른 같은 문제 → 10분에 한 번
        issues = [q for q in self.app.cloud.queue if q["kind"] == "issue"]
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0]["account"], "a@x.com")
        self.assertEqual(len(issues[0]["context"]), 40)
        self.assertEqual(issues[0]["context"][-1]["acct"], "a@x.com")

    def test_exception_recorded_with_location(self):
        try:
            {}["x"]
        except KeyError as exc:
            self.app.journal.exception("테스트", exc)
        issues = [q for q in self.app.cloud.queue if q["kind"] == "issue"]
        self.assertIn("KeyError", issues[-1]["msg"])
        self.assertIn("test_ops.py", issues[-1]["msg"])
        self.assertTrue(any(r["cat"] == "오류" for r in issues[-1]["context"]))

    def test_client_error(self):
        self.app.client_error({"msg": "TypeError: x is undefined\n at y", "src": "http://127.0.0.1:8780/static/app.js", "line": 12})
        msg = [q for q in self.app.cloud.queue if q["kind"] == "issue"][-1]["msg"]
        self.assertIn("app.js:12", msg)

    # ---- 자동 업데이트
    def make_root(self, version):
        root = Path(self.tmp.name) / f"root_{version}"
        for rel in updater.program_files(ROOT):
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(ROOT / rel, root / rel)
        src = (root / "app.py").read_text(encoding="utf-8")
        (root / "app.py").write_text(src.replace(f'VERSION = "{appmod.VERSION}"', f'VERSION = "{version}"'), encoding="utf-8")
        (root / "data").mkdir()
        (root / "data" / "keep.txt").write_text("계정", encoding="utf-8")
        (root / "cloud.json").write_text("{}", encoding="utf-8")
        return root

    def test_package_excludes_private_files(self):
        root = self.make_root("9.0")
        raw, sha = updater.build_package(root)
        names = zipfile.ZipFile(io.BytesIO(raw)).namelist()
        self.assertIn("app.py", names)
        self.assertIn("core/engine.py", names)
        self.assertFalse(any(n.startswith("data/") or n == "cloud.json" or n.endswith(".bat") for n in names))
        self.assertEqual(updater.verify(raw, sha, "9.0"), names)
        with self.assertRaises(updater.UpdateError):
            updater.verify(raw, "0" * 64, "9.0")
        with self.assertRaises(updater.UpdateError):
            updater.verify(raw, sha, "9.1")

    def test_rejects_bad_paths(self):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("app.py", 'VERSION = "9.0"\n')
            z.writestr("../evil.py", "x")
        raw = buf.getvalue()
        import hashlib
        with self.assertRaises(updater.UpdateError):
            updater.verify(raw, hashlib.sha256(raw).hexdigest(), "9.0")

    def test_publish_and_auto_apply(self):
        new_root = self.make_root("2099.1.1")
        self.app.root = new_root                 # 관리자 PC: 새 버전 파일
        orig_v = appmod.VERSION
        appmod.VERSION = "2099.1.1"
        self.addCleanup(setattr, appmod, "VERSION", orig_v)
        self.app.admin_login("pw12")
        self.app.cloud.heartbeat({})
        self.app.admin_publish({"notes": "시계 보정", "auto": True})
        with self.assertRaises(ValueError):       # 같은 버전 다시 배포 막기
            self.app.cloud.heartbeat({})
            self.app.admin_publish({})
        appmod.VERSION = orig_v                  # 다른 PC(구버전)
        old_root = self.make_root(orig_v)
        self.app.root = old_root
        restarted = []
        self.app.restart_hook = lambda: restarted.append(1)
        self.app.engine.running = True           # 예약 중이면 기다림
        self.app.cloud.heartbeat({})
        self.app._cloud_control(self.app.cloud.control)
        self.assertEqual(self.app.update["status"], "wait")
        self.assertEqual(restarted, [])
        self.app.engine.running = False
        self.app._cloud_control(self.app.cloud.control)
        self.assertEqual(restarted, [1])
        self.assertIn('VERSION = "2099.1.1"', (old_root / "app.py").read_text(encoding="utf-8"))
        self.assertEqual((old_root / "data" / "keep.txt").read_text(encoding="utf-8"), "계정")   # data는 그대로
        self.assertEqual((old_root / "cloud.json").read_text(encoding="utf-8"), "{}")
        self.assertEqual(len(list((self.data / "backup").glob("*.zip"))), 1)

    def test_bad_release_not_applied_and_reported(self):
        self.sb.releases["2099.1.1"] = {"version": "2099.1.1", "sha256": "0" * 64, "auto": True, "notes": "",
                                        "zip_b64": base64.b64encode(b"not zip").decode(), "seq": 0}
        old_root = self.make_root(appmod.VERSION)
        self.app.root = old_root
        self.app.restart_hook = lambda: self.fail("다시 시작하면 안 됨")
        self.app.cloud.heartbeat({})
        self.app._cloud_control(self.app.cloud.control)
        self.assertEqual(self.app.update["status"], "fail")
        self.assertTrue(any("업데이트 실패" in q.get("msg", "") for q in self.app.cloud.queue))
        self.app._cloud_control(self.app.cloud.control)       # 1시간 안엔 다시 안 받음
        self.assertEqual(self.sb.calls.count("app_get_release"), 1)


if __name__ == "__main__":
    unittest.main()
