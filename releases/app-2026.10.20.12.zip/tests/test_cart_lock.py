"""장바구니 자동취소 시각: 사이트가 주는 lockedUntil을 쓰고, 없으면 담긴 시각 + 5시간으로 추정."""
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.engine import Engine, _cart_item_info
from core.journal import Journal
from core.rules import KST


class CartLockTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.server_now = datetime.now(KST) + timedelta(seconds=2)       # 서버 시계가 PC보다 2초 빠름
        self.eng = Engine(Journal(Path(self.tmp.name)), lambda tok: None, now=lambda: self.server_now)
        self.eng.ensure_account("A")
        self.a = self.eng.accounts["A"]

    def tearDown(self):
        self.eng.journal.close()
        self.tmp.cleanup()

    def test_item_info_reads_locked_until(self):
        sid, info = _cart_item_info({"slotId": "s1", "lockedUntil": 1792500000000, "_creationTime": 1792480000000.5})
        self.assertEqual(sid, "s1")
        self.assertEqual(info["locked_until"], 1792500000000)

    def test_site_time_used_when_present(self):
        lock = (self.server_now.timestamp() + 3600) * 1000
        self.a.cart_ids = {"s1"}
        self.a.cart_info["s1"] = {"locked_until": lock, "created": (time.time() - 100) * 1000}
        row = self.eng.snapshot()["accounts"]["A"]["cart"][0]
        self.assertEqual(row["exact_time"], "site")
        self.assertAlmostEqual(row["left_s"], 3600, delta=2)

    def test_estimate_when_missing(self):
        self.a.cart_ids = {"s2"}
        self.a.cart_info["s2"] = {"created": (time.time() - 3600) * 1000}
        row = self.eng.snapshot()["accounts"]["A"]["cart"][0]
        self.assertEqual(row["exact_time"], "created")
        self.assertAlmostEqual(row["left_s"], 4 * 3600, delta=5)


if __name__ == "__main__":
    unittest.main()
