import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import app as appmod
from core import ghupdate, updater


class Resp:
    def __init__(self, status=200, body=b"", js=None):
        self.status_code, self.content, self._js = status, body, js

    def json(self):
        return self._js

    def raise_for_status(self):
        if self.status_code >= 400:
            raise ghupdate.requests.HTTPError(str(self.status_code))


class Sess:
    def __init__(self, routes):
        self.routes, self.calls = routes, []

    def get(self, url, **kw):
        self.calls.append(url)
        return self.routes[url]


class ManifestTest(unittest.TestCase):
    def good(self, **kw):
        m = {"version": "2099.1.1", "sha256": "a" * 64, "file": "releases/app-2099.1.1.zip", "notes": "n"}
        m.update(kw)
        return m

    def test_ok(self):
        s = Sess({ghupdate.RAW + ghupdate.MANIFEST: Resp(js=self.good())})
        m = ghupdate.manifest(s)
        self.assertEqual(m["version"], "2099.1.1")
        self.assertTrue(m["auto"])

    def test_rejects_bad_file_path(self):
        for bad in ("../app.py", "releases/x.exe", "https://evil/app.zip"):
            s = Sess({ghupdate.RAW + ghupdate.MANIFEST: Resp(js=self.good(file=bad))})
            with self.assertRaises(ghupdate.GhError):
                ghupdate.manifest(s)

    def test_rejects_bad_sha_and_version(self):
        for kw in ({"sha256": "zz"}, {"version": "1.0; rm"}):
            s = Sess({ghupdate.RAW + ghupdate.MANIFEST: Resp(js=self.good(**kw))})
            with self.assertRaises(ghupdate.GhError):
                ghupdate.manifest(s)

    def test_missing(self):
        s = Sess({ghupdate.RAW + ghupdate.MANIFEST: Resp(status=404)})
        with self.assertRaises(ghupdate.GhError):
            ghupdate.manifest(s)


class AppGithubTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.prog = d / "prog"
        (self.prog / "core").mkdir(parents=True)
        (self.prog / "app.py").write_text(f'VERSION = "{appmod.VERSION}"\n', encoding="utf-8")
        (self.prog / "core" / "x.py").write_text("old\n", encoding="utf-8")
        self.a = appmod.App(d / "data", start_threads=False)
        self.a.root = self.prog
        self.restarts = []
        self.a.restart_hook = lambda: self.restarts.append(1)

    def tearDown(self):
        self.tmp.cleanup()

    def package(self, version):
        src = Path(self.tmp.name) / f"src{version}"
        (src / "core").mkdir(parents=True)
        (src / "app.py").write_text(f'VERSION = "{version}"\n', encoding="utf-8")
        (src / "core" / "x.py").write_text("new\n", encoding="utf-8")
        return updater.build_package(src)

    def manifest_for(self, version, raw, sha, auto=True):
        return {"version": version, "sha256": sha, "file": f"releases/app-{version}.zip", "notes": "고침", "auto": auto, "size": len(raw)}

    def test_newer_github_applies_and_restarts(self):
        raw, sha = self.package("2099.1.1")
        with mock.patch.object(ghupdate, "manifest", return_value=self.manifest_for("2099.1.1", raw, sha)), \
             mock.patch.object(ghupdate, "download", return_value=raw):
            self.assertTrue(self.a.check_github())
        self.assertEqual((self.prog / "core" / "x.py").read_text(), "new\n")
        self.assertEqual(self.restarts, [1])
        self.assertEqual(self.a.update["source"], "github")

    def test_same_version_does_nothing(self):
        raw, sha = self.package(appmod.VERSION)
        with mock.patch.object(ghupdate, "manifest", return_value=self.manifest_for(appmod.VERSION, raw, sha)), \
             mock.patch.object(ghupdate, "download") as dl:
            self.a.check_github()
        dl.assert_not_called()
        self.assertEqual(self.a.update["available"], "")

    def test_waits_while_running(self):
        raw, sha = self.package("2099.1.1")
        self.a.engine.running = True
        with mock.patch.object(ghupdate, "manifest", return_value=self.manifest_for("2099.1.1", raw, sha)), \
             mock.patch.object(ghupdate, "download") as dl:
            self.a.check_github()
        dl.assert_not_called()
        self.assertEqual(self.a.update["status"], "wait")

    def test_tampered_zip_rejected(self):
        raw, sha = self.package("2099.1.1")
        with mock.patch.object(ghupdate, "manifest", return_value=self.manifest_for("2099.1.1", raw, hashlib.sha256(b"x").hexdigest())), \
             mock.patch.object(ghupdate, "download", return_value=raw):
            self.a.check_github()
        self.assertEqual((self.prog / "core" / "x.py").read_text(), "old\n")
        self.assertEqual(self.a.update["status"], "fail")
        self.assertEqual(self.restarts, [])

    def test_cloud_older_does_not_hide_github(self):
        raw, sha = self.package("2099.1.1")
        self.a._check_update({"latest_version": "2000.1.1", "release_sha": "b" * 64, "release_auto": True})
        with mock.patch.object(ghupdate, "manifest", return_value=self.manifest_for("2099.1.1", raw, sha, auto=False)):
            self.a.check_github()
        self.a._check_update({"latest_version": "2000.1.1", "release_sha": "b" * 64, "release_auto": True})
        self.assertEqual(self.a.update["available"], "2099.1.1")

    def test_network_error_is_quiet(self):
        with mock.patch.object(ghupdate, "manifest", side_effect=ghupdate.requests.ConnectionError("x")):
            self.assertFalse(self.a.check_github())
        self.assertEqual(self.a.update["available"], "")


if __name__ == "__main__":
    unittest.main()
