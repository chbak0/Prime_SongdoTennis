"""러시 병렬성 오프라인 시뮬레이션(10/20 평일 주간 상황 재현).

- 계정 3개가 서로 다른 (코트, 날짜)를 목표로 둠, 실시간(WS) 슬롯 구독은 아무것도 주지 않음(실제 관찰과 같음)
- HTTP 요청은 실제처럼 하나의 줄(초당 4회)과 왕복 지연을 거침
- 세 곳이 같은 순간에 열림 → 세 계정의 담기 요청이 얼마나 벌어지는지, 러시 중 계정 새로고침이 줄을 차지하는지 확인
"""
import asyncio
import sys
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.engine import CART_IDS_Q, CART_LIST_Q, RES_Q, SLOTS_Q, DONE, FALLBACK_FACILITIES, Engine, Target
from core.journal import Journal
from core.transport import RateGate, check_allowed
from test_engine import DAY, FakeServer, FakeTransport, jwt
import tempfile

RTT = 0.12


class GatedTransport(FakeTransport):
    """실제 Transport처럼 HTTP 조회는 공용 줄(RateGate)을 거치고 왕복 지연이 있다. 슬롯 실시간 구독은 조용함."""
    gate: RateGate = None
    log: list = None

    async def subscribe(self, path, args):
        if path == SLOTS_Q:
            await asyncio.Event().wait()          # 아무것도 오지 않음
        async for v in super().subscribe(path, args):
            yield v

    async def query(self, path, args, timeout=4.0, urgent=False, skip_gate=False):
        check_allowed("query", path)
        wait = self.gate.reserve(urgent, skip_gate)
        t = time.monotonic()
        await asyncio.sleep(wait + RTT)
        self.log.append((t + wait, path, urgent, args.get("facilityId", "")[-3:]))
        return self.server.query(self.token, path, args)


class RushParallelTest(unittest.TestCase):
    def test_three_accounts_add_nearly_together(self):
        tmp = tempfile.TemporaryDirectory()
        server = FakeServer()
        groups = [(12, DAY), (13, DAY), (14, DAY)]
        for c, d in groups:
            server.make_slots(FALLBACK_FACILITIES[c], d, open_=False)
        log = []
        GatedTransport.log = log
        timing = {"prepare_minutes": 0.1, "pre_seconds": 3, "rush_seconds": 8, "after_minutes": 0, "rush_poll": 1.0,
                  "verify_seconds": 1.5, "now_delay": 0.3, "http_rps": 4.0, "reject_cooldown": 0.3}
        journal = Journal(Path(tmp.name))
        eng = Engine(journal, lambda tok: GatedTransport(server, tok), timing=timing)
        eng.facilities = dict(FALLBACK_FACILITIES)
        GatedTransport.gate = eng.gate                # 실제처럼 엔진 전체가 한 줄을 같이 씀
        for n in ("A", "B", "C"):
            eng.link_token(n, jwt("user-" + n))
        targets = [Target(account=n, date=d, court=c, start=600, priority=0) for n, (c, d) in zip("ABC", groups)]
        events = []
        journal.listeners.append(lambda kind, e: events.append((time.monotonic(), kind, e)) if False else None)
        sent = {}
        orig = eng._add

        async def spy(acct, st, sid):
            sent.setdefault(acct.name, time.monotonic())
            return await orig(acct, st, sid)
        eng._add = spy
        from datetime import datetime, timedelta
        from core.rules import KST
        at = datetime.now(KST) + timedelta(seconds=9)
        eng.arm(targets, test_at=at)                # 9초 뒤 오픈(준비 조회가 끝난 뒤), 3초 전부터 칸 조회
        time.sleep(10.3)                            # 오픈 1.3초 뒤 사이트가 실제로 엶(10/20엔 12초 뒤)
        opened = time.monotonic()
        GatedTransport.opened = opened
        for c, d in groups:                         # 세 곳이 같은 순간에 열림
            server.open_all(FALLBACK_FACILITIES[c], d)
        end = time.time() + 14
        while time.time() < end and eng.running:
            time.sleep(0.05)
        try:
            self.assertEqual(sorted(sent), ["A", "B", "C"])
            spread = max(sent.values()) - min(sent.values())
            first = min(sent.values()) - opened
            rush = [x for x in log if x[0] >= opened - 1 and x[0] <= opened + 3]
            acct_q = [x for x in rush if x[1] in (CART_IDS_Q, CART_LIST_Q, RES_Q)]
            print(f"\n  열림→첫 담기 {first:.2f}s · 세 계정 담기 벌어짐 {spread:.2f}s · 러시 3초 계정조회 {len(acct_q)}건")
            self.assertLess(spread, 0.45)
            self.assertTrue(all(st.status == DONE for st in eng.states.values()))
            # 정기 새로고침 없음: 목록·예약 조회는 '이 계정 목표가 다 담긴 뒤 1번'뿐(계정당 최대 1번씩)
            self.assertLessEqual(len([x for x in acct_q if x[1] == RES_Q]), 3)
            self.assertLessEqual(len([x for x in acct_q if x[1] == CART_LIST_Q]), 3)
        finally:
            eng.stop()
            journal.close()
            tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
