"""장바구니 '시간 연장': 빼고 바로 다시 담기, 같은 칸 1번만, 빼지 못하면 그대로 둠, 다시 못 담으면 잃었다고 알림."""
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core.engine import Engine, FALLBACK_FACILITIES
from core.journal import Journal
from core.transport import Rejected
from test_engine import DAY, FAC12, FakeServer, FakeTransport, jwt


class ExtendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.server = FakeServer()
        self.server.make_slots(FAC12, DAY, open_=True)
        self.eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(self.server, tok))
        self.eng.facilities = dict(FALLBACK_FACILITIES)
        self.app = appmod.App(data=d, engine=self.eng, start_threads=False)
        self.app.add_account("A")
        self.token = jwt("user-a")
        self.eng.link_token("A", self.token)
        self.sid = f"{FAC12[-4:]}-{DAY}-600"
        self.server.mutation(self.token, "cart/mutations:add", {"slotId": self.sid})
        self.eng.refresh_now("A").result(5)
        self.assertIn(self.sid, self.eng.accounts["A"].cart_ids)

    def tearDown(self):
        self.eng.stop()
        self.app.journal.close()
        self.tmp.cleanup()

    def test_extend_once(self):
        out = self.app.extend_cart("A", self.sid)
        self.assertEqual(out["result"], "ok")
        self.assertIn(self.sid, self.server.carts[self.token])
        calls = [c[1] for c in self.server.calls if c[0] == "mutation"]
        self.assertEqual(calls[-2:], ["cart/mutations:remove", "cart/mutations:add"])
        with self.assertRaises(ValueError):                       # 같은 칸 두 번째는 막음
            self.app.extend_cart("A", self.sid)
        acct = [a for a in self.app.state()["accounts"] if a["name"] == "A"][0]
        self.assertTrue(acct["cart"][0]["extended"])

    def test_lost_when_someone_grabs(self):
        orig = self.server.mutation

        def mut(token, path, args):
            r = orig(token, path, args)
            if path == "cart/mutations:remove":                   # 빼는 순간 다른 사람이 담음
                orig("other", "cart/mutations:add", {"slotId": self.sid})
            return r
        self.server.mutation = mut
        out = self.app.extend_cart("A", self.sid)
        self.assertEqual(out["result"], "lost")
        self.assertNotIn(self.sid, self.eng.accounts["A"].cart_ids)

    def test_kept_when_remove_fails(self):
        orig = self.server.mutation

        def mut(token, path, args):
            if path == "cart/mutations:remove":
                raise Rejected("빼기 오류")
            return orig(token, path, args)
        self.server.mutation = mut
        out = self.app.extend_cart("A", self.sid)
        self.assertEqual(out["result"], "kept")
        self.assertIn(self.sid, self.server.carts[self.token])

    def test_not_during_run(self):
        self.eng.running = True
        with self.assertRaises(ValueError):
            self.app.extend_cart("A", self.sid)
        self.eng.running = False


if __name__ == "__main__":
    unittest.main()
