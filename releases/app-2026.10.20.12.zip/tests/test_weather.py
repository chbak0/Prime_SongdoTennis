"""날씨(Open-Meteo) 정리·저장·실패 처리 오프라인 테스트."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import requests

from core import weather


def sample_raw(days=2):
    times = [f"2026-10-{15 + d:02d}T{h:02d}:00" for d in range(days) for h in range(24)]
    n = len(times)
    return {"timezone": "Asia/Seoul",
            "current": {"time": "2026-10-15T09:45", "interval": 900, "temperature_2m": 17.34, "apparent_temperature": 16.1,
                        "weather_code": 2, "precipitation": 0.0, "wind_speed_10m": 3.2},
            "hourly": {"time": times, "temperature_2m": [10 + i % 24 * 0.5 for i in range(n)],
                       "precipitation_probability": [i % 100 for i in range(n)], "precipitation": [0.0] * n,
                       "weather_code": [61 if i % 24 == 14 else 1 for i in range(n)], "wind_speed_10m": [2.5] * n},
            "daily": {"time": [f"2026-10-{15 + d:02d}" for d in range(days)], "weather_code": [2, 61],
                      "temperature_2m_max": [21.4, 18.0], "temperature_2m_min": [12.1, 11.0],
                      "precipitation_probability_max": [10, 70], "precipitation_sum": [0.0, 4.2]}}


class Sess:
    def __init__(self, raw=None, fail=False):
        self.raw, self.fail, self.calls = raw, fail, 0

    def get(self, url, params=None, timeout=None):
        self.calls += 1
        if self.fail:
            raise requests.ConnectionError("down")
        raw = self.raw

        class R:
            def raise_for_status(self):
                pass

            def json(self):
                return raw
        return R()


class WeatherTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.data = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_normalize_keeps_court_hours(self):
        out = weather.normalize(sample_raw(), now=1.0)
        self.assertEqual(out["current"]["temp"], 17.3)
        self.assertEqual(out["days"]["2026-10-16"]["pop"], 70)
        self.assertIn("2026-10-15T06", out["hours"])
        self.assertIn("2026-10-15T22", out["hours"])
        self.assertNotIn("2026-10-15T03", out["hours"])
        self.assertEqual(out["hours"]["2026-10-15T14"][2], 61)

    def test_fetch_saves_and_survives_failure(self):
        w = weather.Weather(self.data, session=Sess(sample_raw()))
        self.assertTrue(w.due())
        w.fetch()
        self.assertFalse(w.due())
        w2 = weather.Weather(self.data, session=Sess(fail=True))   # 다시 켜도 저장된 것 사용
        self.assertEqual(w2.data["current"]["temp"], 17.3)
        with self.assertRaises(requests.RequestException):
            w2.fetch()
        self.assertEqual(w2.data["current"]["temp"], 17.3)

    def test_empty_response_rejected(self):
        w = weather.Weather(self.data, session=Sess({}))
        with self.assertRaises(ValueError):
            w.fetch()
        self.assertIsNone(w.data)

    def test_params(self):
        self.assertEqual(weather.PARAMS["timezone"], "Asia/Seoul")
        self.assertEqual(weather.PARAMS["forecast_days"], 16)


if __name__ == "__main__":
    unittest.main()
