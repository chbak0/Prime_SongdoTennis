-- 송도테니스 장바구니 도우미 · 관리자 대시보드용 Supabase 설정
-- Supabase 대시보드 → SQL Editor → 이 파일 전체를 붙여 넣고 Run. 여러 번 실행해도 안전합니다.
--
-- 보안 구조
--  · 표(table)는 RLS를 켜고 정책을 두지 않아서 공개 키(anon key)로는 직접 읽기·쓰기 불가.
--  · 프로그램은 아래 app_* 함수로만 '자기 PC 기록'을 올리고 제어 값을 받아요.
--  · 전체 기록 조회와 원격 제어는 admin_* 함수뿐이고, 관리자 비밀번호(bcrypt 해시로 보관)가 맞아야 동작해요.
--  · 토큰·비밀번호·전화번호는 올리지 않아요. 계정은 사이트 아이디(이메일)로만 구분해요.

create extension if not exists pgcrypto;

create table if not exists public.installs (
  id          uuid primary key,
  pc          text not null default '',
  version     text not null default '',
  os          text not null default '',
  accounts    jsonb not null default '[]',
  targets     int not null default 0,
  running     boolean not null default false,
  state       text not null default '',
  first_seen  timestamptz not null default now(),
  last_seen   timestamptz not null default now()
);

create table if not exists public.runs (
  id          bigint generated always as identity primary key,
  install_id  uuid not null,
  run_key     text not null,
  started     timestamptz,
  ended       timestamptz,
  test        boolean not null default false,
  report      jsonb not null,
  created_at  timestamptz not null default now(),
  unique (install_id, run_key)
);
create index if not exists runs_started_idx on public.runs (started desc);

create table if not exists public.issues (
  id          bigint generated always as identity primary key,
  install_id  uuid not null,
  at          timestamptz not null default now(),
  level       text not null,
  account     text not null default '',
  msg         text not null
);
create index if not exists issues_at_idx on public.issues (at desc);
alter table public.issues add column if not exists context jsonb;      -- 오류 직전 기록(자세한 로그 몇십 줄)
alter table public.installs add column if not exists clock_ms int;     -- PC 시계 오차(서버-PC, ms)

-- 자동 업데이트: 관리자가 올린 프로그램 묶음(zip, base64). 최근 3개만 보관
create table if not exists public.releases (
  version     text primary key,
  notes       text not null default '',
  sha256      text not null,
  size        int not null,
  zip_b64     text not null,
  auto        boolean not null default true,
  created_at  timestamptz not null default now()
);

create table if not exists public.control (
  id           int primary key default 1 check (id = 1),
  stop_all     boolean not null default false,
  stop_ids     uuid[] not null default '{}',
  min_version  text not null default '',
  notice       text not null default '',
  notice_id    int not null default 0,
  updated_at   timestamptz not null default now()
);
insert into public.control (id) values (1) on conflict do nothing;
alter table public.control add column if not exists share_calendar boolean not null default false;

-- 각 PC 계정의 예약·장바구니(이번 달~다음 달). PC마다 통째로 바꿔 넣음
create table if not exists public.bookings (
  install_id  uuid not null,
  account     text not null default '',
  kind        text not null,              -- res(예약) | cart(장바구니)
  date        date not null,
  start_min   int,
  end_min     int,
  court       int,
  status      text not null default '',
  synced_at   timestamptz,
  updated_at  timestamptz not null default now()
);
create index if not exists bookings_install_idx on public.bookings (install_id);
create index if not exists bookings_date_idx on public.bookings (date);

create table if not exists public.admin_secret (
  id    int primary key default 1 check (id = 1),
  hash  text not null
);

alter table public.installs     enable row level security;
alter table public.runs         enable row level security;
alter table public.issues       enable row level security;
alter table public.control      enable row level security;
alter table public.admin_secret enable row level security;
alter table public.bookings     enable row level security;
alter table public.releases     enable row level security;
revoke all on public.installs, public.runs, public.issues, public.control, public.admin_secret, public.bookings, public.releases from anon, authenticated;

-- ---------------------------------------------------------------- 내부 도우미
create or replace function public._admin_ok(p_pw text) returns boolean
language sql security definer set search_path = public, extensions as $$
  select exists (select 1 from public.admin_secret where id = 1 and hash = crypt(coalesce(p_pw, ''), hash));
$$;

create or replace function public._control_json(p_id uuid) returns jsonb
language sql security definer set search_path = public, extensions as $$
  select jsonb_build_object('latest_version', r.version, 'release_sha', r.sha256, 'release_auto', r.auto, 'release_notes', r.notes,
                            'stop', c.stop_all or (p_id is not null and p_id = any(c.stop_ids)),
                            'stop_all', c.stop_all, 'min_version', c.min_version, 'share_calendar', c.share_calendar,
                            'notice', c.notice, 'notice_id', c.notice_id, 'server_time', now())
  from public.control c
  left join lateral (select version, sha256, auto, notes from public.releases order by created_at desc limit 1) r on true
  where c.id = 1;
$$;

create or replace function public._admin_check(p_pw text) returns void
language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from public.admin_secret where id = 1) then
    raise exception 'no_admin';
  end if;
  if not public._admin_ok(p_pw) then
    perform pg_sleep(0.5);
    raise exception 'denied';
  end if;
end $$;

-- ---------------------------------------------------------------- 프로그램(각 PC)이 쓰는 함수
drop function if exists public.app_heartbeat(uuid, text, text, text, jsonb, int, boolean, text);
create or replace function public.app_heartbeat(p_id uuid, p_pc text, p_version text, p_os text,
                                                p_accounts jsonb, p_targets int, p_running boolean, p_state text,
                                                p_clock_ms int default null)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if p_id is null then raise exception 'bad_id'; end if;
  if jsonb_typeof(coalesce(p_accounts, '[]')) <> 'array' or jsonb_array_length(coalesce(p_accounts, '[]')) > 20 then
    raise exception 'bad_accounts';
  end if;
  insert into public.installs as i (id, pc, version, os, accounts, targets, running, state, last_seen, clock_ms)
  values (p_id, left(coalesce(p_pc, ''), 60), left(coalesce(p_version, ''), 20), left(coalesce(p_os, ''), 40),
          coalesce(p_accounts, '[]'), greatest(0, least(coalesce(p_targets, 0), 999)), coalesce(p_running, false),
          left(coalesce(p_state, ''), 60), now(),
          case when p_clock_ms is null then null else greatest(-600000, least(p_clock_ms, 600000)) end)
  on conflict (id) do update set pc = excluded.pc, version = excluded.version, os = excluded.os,
    accounts = excluded.accounts, targets = excluded.targets, running = excluded.running,
    state = excluded.state, last_seen = now(), clock_ms = coalesce(excluded.clock_ms, i.clock_ms);
  return public._control_json(p_id);
end $$;

create or replace function public.app_report(p_id uuid, p_run_key text, p_report jsonb)
returns boolean language plpgsql security definer set search_path = public, extensions as $$
begin
  if p_id is null or p_report is null or octet_length(p_report::text) > 300000 then raise exception 'bad_report'; end if;
  if not exists (select 1 from public.installs where id = p_id) then raise exception 'unknown_install'; end if;
  insert into public.runs (install_id, run_key, started, ended, test, report)
  values (p_id, left(p_run_key, 40), (p_report->>'started')::timestamptz, (p_report->>'ended')::timestamptz,
          coalesce((p_report->>'test')::boolean, false), p_report)
  on conflict (install_id, run_key) do nothing;
  return true;
end $$;

drop function if exists public.app_issue(uuid, text, text, text, timestamptz);
create or replace function public.app_issue(p_id uuid, p_level text, p_account text, p_msg text, p_at timestamptz default null,
                                            p_context jsonb default null)
returns boolean language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from public.installs where id = p_id) then raise exception 'unknown_install'; end if;
  -- PC 한 대가 한 시간에 200건 넘게 올리면 버림(폭주 방지)
  if (select count(*) from public.issues where install_id = p_id and at > now() - interval '1 hour') >= 200 then
    return false;
  end if;
  insert into public.issues (install_id, at, level, account, msg, context)
  values (p_id, least(coalesce(p_at, now()), now()), left(coalesce(p_level, 'info'), 10),
          left(coalesce(p_account, ''), 120), left(coalesce(p_msg, ''), 300),
          case when jsonb_typeof(p_context) = 'array' and octet_length(p_context::text) <= 40000 then p_context end);
  return true;
end $$;

-- 이번 달 1일(한국 시간) ~ 다다음 달 1일 전까지
create or replace function public._cal_from() returns date language sql stable as $$
  select (date_trunc('month', now() at time zone 'Asia/Seoul'))::date;
$$;

create or replace function public._bookings_json(p_me uuid) returns jsonb
language sql security definer set search_path = public, extensions as $$
  select coalesce(jsonb_agg(jsonb_build_object('account', b.account, 'kind', b.kind, 'date', b.date, 'start_min', b.start_min,
                                               'end_min', b.end_min, 'court', b.court, 'status', b.status, 'synced_at', b.synced_at,
                                               'install_id', b.install_id, 'pc', i.pc, 'mine', b.install_id = p_me)
                            order by b.date, b.start_min, b.court), '[]')
  from public.bookings b left join public.installs i on i.id = b.install_id
  where b.date >= public._cal_from() and b.date < (public._cal_from() + interval '2 months')::date;
$$;

create or replace function public.app_bookings(p_id uuid, p_items jsonb)
returns int language plpgsql security definer set search_path = public, extensions as $$
declare n int;
begin
  if not exists (select 1 from public.installs where id = p_id) then raise exception 'unknown_install'; end if;
  if jsonb_typeof(coalesce(p_items, '[]')) <> 'array' or jsonb_array_length(coalesce(p_items, '[]')) > 300 then
    raise exception 'bad_items';
  end if;
  delete from public.bookings where install_id = p_id;
  insert into public.bookings (install_id, account, kind, date, start_min, end_min, court, status, synced_at)
  select p_id, left(coalesce(x.account, ''), 120), x.kind, x.date, x.start_min, x.end_min, x.court,
         left(coalesce(x.status, ''), 30), x.synced_at
  from jsonb_to_recordset(coalesce(p_items, '[]')) as x(account text, kind text, date date, start_min int, end_min int,
                                                          court int, status text, synced_at timestamptz)
  where x.kind in ('res', 'cart') and x.date is not null
    and x.date >= public._cal_from() and x.date < (public._cal_from() + interval '2 months')::date;
  get diagnostics n = row_count;
  return n;
end $$;

-- 관리자가 '홈 달력 배포'를 켰을 때만 모임 일정(모든 PC의 예약·장바구니)을 돌려줌
create or replace function public.app_shared_calendar(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from public.installs where id = p_id) then raise exception 'unknown_install'; end if;
  if not (select share_calendar from public.control where id = 1) then return null; end if;
  return jsonb_build_object('at', now(), 'items', public._bookings_json(p_id));
end $$;

create or replace function public.app_get_release(p_id uuid, p_version text)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  if not exists (select 1 from public.installs where id = p_id) then raise exception 'unknown_install'; end if;
  return (select jsonb_build_object('version', version, 'sha256', sha256, 'size', size, 'zip_b64', zip_b64)
          from public.releases where version = p_version);
end $$;

-- ---------------------------------------------------------------- 관리자 함수
create or replace function public.admin_init(p_pw text) returns boolean
language plpgsql security definer set search_path = public, extensions as $$
begin
  if length(coalesce(p_pw, '')) < 4 then raise exception 'short_pw'; end if;
  insert into public.admin_secret (id, hash) values (1, crypt(p_pw, gen_salt('bf', 10)))
  on conflict (id) do nothing;
  return public._admin_ok(p_pw);
end $$;

create or replace function public.admin_dashboard(p_pw text, p_days int default 60)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare d int := greatest(1, least(coalesce(p_days, 60), 365));
begin
  perform public._admin_check(p_pw);
  delete from public.issues where at < now() - interval '120 days';
  delete from public.runs where created_at < now() - interval '400 days';
  return jsonb_build_object(
    'server_time', now(),
    'control', (select to_jsonb(c) from public.control c where c.id = 1),
    'installs', coalesce((select jsonb_agg(to_jsonb(i) order by i.last_seen desc) from public.installs i), '[]'),
    'runs', coalesce((select jsonb_agg(jsonb_build_object('install_id', r.install_id, 'started', r.started, 'ended', r.ended,
                                                          'test', r.test, 'report', r.report) order by r.started desc)
                      from (select * from public.runs where started > now() - make_interval(days => d)
                            order by started desc limit 600) r), '[]'),
    'issues', coalesce((select jsonb_agg((to_jsonb(x) - 'context') || jsonb_build_object('has_ctx', x.context is not null) order by x.at desc)
                        from (select * from public.issues where at > now() - make_interval(days => d)
                              order by at desc limit 400) x), '[]'),
    'releases', coalesce((select jsonb_agg(jsonb_build_object('version', version, 'notes', notes, 'size', size, 'auto', auto,
                                                              'created_at', created_at) order by created_at desc)
                          from public.releases), '[]'),
    'bookings', public._bookings_json(null));
end $$;

create or replace function public.admin_control(p_pw text, p_patch jsonb)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  perform public._admin_check(p_pw);
  update public.control c set
    stop_all    = coalesce((p_patch->>'stop_all')::boolean, c.stop_all),
    share_calendar = coalesce((p_patch->>'share_calendar')::boolean, c.share_calendar),
    stop_ids    = case when p_patch ? 'stop_ids'
                       then array(select jsonb_array_elements_text(p_patch->'stop_ids'))::uuid[] else c.stop_ids end,
    min_version = case when p_patch ? 'min_version' then left(coalesce(p_patch->>'min_version', ''), 20) else c.min_version end,
    notice      = case when p_patch ? 'notice' then left(coalesce(p_patch->>'notice', ''), 300) else c.notice end,
    notice_id   = case when p_patch ? 'notice' and coalesce(p_patch->>'notice', '') <> '' then c.notice_id + 1 else c.notice_id end,
    updated_at  = now()
  where c.id = 1;
  return (select to_jsonb(c) from public.control c where c.id = 1);
end $$;

create or replace function public.admin_issue(p_pw text, p_issue bigint)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
begin
  perform public._admin_check(p_pw);
  return (select to_jsonb(x) from public.issues x where x.id = p_issue);
end $$;

create or replace function public.admin_publish_release(p_pw text, p_version text, p_notes text, p_sha256 text,
                                                        p_zip_b64 text, p_auto boolean default true)
returns jsonb language plpgsql security definer set search_path = public, extensions as $$
declare raw bytea;
begin
  perform public._admin_check(p_pw);
  if p_version !~ '^[0-9]+(\.[0-9]+){0,3}$' then raise exception 'bad_version'; end if;
  raw := decode(p_zip_b64, 'base64');
  if octet_length(raw) > 5000000 then raise exception 'too_big'; end if;
  if encode(digest(raw, 'sha256'), 'hex') <> lower(p_sha256) then raise exception 'bad_sha'; end if;
  insert into public.releases (version, notes, sha256, size, zip_b64, auto)
  values (p_version, left(coalesce(p_notes, ''), 500), lower(p_sha256), octet_length(raw), p_zip_b64, coalesce(p_auto, true))
  on conflict (version) do update set notes = excluded.notes, sha256 = excluded.sha256, size = excluded.size,
    zip_b64 = excluded.zip_b64, auto = excluded.auto, created_at = now();
  delete from public.releases where version not in (select version from public.releases order by created_at desc limit 3);
  return jsonb_build_object('version', p_version, 'size', octet_length(raw));
end $$;

create or replace function public.admin_forget_install(p_pw text, p_id uuid)
returns boolean language plpgsql security definer set search_path = public, extensions as $$
begin
  perform public._admin_check(p_pw);
  delete from public.installs where id = p_id;
  return true;
end $$;

-- GitHub Actions가 며칠마다 불러서 무료 프로젝트가 '쉬는 중'으로 멈추지 않게 함(DB를 한 번 읽음, 바꾸는 것 없음)
create or replace function public.keepalive() returns jsonb
language sql security definer set search_path = public, extensions as $$
  select jsonb_build_object('ok', true, 'at', now(), 'installs', (select count(*) from public.installs));
$$;

-- 함수 실행 권한: 내부 도우미는 막고, app_*/admin_*만 공개 키로 호출 가능
revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.app_heartbeat(uuid, text, text, text, jsonb, int, boolean, text, int) to anon, authenticated;
grant execute on function public.app_report(uuid, text, jsonb) to anon, authenticated;
grant execute on function public.app_issue(uuid, text, text, text, timestamptz, jsonb) to anon, authenticated;
grant execute on function public.app_get_release(uuid, text) to anon, authenticated;
grant execute on function public.keepalive() to anon, authenticated;
grant execute on function public.admin_issue(text, bigint) to anon, authenticated;
grant execute on function public.admin_publish_release(text, text, text, text, text, boolean) to anon, authenticated;
grant execute on function public.app_bookings(uuid, jsonb) to anon, authenticated;
grant execute on function public.app_shared_calendar(uuid) to anon, authenticated;
grant execute on function public.admin_init(text) to anon, authenticated;
grant execute on function public.admin_dashboard(text, int) to anon, authenticated;
grant execute on function public.admin_control(text, jsonb) to anon, authenticated;
grant execute on function public.admin_forget_install(text, uuid) to anon, authenticated;
