"""자동 다시 로그인(오래 꺼 둔 뒤): 숨은 로그인 창에서 로그인 버튼 → 가짜 Google 계정 선택 화면에서 같은 아이디만 누름.
비밀번호 화면·다른 계정만 보이는 화면이면 누르지 않고 창을 보여 주며 사용자에게 넘긴다. SONGDO_CHROME 있을 때만."""
import base64
import http.server
import json
import os
import stat
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def jwt():
    b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")
    return f"{b({'alg': 'none'})}.{b({'sub': 'u', 'exp': time.time() + 3600})}.sig"


HOME = """<header><button aria-label="로그인" onclick="location.href = LOGINPAGE + '?back=' + encodeURIComponent(location.href)">L</button></header>
<script>if (location.search.includes('code=')) localStorage.setItem('convex_auth_token', JSON.stringify(TOK));</script>"""
CHOOSER = """<ul>
<li><div role="link" data-identifier="other@gmail.com" onclick="go('other')">다른 계정</div></li>
<li><div role="link" data-identifier="me@gmail.com" onclick="go('me')">내 계정</div></li></ul>
<script>function go(w){ localStorage.setItem('picked', w); if (w !== 'me') return;
const b=new URLSearchParams(location.search).get('back'); setTimeout(()=>{location.href=b+(b.includes('?')?'&':'?')+'code=1'},300) }</script>"""
PASSWORD = """<input type="email" value="me@gmail.com"><input type="password"><button>다음</button>"""
PROFILE = """<input id="profile-name" value="박철환"><input id="profile-email" value="me@gmail.com">"""


@unittest.skipUnless(os.environ.get("SONGDO_CHROME"), "Chrome 경로 없음")
class AutoReloginTests(unittest.TestCase):
    PAGE = CHOOSER

    def setUp(self):
        tok = self.tok = jwt()
        page = self.PAGE

        class G(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
                self.wfile.write(page.encode())
        self.g = http.server.HTTPServer(("127.0.0.1", 0), G)
        threading.Thread(target=self.g.serve_forever, daemon=True).start()
        google = f"http://localhost:{self.g.server_port}/accounts.google.com/o"

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def do_GET(self):
                if self.path.startswith("/prime-reserve.com/login"):     # 실제처럼: 사이트 로그인 서버에서 '구글로 계속하기'를 눌러야 Google로
                    body = ("<button>네이버로 계속하기</button><button onclick=\"location.href=" + json.dumps(google).replace('"', "'")
                            + "+'?back='+new URLSearchParams(location.search).get('back')\">구글로 계속하기</button>")
                else:
                    body = PROFILE if self.path.startswith("/profile") else ("<script>const TOK=" + json.dumps(tok) + ";const LOGINPAGE='/prime-reserve.com/login'</script>" + HOME)
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.end_headers()
                self.wfile.write(body.encode())
        self.srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.tmp = tempfile.TemporaryDirectory()
        real = self.real = os.environ["SONGDO_CHROME"]
        if os.environ.get("SONGDO_CHROME_HEADLESS"):
            wrap = Path(self.tmp.name) / "chrome.sh"
            wrap.write_text(f'#!/bin/sh\nexec "{real}" --headless=new --no-sandbox "$@"\n')
            wrap.chmod(wrap.stat().st_mode | stat.S_IEXEC)
            os.environ["SONGDO_CHROME"] = str(wrap)
        os.environ["SONGDO_SITE_OVERRIDE"] = f"http://127.0.0.1:{self.srv.server_port}/songdotennis.co.kr"
        import importlib, core.browser
        importlib.reload(core.browser)
        self.b = core.browser
        self.b.LoginWatcher.GOOGLE_WAIT = 4

    def tearDown(self):
        os.environ["SONGDO_CHROME"] = self.real
        self.srv.shutdown(); self.g.shutdown(); self.tmp.cleanup()

    def run_watch(self, email="me@gmail.com", wait=30):
        prof = self.b.Profiles(Path(self.tmp.name))
        port = self.b.free_port()
        prof.open_login("A", debug_port=port)
        done, logs, need = [], [], []
        w = self.b.LoginWatcher(prof, "A", port, lambda t, p: done.append(t), lambda s, m: None, timeout=wait,
                                on_log=lambda m, level="info": logs.append(m), popup_ids=lambda: [], today="2026-10-20",
                                auto_email=email, on_need_user=need.append)
        w.start(); w.join(wait + 20)
        w.stop()
        for _ in range(40):
            if not prof.window_open("A"):
                break
            time.sleep(0.25)
        if prof.window_open("A"):
            prof.windows["A"].kill()
        return done, logs, need


class PickTests(AutoReloginTests):
    def test_picks_matching_account_only(self):
        done, logs, need = self.run_watch()
        self.assertEqual(done, [self.tok], logs)
        self.assertEqual(need, [], logs)
        self.assertTrue(any("Google 계정 선택 자동으로 누름" in m for m in logs), logs)
        self.assertTrue(any("구글로 계속하기" in m for m in logs), logs)
        self.assertTrue(any("자동 다시 로그인 시작 · 창 숨김" in m for m in logs), logs)

    def test_hands_over_when_account_missing(self):
        done, logs, need = self.run_watch(email="nobody@gmail.com", wait=12)
        self.assertEqual(done, [])
        self.assertEqual(need, ["고를 계정이 안 보임"], logs)


class PasswordTests(AutoReloginTests):
    PAGE = PASSWORD

    def test_never_touches_password(self):
        done, logs, need = self.run_watch(wait=10)
        self.assertEqual(done, [])
        self.assertEqual(need, ["Google이 비밀번호 확인을 요구함"], logs)


del AutoReloginTests

if __name__ == "__main__":
    unittest.main(verbosity=2)
