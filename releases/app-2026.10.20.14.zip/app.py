"""송도테니스 장바구니 도우미 (Songdo Tennis). 시작.bat으로 실행 → http://127.0.0.1:8780

범위: 감시 → 장바구니 담기 → 반영 확인, 그리고 사용자가 누른 장바구니 항목 취소.
예약 생성·확정·결제·취소 함수는 코드에 없다(core/rules.py 허용 목록).
"""
from __future__ import annotations

import base64
import csv
import hashlib
import hmac
import io
import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit
from urllib.request import urlopen

import re

from core.cloud import Cloud, CloudError, version_tuple
from core import updater
from core import ghupdate
import requests
from core.weather import Weather
from core import notices as notices_mod
from core import tournaments
from core.browser import BrowserError, Keeper, LoginWatcher, Profiles, free_port
from core.engine import DEFAULT_TIMING, DONE, LIMIT, REMOVED, TIMING_LIMITS, Engine
from core.journal import Journal
from core.rules import (BLOCK_NOTE, COURT_KIND, DEFAULT_RULES, KST, MAX_TARGETS, SLOT_STARTS, block_rules, court_blocked, hm,
                        open_event_for, parse_date, price, validate_targets)

BASE_BLOCKS = dict(DEFAULT_RULES["blocks"])     # 프로그램에 적어 둔 대회 막힘(공지를 못 읽을 때 대비)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
HOST, PORT = "127.0.0.1", 8780
URL = f"http://{HOST}:{PORT}"
APP_ID = "SongdoCart"
VERSION = "2026.10.20.14"          # 관리자 대시보드의 최소 버전 강제에 쓰임(배포할 때 올리기)
PALETTE = ["#D7F26B", "#9ED8F5", "#FFC9A8", "#C9B8F5", "#F5B8D2", "#B9F0D2", "#FFE08A", "#A8C8F0"]
ADMIN_UNLOCK_SECONDS = 30 * 60


def _pw_hash(pw: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, 200_000).hex()


class App:
    def __init__(self, data: Path = DATA, engine: Engine | None = None, start_threads: bool = True):
        self.data = data
        data.mkdir(exist_ok=True)
        self.csrf = secrets.token_urlsafe(24)
        self.lock = threading.RLock()
        self.settings_path = data / "settings.json"
        self.settings = {"accounts": [], "targets": [], "timing": {}}
        self.notice = ""
        if self.settings_path.exists():
            try:
                self.settings.update(json.loads(self.settings_path.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                self.notice = "settings.json을 읽지 못했습니다(파일은 보존)."
        self._migrate()
        self.journal = Journal(data / "logs")
        self.journal.event("session", detail=f"프로그램 시작 · 버전 {VERSION}")
        self.engine = engine or Engine(self.journal, timing=self.settings.get("timing") or {})
        if engine is None:
            from core.clock import measure
            from core.transport import BACKEND
            self.engine.measure_clock = lambda: measure(BACKEND + "/")
        self.profiles = Profiles(data)
        self.acct_status: dict[str, dict] = {}
        self.keepers: dict[str, Keeper] = {}
        self.login_busy: set[str] = set()      # 로그인 창이 열려 있는 계정(숨은 Chrome을 띄우지 않음)
        self._refresh_tried: dict[str, float] = {}
        self._ar: dict[str, dict] = {}         # 자동 갱신 시도 기록(토큰별)
        self._auto_login_at: dict[str, float] = {}   # 자동 다시 로그인 마지막 시도
        self._issue_seen: dict = {}
        self.root = ROOT                       # 업데이트할 프로그램 폴더(테스트에서 바꿈)
        self.update = {"available": "", "notes": "", "auto": True, "status": "", "error": ""}
        self._upd_failed: dict[str, float] = {}
        self._upd_busy = False
        self._upd_lock = threading.RLock()
        self._cloud_rel: dict | None = None    # 관리자 배포(Supabase)
        self._gh_rel: dict | None = None       # GitHub 배포
        self.last_poll = 0.0
        self.bye_at = 0.0                      # 화면(탭)을 닫았다는 신호를 받은 시각
        self.started_at = time.time()
        self.auto_exit = False                 # main()이 켬: 화면을 닫으면 프로그램도 끄기
        self.request_shutdown = None           # main()이 넣음: 서버 종료
        self.listen_socket = None              # main()이 넣음: 다시 시작할 때 새 프로그램에 넘겨줄 접속 소켓
        self.restart_hook = None               # 테스트용
        self.admin_until = 0.0
        self.admin_pw = ""                     # 대시보드 조회용. 메모리에만(파일·로그에 남기지 않음)
        self.test_at: datetime | None = None
        for a in self.settings["accounts"]:
            self.engine.ensure_account(a["name"])
            self.acct_status[a["name"]] = {"state": "idle", "msg": "로그인 확인 필요"}
        self.journal.log("시스템", f"시작 · 계정 {len(self.settings['accounts'])}개")
        self.cloud = Cloud(ROOT / "cloud.json" if data == DATA else data / "cloud.json", data, VERSION,
                           use_default=data == DATA)      # 실제 설치에서만 기본 연결(테스트는 끔)
        self.weather = Weather(data)
        self.notices: list = []
        self.notices_at = 0.0
        self.tours: dict = {}                  # 공지에서 읽은 대회 막힘 {날짜: [막힘]}
        self.tours_missed: list = []
        try:
            c = json.loads((data / "notices.json").read_text(encoding="utf-8"))
            self.notices, self.notices_at = list(c.get("items") or []), float(c.get("at") or 0)
            self._apply_tours(c.get("tours") or {})
        except (OSError, ValueError, AttributeError):
            pass
        self.engine.on_report = lambda rep, name: self.cloud.report(name[:-5], self._cloud_report(rep))
        self.journal.listeners.append(self._cloud_issue)
        if start_threads:
            if data == DATA:
                self.register_protocol(ROOT)
            self._install_hooks()
            self.weather.start()
            threading.Thread(target=self._notices_loop, daemon=True).start()
            self.cloud.start(self._cloud_status, self._cloud_control, self._cloud_bookings)
            threading.Thread(target=self._supervise, daemon=True).start()
            threading.Thread(target=self._startup_check, daemon=True).start()
            threading.Thread(target=self._clock_loop, daemon=True).start()
            threading.Thread(target=self._gh_loop, daemon=True).start()

    # ---------------------------------------------------------------- 저장
    def _migrate(self):
        accts = []
        for i, a in enumerate(self.settings.get("accounts") or []):
            if isinstance(a, str):
                a = {"name": a}
            if isinstance(a, dict) and a.get("name"):
                a.setdefault("color", PALETTE[i % len(PALETTE)])
                accts.append(a)
        self.settings["accounts"] = accts
        names = {a["name"] for a in accts}
        clean = []
        for t in self.settings.get("targets") or []:
            if isinstance(t, dict) and t.get("account") in names:
                t.pop("swap", None)
                clean.append(t)
        self.settings["targets"] = clean
        timing = self.settings.get("timing") or {}
        self.settings["timing"] = {k: v for k, v in timing.items() if k in TIMING_LIMITS}

    def save(self):
        with self.lock:
            tmp = self.data / "settings.pending.json"
            tmp.write_text(json.dumps(self.settings, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.settings_path)

    def names(self) -> list[str]:
        return [a["name"] for a in self.settings["accounts"]]

    def _need_account(self, name) -> str:
        if name not in self.names():
            raise ValueError("없는 계정입니다.")
        return name

    # ---------------------------------------------------------------- 계정
    def status(self, name, state, msg):
        prev = self.acct_status.get(name, {})
        if state == "error" and "로그인" in msg:
            email = self._auto_relogin_ok(name)
            if email:                                  # 오래 꺼 뒀다 켜서 풀린 경우 등 → 사용자를 부르기 전에 자동으로 한 번
                self._auto_login_at[name] = time.time()
                self.acct_status[name] = {"state": "login", "msg": "자동으로 다시 로그인하는 중"}
                threading.Thread(target=self._auto_relogin, args=(name, email), daemon=True).start()
                return
        if state == "ready":
            self._mark_login_seen(name)
        self.acct_status[name] = {"state": state, "msg": msg}
        if prev.get("state") != state or prev.get("msg") != msg:
            if state == "error":
                self.journal.log(name, f"로그인 확인 실패 · {msg}", "error", "계정")
                self.journal.notify(name, "로그인이 필요해요", "warn", key=f"login:{name}", window=6 * 3600)
            elif state == "ready" and prev.get("state") != "ready":
                self.journal.log(name, "로그인 확인 완료", "success", "계정")

    def add_account(self, name: str = "") -> str:
        with self.lock:
            name = (name or "").strip()
            if not name:
                n = 1
                while f"계정{n}" in self.names():
                    n += 1
                name = f"계정{n}"
            if not 1 <= len(name) <= 20 or any(ord(c) < 32 for c in name):
                raise ValueError("계정 이름은 1~20자로 입력하세요.")
            if name in self.names():
                raise ValueError("이미 있는 이름입니다.")
            used = {a["color"] for a in self.settings["accounts"]}
            color = next((c for c in PALETTE if c not in used), PALETTE[len(used) % len(PALETTE)])
            self.settings["accounts"].append({"name": name, "color": color})
            self.engine.ensure_account(name)
            self.status(name, "idle", "로그인 창을 열어 로그인하세요")
            self.save()
            return name

    def rename_account(self, name: str, new: str):
        new = (new or "").strip()
        with self.lock:
            self._need_account(name)
            if self.engine.running:
                raise ValueError("예약 중에는 이름을 바꿀 수 없어요.")
            if not 1 <= len(new) <= 20 or any(ord(c) < 32 for c in new):
                raise ValueError("계정 이름은 1~20자로 입력하세요.")
            if new in self.names():
                raise ValueError("이미 있는 이름입니다.")
            old_prof = self.profiles.path(name)
            if old_prof.exists():
                old_prof.rename(self.profiles.path(new))
            for a in self.settings["accounts"]:
                if a["name"] == name:
                    a["name"] = new
            for t in self.settings["targets"]:
                if t["account"] == name:
                    t["account"] = new
            self.engine.rename_account(name, new)
            self.acct_status[new] = self.acct_status.pop(name, {"state": "idle", "msg": ""})
            k = self.keepers.pop(name, None)
            if k:
                k.stop()
            self.save()

    def remove_account(self, name: str):
        with self.lock:
            self._need_account(name)
            if self.engine.running:
                raise ValueError("예약 중에는 계정을 삭제할 수 없어요.")
            self.settings["accounts"] = [a for a in self.settings["accounts"] if a["name"] != name]
            self.settings["targets"] = [t for t in self.settings["targets"] if t["account"] != name]
            self.engine.remove_account(name)
            self.acct_status.pop(name, None)
            k = self.keepers.pop(name, None)
            if k:
                k.stop()
                k.join(8)
            self.profiles.delete(name)
            self.save()
        self.journal.log("시스템", "계정 삭제", cat="계정")

    AUTO_LOGIN_GAP = 3600       # 같은 계정 자동 다시 로그인은 1시간에 1번

    def _auto_relogin_ok(self, name: str) -> str:
        """자동 다시 로그인을 해도 되는지 · 되면 그 계정의 Google 이메일(사이트 아이디)."""
        acct = next((a for a in self.settings["accounts"] if a["name"] == name), None)
        email = (acct or {}).get("login_id") or ""
        if "@" not in email or not self.profiles.path(name).is_dir():
            return ""                                  # 처음 로그인(아이디를 모름)은 사용자가
        if name in self.login_busy or self.profiles.window_open(name):
            return ""
        if time.time() - self._auto_login_at.get(name, 0) < self.AUTO_LOGIN_GAP:
            return ""
        return email

    def _auto_relogin(self, name: str, email: str):
        self._auto_login_at[name] = time.time()
        gone = self._login_age(name)
        self.journal.log(name, f"사이트 로그인이 풀려 있어 자동으로 다시 로그인해요{(' · ' + gone) if gone else ''}", "info", "계정")
        try:
            self.open_login(name, auto_email=email)
        except Exception as exc:
            self.journal.log(name, f"자동 다시 로그인 시작 못 함 · {str(exc)[:80]}", "warning", "계정")
            self.status(name, "error", "로그인이 필요해요 · '로그인 창 열기'로 로그인해 주세요")

    def _login_age(self, name: str) -> str:
        """로그인이 풀렸을 때 기록용: 마지막으로 로그인(갱신)이 확인된 뒤 얼마나 지났는지."""
        t = self._login_seen().get(name)
        if not t:
            return ""
        h = (time.time() - t) / 3600
        return f"마지막 로그인 확인 후 {h / 24:.1f}일" if h >= 48 else f"마지막 로그인 확인 후 {h:.0f}시간"

    def _login_seen(self) -> dict:
        try:
            v = json.loads((self.data / "login_seen.json").read_text(encoding="utf-8"))
            return v if isinstance(v, dict) else {}
        except (OSError, ValueError):
            return {}

    def _mark_login_seen(self, name: str):
        v = self._login_seen()
        v[name] = time.time()
        try:
            (self.data / "login_seen.json").write_text(json.dumps(v), encoding="utf-8")
        except OSError:
            pass

    def open_login(self, name: str, auto_email: str = ""):
        self._need_account(name)
        with self.lock:
            self.login_busy.add(name)
            k = self.keepers.pop(name, None)
        if k:
            k.stop()
            k.join(8)
        port = free_port()
        try:
            self.profiles.open_login(name, debug_port=port)
        except Exception:
            with self.lock:
                self.login_busy.discard(name)
            raise
        self.status(name, "login", "자동으로 다시 로그인하는 중" if auto_email else "열린 창에서 Google 계정을 골라 로그인해 주세요")
        LoginWatcher(self.profiles, name, port, lambda tok, prof: self._login_done(name, tok, prof),
                     lambda s, m: self.status(name, s, m),
                     on_log=lambda msg, level="info": self.journal.log(name, msg, level, "계정"),
                     popup_ids=self.popup_ids_cached, today=datetime.now(KST).strftime("%Y-%m-%d"),
                     auto_email=auto_email,
                     on_need_user=lambda why: self.journal.notify(name, f"로그인이 필요해요 · 자동 로그인이 안 됨({why})", "warn",
                                                                  key=f"login:{name}", window=3600),
                     on_end=lambda done: self._login_window_end(name, done)).start()

    def _login_window_end(self, name: str, done: bool):
        """로그인 창 도우미가 끝남. 로그인 없이 창이 닫혔으면 '로그인 중' 표시를 풀어 준다
        (안 풀면 숨은 Chrome 확인·자동 업데이트가 계속 기다림 · 10/20 17:56 실제로 생김)."""
        if done:
            return                                 # 완료는 _apply_profile이 정리
        with self.lock:
            self.login_busy.discard(name)
        if self.acct_status.get(name, {}).get("state") == "login":
            self.status(name, "idle", "로그인 창이 닫혔어요 · '로그인 창 열기'로 다시 로그인해 주세요")

    POPUP_CACHE_DAYS = 3

    def popup_ids_cached(self) -> list[str]:
        """사이트 팝업 공지 ID. 저장해 둔 게 있으면 바로 쓰고(뒤에서 새로 받아 둠), 없으면 한 번 받는다(최대 3초)."""
        path = self.data / "popup_ids.json"
        try:
            c = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            c = {}

        def fetch(timeout):
            ids = self.engine.popup_ids(timeout=timeout)
            if ids:
                try:
                    path.write_text(json.dumps({"ids": ids, "at": time.time()}), encoding="utf-8")
                except OSError:
                    pass
            return ids
        if c.get("ids") and time.time() - float(c.get("at") or 0) < self.POPUP_CACHE_DAYS * 86400:
            threading.Thread(target=fetch, args=(5,), daemon=True).start()
            return list(c["ids"])
        return fetch(3)

    def _login_done(self, name: str, tok: str, profile: dict):
        """로그인 창 도우미가 로그인을 확인함 → 연결·조회, 프로필 이름으로 계정 이름 정하기, 창은 도우미가 닫음."""
        try:
            self.engine.link_token(name, tok)
            self.engine.call(self.engine.refresh_account(self.engine.accounts[name]), timeout=15)
        except Exception as exc:
            self.status(name, "error", str(exc)[:120])
            return
        a = self.engine.accounts.get(name)
        self.status(name, "error" if a and a.auth_error else "ready", (a.auth_error if a else "") or "로그인 정상")
        threading.Thread(target=self._apply_profile, args=(name, profile or {}), daemon=True).start()

    def _apply_profile(self, name: str, profile: dict):
        for _ in range(40):                       # 창이 닫힌 뒤(프로필 폴더를 쓰지 않을 때) 이름을 바꾼다
            if not self.profiles.window_open(name):
                break
            time.sleep(0.25)
        with self.lock:
            self.login_busy.discard(name)
            acct = next((x for x in self.settings["accounts"] if x["name"] == name), None)
            if not acct:
                return
            if profile.get("email"):
                acct["login_id"] = profile["email"]
            if profile.get("name"):
                acct["display_name"] = profile["name"]
                eng = self.engine.accounts.get(name)
                if eng is not None and not eng.profile:
                    eng.profile = {"name": profile["name"], "email": profile.get("email", "")}
            want = profile.get("name", "").strip()
            auto_named = bool(re.fullmatch(r"계정\d+", name))
            if want and auto_named and not self.engine.running:
                new, n = want, 2
                while new in self.names() and new != name:
                    new, n = f"{want}{n}", n + 1
                if new != name:
                    try:
                        self.rename_account(name, new)
                        self.journal.log(new, "계정 이름을 사이트 프로필 이름으로 정함", "success", "계정")
                        return
                    except (ValueError, OSError):
                        pass
            self.save()

    def check_login(self, name: str, quiet: bool = False):
        self._need_account(name)
        if self.profiles.window_open(name):
            raise ValueError("로그인 창을 먼저 닫아 주세요.")
        with self.lock:
            self.login_busy.discard(name)
            k = self.keepers.get(name)
            if k and k.is_alive():                 # 이미 숨은 Chrome이 돌고 있으면 그 결과를 쓴다
                self.engine.refresh_now(name)
                return
        if not self.profiles.path(name).is_dir():
            self.status(name, "idle", "로그인 창을 열어 로그인하세요")
            if not quiet:
                raise ValueError("먼저 '로그인 창 열기'로 로그인해 주세요.")
            return
        self.status(name, "checking", "로그인 확인 중")

        def got(tok):
            try:
                self.engine.link_token(name, tok)
                self.engine.call(self.engine.refresh_account(self.engine.accounts[name]), timeout=15)
                a = self.engine.accounts[name]
                self.status(name, "error" if a.auth_error else "ready", a.auth_error or "로그인 정상")
            except Exception as exc:
                self.status(name, "error", str(exc)[:120])

        k = Keeper(self.profiles, name, got, lambda s, m: self.status(name, s, m), once=True, wait_seconds=30)
        with self.lock:
            self.keepers[name] = k
        k.start()

    def refresh(self, name: str):
        """화면을 열 때 장바구니·예약을 새로 읽는다. 토큰이 아직 살아 있으면 그대로 쓰고(갱신은 _auto_refresh 담당),
        이미 끝났을 때만 숨은 Chrome으로 한 번 확인."""
        self._need_account(name)
        if self.engine.token_fresh(name, margin=5):
            self.engine.refresh_now(name)
            return
        k = self.keepers.get(name)
        if name not in self.login_busy and not (k and k.is_alive()):
            self.check_login(name, quiet=True)

    def _install_hooks(self):
        """잡히지 않은 오류도 기록·전송(스레드·메인)."""
        def th(args):
            if args.exc_type is not SystemExit:
                self.journal.exception(f"스레드 {args.thread.name if args.thread else ''}", args.exc_value)
        threading.excepthook = th
        prev = sys.excepthook

        def sh(t, v, tb):
            if t is not KeyboardInterrupt:
                self.journal.exception("메인", v)
            prev(t, v, tb)
        sys.excepthook = sh

    NOTICES_EVERY = 1800

    def refresh_notices(self) -> bool:
        """사이트 공지를 새로 받아 홈 '사이트 공지'에 반영(팝업 공지 ID도 함께 갱신)."""
        raw = self.engine.announcements()
        if raw is None:
            return False
        items = notices_mod.normalize(raw)
        try:
            tours, missed = tournaments.parse(raw)
        except Exception as exc:                   # 공지 글이 낯설어도 공지 목록은 계속 보여 준다
            self.journal.exception("대회 일정 해석", exc)
            tours, missed = self.tours, []
        if tours != self.tours:
            days = ", ".join(f"{k[5:7].lstrip('0')}/{k[8:].lstrip('0')}" for k in sorted(tours)) or "없음"
            self.journal.log("시스템", f"사이트 공지의 대회 일정을 반영했어요 · {days}", "info", "공지", notify=bool(tours))
        if missed and missed != self.tours_missed:
            self.journal.log("시스템", f"대회 일정 공지를 읽지 못했어요({', '.join(missed)}) · 공지를 직접 확인해 주세요", "warning", "공지",
                             notify=True)
        self.tours_missed = missed
        self._apply_tours(tours)
        if not self.notices_at:
            self.journal.event("notices", detail=f"공지 {len(raw)}개 · 항목 {notices_mod.field_names(raw)}")
        if raw and not items:
            self.journal.log("시스템", "사이트 공지 형식을 읽지 못했어요(항목 이름이 바뀐 듯)", "warning", "통신")
            return False
        self.notices, self.notices_at = items, time.time()
        try:
            (self.data / "notices.json").write_text(json.dumps({"at": self.notices_at, "items": items, "tours": self.tours},
                                                               ensure_ascii=False), encoding="utf-8")
            ids = [n["id"] for n in items if n.get("popup") and n.get("id")]
            if ids:
                (self.data / "popup_ids.json").write_text(json.dumps({"ids": ids, "at": time.time()}), encoding="utf-8")
        except OSError:
            pass
        return True

    def _apply_tours(self, tours: dict):
        """고정 대회 막힘(BASE_BLOCKS) 위에 공지에서 읽은 날짜를 덮어써서 예약 규칙에 반영."""
        self.tours = {k: v for k, v in (tours or {}).items() if isinstance(v, list)}
        merged = dict(BASE_BLOCKS)
        merged.update(self.tours)
        DEFAULT_RULES["blocks"] = merged

    def _notices_loop(self):
        time.sleep(3)
        while True:
            ok = False
            try:
                ok = self.refresh_notices()
            except Exception:
                pass
            time.sleep(self.NOTICES_EVERY if ok else 300)

    def _clock_loop(self):
        """켤 때 한 번, 그 뒤 1시간마다(예약 중이 아닐 때) 사이트 시계와 비교. 오픈 준비 때는 엔진이 다시 잰다."""
        time.sleep(5)
        while True:
            if not self.engine.running:
                try:
                    self.engine.call(self.engine.check_clock("주기 확인"), timeout=30)
                except Exception:
                    pass
            time.sleep(3600)

    def extended(self) -> dict:
        """'시간 연장'을 이미 한 칸(slotId → 시각). 같은 칸은 한 번만."""
        try:
            v = json.loads((self.data / "extended.json").read_text(encoding="utf-8"))
            return v if isinstance(v, dict) else {}
        except (OSError, ValueError):
            return {}

    def extend_cart(self, name: str, sid: str) -> dict:
        ext = self.extended()
        if sid in ext:
            raise ValueError("이 칸은 이미 한 번 연장했어요. 같은 칸은 한 번만 연장할 수 있어요.")
        fut = self.engine.extend_by_user(name, sid)
        ext[sid] = datetime.now(KST).isoformat(timespec="seconds")     # 시도하면(성공·실패 모두) 1번 쓴 것으로
        try:
            cut = (datetime.now(KST) - timedelta(days=90)).isoformat()
            ext = {k: v for k, v in ext.items() if v >= cut}
            (self.data / "extended.json").write_text(json.dumps(ext), encoding="utf-8")
        except OSError:
            pass
        result, msg = fut.result(30)
        return {"result": result, "message": msg}

    def quit(self, force: bool = False):
        """화면의 '프로그램 끄기' 버튼: 기다리지 않고 바로 끈다. 예약 실행 중이면 force일 때만."""
        if self.engine.running and not force:
            raise ValueError("예약 실행 중이에요. 끄면 예약이 멈춰요.")
        self.journal.log("시스템", "프로그램 종료 · 끄기 버튼" + (" · 예약 중지" if self.engine.running else ""), cat="엔진")
        if self.engine.running:
            self.engine.stop()
        self.auto_exit = False
        if self.request_shutdown:
            threading.Timer(0.4, self.request_shutdown).start()      # 응답을 먼저 보내고 끈다

    @staticmethod
    def register_protocol(root: Path) -> bool:
        """Windows: songdotennis:// 주소를 이 프로그램 실행으로 연결(현재 사용자만, 관리자 권한 불필요).
        화면의 '연결 끊김'을 누르면 브라우저가 이 주소로 프로그램을 다시 켠다."""
        if sys.platform != "win32":
            return False
        pyw = root / ".venv" / "Scripts" / "pythonw.exe"
        if not pyw.exists():
            return False
        try:
            import winreg
            base = r"Software\Classes\songdotennis"
            cmd = f'"{pyw}" "{root / "app.py"}" --no-open --from-link'
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base) as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:Songdo Tennis")
                winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\DefaultIcon") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, str(root / "songdo.ico"))
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, base + r"\shell\open\command") as k:
                winreg.SetValueEx(k, "", 0, winreg.REG_SZ, cmd)
            return True
        except OSError:
            return False

    def _startup_check(self):
        for name in list(self.names()):
            try:
                if self.profiles.path(name).is_dir():
                    self.check_login(name, quiet=True)
                    k = self.keepers.get(name)
                    if k:
                        k.join(40)
            except Exception:
                pass

    # ---------------------------------------------------------------- 숨은 Chrome 관리
    def _need_keeper(self) -> set[str]:
        need = set()
        if not self.engine.running:
            return need
        now = self.engine.now()
        prep = timedelta(minutes=self.engine.timing["prepare_minutes"] + 2)
        for e in list(self.engine.events.values()):
            if e.phase == "종료":
                continue
            if e.at - prep <= now:
                for tid in e.target_ids:
                    st = self.engine.states.get(tid)
                    if st:
                        need.add(st.target.account)
        return need

    def _supervise(self):
        while True:
            time.sleep(1.0)
            try:
                self._prune_done()
                self._sync_profiles()
                self._auto_refresh()
                self._idle_exit_check()
                with self.lock:
                    busy = set(self.login_busy)
                need = self._need_keeper() - busy
                for name in need:
                    k = self.keepers.get(name)
                    if k and k.is_alive():
                        continue
                    if k and not k.once and time.time() - getattr(k, "_died", time.time()) < 60:
                        continue                         # 실패한 숨은 Chrome은 60초 뒤 다시 시도

                    def on_tok(tok, name=name):
                        self.engine.link_token(name, tok)
                        self.status(name, "ready", "숨은 Chrome으로 로그인 유지 중")
                    nk = Keeper(self.profiles, name, on_tok, lambda s, m, name=name: self.status(name, s, m), interval=30)
                    self.keepers[name] = nk
                    nk.start()
                for name, k in list(self.keepers.items()):
                    if not k.once and name not in need:
                        self.keepers.pop(name).stop()
                    elif not k.once and not k.is_alive() and not hasattr(k, "_died"):
                        k._died = time.time()           # 실패하면 60초 뒤 다시 시도
            except Exception:
                pass

    BYE_GRACE = 15             # 탭을 닫은 뒤 이만큼 새 화면이 없으면 끔(새로고침은 바로 다시 연결됨)
    IDLE_EXIT = 180            # 닫았다는 신호가 없어도 화면이 이만큼 없으면 끔(브라우저 뒤 탭은 1분에 한 번만 깨어남)

    def _idle_exit_check(self) -> str:
        """화면을 닫으면 프로그램도 끈다. 예약 중·로그인 창·업데이트 중에는 끄지 않는다."""
        if not self.auto_exit or not self.request_shutdown:
            return ""
        if self.engine.running or self.login_busy or self._upd_busy:
            return ""
        now = time.time()
        last = max(self.last_poll, self.started_at)
        if self.bye_at and self.bye_at >= self.last_poll and now - self.bye_at > self.BYE_GRACE:
            why = "화면을 닫아서"
        elif now - last > self.IDLE_EXIT:
            why = "화면이 3분 넘게 열려 있지 않아서"
        else:
            return ""
        self.auto_exit = False
        self.journal.log("시스템", f"프로그램 종료 · {why}", cat="엔진")
        self.request_shutdown()
        return why

    REFRESH_BEFORE = 60        # 토큰 만료 이 초 전에 갱신 시작

    REFRESH_TRIES = 3           # 한 토큰에 대해 자동 갱신 최대 시도
    REFRESH_GAP = 120           # 실패하면 2분 뒤 다시(토큰이 끝난 뒤 사이트를 열면 저장된 갱신 정보로 바로 새 토큰을 줌)

    def _auto_refresh(self):
        """예약 중이 아니어도 로그인 유지: 토큰(1시간)이 끝나기 1분 전쯤 숨은 Chrome을 잠깐 열면
        사이트가 저장된 갱신 정보로 새 토큰을 받는다. 그 토큰만 읽고 바로 닫는다(약 10~60초, 계정당 1시간에 1번).
        실패하면 2분 간격으로 3번까지 다시 해 보고, 그래도 안 되면 '로그인이 필요해요'."""
        now = time.time()
        for name in list(self.names()):
            if name in self.login_busy or self.acct_status.get(name, {}).get("state") in ("login", "checking"):
                continue
            k = self.keepers.get(name)
            if k and k.is_alive():
                continue
            acct = self.engine.accounts.get(name)
            if not acct or not acct.token or not acct.exp or not self.profiles.path(name).is_dir():
                continue
            if acct.exp - now > self.REFRESH_BEFORE:
                continue
            st = self._ar.get(name)
            if not st or st["exp"] != acct.exp:
                st = self._ar[name] = {"exp": acct.exp, "n": 0, "at": 0.0}
            if st["n"] >= self.REFRESH_TRIES or (st["n"] and now - st["at"] < self.REFRESH_GAP):
                continue
            if self.acct_status.get(name, {}).get("state") == "error" and not st["n"]:
                continue                       # 다른 이유로 이미 '로그인 필요'인 계정은 건드리지 않음
            st["n"] += 1
            st["at"] = now
            tries = st["n"]

            def got(tok, name=name):
                try:
                    self.engine.link_token(name, tok)
                    self.status(name, "ready", "로그인 정상 · 자동 갱신")
                    self.journal.log(name, "로그인 자동 갱신", cat="계정")
                except Exception as exc:
                    self.status(name, "error", str(exc)[:120])

            def on_status(state, msg, name=name, tries=tries):
                if state == "error" and tries < self.REFRESH_TRIES:
                    self.journal.log(name, f"로그인 자동 갱신 실패({tries}/{self.REFRESH_TRIES}) · 2분 뒤 다시 시도", "warning", "계정")
                    return
                self.status(name, state, msg)

            nk = Keeper(self.profiles, name, got, on_status, once=True, wait_seconds=100)
            with self.lock:
                self.keepers[name] = nk
            nk.start()

    def _sync_profiles(self):
        """사이트 프로필(이름·이메일)을 계정 설정에 반영. '계정N'처럼 자동으로 붙은 이름이면 프로필 이름으로 바꾼다."""
        for a in list(self.settings["accounts"]):
            acct = self.engine.accounts.get(a["name"])
            prof = dict(acct.profile) if acct else {}
            if not prof.get("name"):
                continue
            if a.get("display_name") != prof["name"] or (prof.get("email") and a.get("login_id") != prof["email"]):
                with self.lock:
                    a["display_name"] = prof["name"]
                    if prof.get("email"):
                        a["login_id"] = prof["email"]
                    self.save()
            k = self.keepers.get(a["name"])
            if re.fullmatch(r"계정\d+", a["name"]) and not self.engine.running and not self.profiles.window_open(a["name"]) \
                    and not (k and k.is_alive()):
                want, n = prof["name"], 2
                new = want
                while new in self.names():
                    new, n = f"{want}{n}", n + 1
                try:
                    self.rename_account(a["name"], new)
                except (ValueError, OSError):
                    pass

    def _prune_done(self):
        """장바구니에 담긴 목표는 목록에서 뺀다(사용자가 취소한 목표도)."""
        with self.lock:
            done = {tid for tid, st in self.engine.states.items() if st.status in (DONE, REMOVED)}
            if not done:
                return
            before = len(self.settings["targets"])
            self.settings["targets"] = [t for t in self.settings["targets"] if t["id"] not in done]
            if len(self.settings["targets"]) != before:
                self.save()

    # ---------------------------------------------------------------- 목표
    def _editable(self):
        if self.engine.running:
            raise ValueError("예약 중에는 목표를 바꿀 수 없어요. 중지 후 바꿔 주세요.")

    def add_targets(self, p: dict) -> int:
        with self.lock:
            self._editable()
            name = self._need_account(p.get("account"))
            d = parse_date(p.get("date", ""))
            courts = sorted({int(c) for c in p.get("courts", [])})
            starts = sorted({int(s) for s in p.get("starts", [])})
            if not 1 <= len(courts) <= 2 or not 1 <= len(starts) <= 2:
                raise ValueError("코트와 시간은 1~2개씩 골라 주세요.")
            have = self.settings["targets"]
            taken = {(t["date"], t["court"], t["start"]): t["account"] for t in have}
            new = []
            for c in courts:
                for s in starts:
                    if court_blocked(d, c, s) or (d.isoformat(), c, s) in taken:
                        continue
                    new.append({"account": name, "date": d.isoformat(), "court": c, "start": s, "priority": 0,
                                "id": secrets.token_hex(5)})
            if not new:
                raise ValueError("고른 칸이 모두 막혀 있거나 이미 목표에 있어요.")
            mine = [t for t in have if t["account"] == name]
            if len(mine) + len(new) > MAX_TARGETS:
                raise ValueError(f"예약 목표는 계정당 최대 {MAX_TARGETS}개예요.")
            # 같은 이용일 3건 한도: 이 날짜의 기존 예약·장바구니 + 목표가 3을 넘지 않게(한 계정 안 병렬 담기 전제)
            held = self.date_held(name, d.isoformat())
            same = sum(1 for t in mine if t["date"] == d.isoformat())
            limit = DEFAULT_RULES["per_date_limit"]
            if held + same + len(new) > limit:
                left = max(0, limit - held - same)
                raise ValueError(f"{d.month}/{d.day}은 같은 날 최대 {limit}건이에요"
                                 + (f"(이미 예약·장바구니 {held}건)" if held else "") + f" · 지금 {left}개만 더 넣을 수 있어요.")
            merged = have + new
            self._renumber(merged)
            validate_targets(merged, set(self.names()))
            self.settings["targets"] = merged
            self.save()
        for t in new:
            self.journal.log(name, f"목표 추가 · {t['date'][5:]} {hm(t['start'])} {t['court']}번", cat="목표")
        return len(new)

    def date_held(self, name: str, date: str) -> int:
        """이 계정이 그 이용일에 이미 가진 예약(취소 제외)·장바구니 수."""
        acct = self.engine.accounts.get(name)
        if not acct:
            return 0
        snap = self.engine.snapshot()["accounts"].get(name, {})
        res = sum(1 for r in snap.get("reservations", []) if r.get("date") == date and not r.get("cancelled"))
        cart = sum(1 for c in snap.get("cart", []) if c.get("date") == date)
        return res + cart

    @staticmethod
    def _renumber(targets: list):
        seen: dict[str, int] = {}
        for t in targets:
            seen[t["account"]] = seen.get(t["account"], -1) + 1
            t["priority"] = seen[t["account"]]

    def remove_target(self, tid: str):
        with self.lock:
            self._editable()
            t = next((x for x in self.settings["targets"] if x["id"] == tid), None)
            if not t:
                raise ValueError("없는 목표입니다.")
            self.settings["targets"].remove(t)
            self._renumber(self.settings["targets"])
            self.save()
        self.journal.log(t["account"], f"목표 빼기 · {t['date'][5:]} {hm(t['start'])} {t['court']}번", cat="목표")

    def reorder_targets(self, name: str, ids: list):
        with self.lock:
            self._editable()
            self._need_account(name)
            mine = [t for t in self.settings["targets"] if t["account"] == name]
            by = {t["id"]: t for t in mine}
            if sorted(ids) != sorted(by):
                raise ValueError("목록이 바뀌었어요. 새로고침해 주세요.")
            rest = [t for t in self.settings["targets"] if t["account"] != name]
            self.settings["targets"] = rest + [by[i] for i in ids]
            self._renumber(self.settings["targets"])
            self.save()

    # ---------------------------------------------------------------- 실행
    def start(self):
        block = self.cloud.block_reason()
        if block:
            raise ValueError(block)
        with self.lock:
            targets = validate_targets(self.settings["targets"], set(self.names()))
            if not targets:
                raise ValueError("예약 목표를 먼저 넣어 주세요.")
            if self.test_at and self.test_at < self.engine.now() + timedelta(seconds=2):
                raise ValueError("테스트 가상 오픈 시각이 지났어요. 다시 정해 주세요.")
            self.engine.arm(targets, timing=self.settings["timing"], test_at=self.test_at)

    def set_timing(self, p: dict):
        with self.lock:
            if self.engine.running:
                raise ValueError("예약 중에는 바꿀 수 없어요.")
            if p.get("reset"):
                self.settings["timing"] = {}
                for k in TIMING_LIMITS:
                    self.engine.timing[k] = DEFAULT_TIMING[k]
            else:
                clean = {}
                for k, (lo, hi) in TIMING_LIMITS.items():
                    if k in p:
                        clean[k] = max(lo, min(hi, int(float(p[k]))))
                self.settings["timing"] = {**self.settings["timing"], **clean}
                self.engine.set_timing(clean)
            self.save()

    # ---------------------------------------------------------------- 관리자·테스트 모드
    @property
    def admin_path(self) -> Path:
        return self.data / "admin.json"

    def admin_exists(self) -> bool:
        return self.admin_path.exists()

    def admin_ok(self) -> bool:
        if time.time() >= self.admin_until:
            self.admin_pw = ""
            return False
        return True

    def admin_login(self, pw: str):
        pw = str(pw or "")
        if not self.admin_exists():
            if len(pw) < 4:
                raise ValueError("관리자 비밀번호는 4자 이상으로 정해 주세요.")
            salt = secrets.token_bytes(16)
            self.admin_path.write_text(json.dumps({"salt": salt.hex(), "hash": _pw_hash(pw, salt)}), encoding="utf-8")
            self.journal.log("시스템", "관리자 비밀번호 설정", cat="관리자")
        else:
            rec = json.loads(self.admin_path.read_text(encoding="utf-8"))
            if not hmac.compare_digest(_pw_hash(pw, bytes.fromhex(rec["salt"])), rec["hash"]):
                time.sleep(0.6)
                raise ValueError("비밀번호가 맞지 않아요")
        self.admin_until = time.time() + ADMIN_UNLOCK_SECONDS
        self.admin_pw = pw

    def admin_lock(self):
        self.admin_until = 0.0
        self.admin_pw = ""

    def set_test(self, p: dict):
        if not self.admin_ok():
            raise ValueError("관리자 확인이 필요해요.")
        if self.engine.running:
            raise ValueError("예약 중에는 바꿀 수 없어요. 중지 후 바꿔 주세요.")
        if p.get("off"):
            self.test_at = None
            self.journal.log("시스템", "테스트 모드 끔", cat="관리자")
            return
        at = datetime.fromisoformat(str(p.get("at")))
        if at.tzinfo is None:
            at = at.replace(tzinfo=KST)
        if at < self.engine.now() + timedelta(seconds=10):
            raise ValueError("가상 오픈 시각은 지금보다 10초 이상 뒤로 정해 주세요.")
        self.test_at = at.astimezone(KST)
        self.journal.log("시스템", f"테스트 모드 · 가상 오픈 {self.test_at:%m/%d %H:%M:%S}", "warning", "관리자")

    # ---------------------------------------------------------------- 관리자 대시보드(Supabase)
    def login_id(self, name: str) -> str:
        a = next((x for x in self.settings["accounts"] if x["name"] == name), None)
        return (a or {}).get("login_id") or ""

    def _cloud_status(self) -> dict:
        ids = [self.login_id(a["name"]) or "(로그인 전)" for a in self.settings["accounts"]]
        running = self.engine.running
        clk = self.engine.clock
        return {"accounts": ids, "targets": len(self.settings["targets"]), "running": running,
                "clock_ms": round(clk["offset"] * 1000) if clk else None,
                "state": ("테스트 중" if self.engine.test_mode else "예약 중") if running else "대기"}

    def _cloud_bookings(self) -> list:
        """모임 일정용: 계정별 예약(취소 제외)·장바구니를 사이트 아이디로. 이번 달~다음 달 범위는 서버가 자른다."""
        snap = self.engine.snapshot()["accounts"]
        out = []
        for a in self.settings["accounts"]:
            info = snap.get(a["name"]) or {}
            who = a.get("login_id") or a["name"]
            synced = info.get("synced_at")
            at = datetime.fromtimestamp(synced, KST).isoformat(timespec="seconds") if synced else None
            for r in info.get("reservations", []):
                if r.get("cancelled") or not r.get("date"):
                    continue
                out.append({"account": who, "kind": "res", "date": r["date"], "start_min": r.get("start"), "end_min": r.get("end"),
                            "court": r.get("court"), "status": str(r.get("status") or "")[:30], "synced_at": at})
            for c in info.get("cart", []):
                if not c.get("date"):
                    continue
                st = c.get("start")
                out.append({"account": who, "kind": "cart", "date": c["date"], "start_min": st,
                            "end_min": st + 120 if isinstance(st, int) else None, "court": c.get("court"), "status": "", "synced_at": at})
        out.sort(key=lambda x: (x["date"], x["start_min"] or 0, x["court"] or 0, x["kind"]))
        return out

    def _cloud_report(self, rep: dict) -> dict:
        """실행 요약을 올릴 형태로: 계정 이름 대신 사이트 아이디, 거절 사유는 짧게."""
        out = dict(rep)
        out["targets"] = [{**t, "account": self.login_id(t.get("account", "")) or t.get("account", ""),
                           "reject_reasons": [str(x)[:80] for x in (t.get("reject_reasons") or [])[:5]]}
                          for t in rep.get("targets", [])]
        out.pop("log_file", None)
        return out

    ISSUE_CONTEXT = 40          # 오류와 함께 보낼 직전 기록 줄 수
    ISSUE_REPEAT = 600          # 같은 문제는 10분에 한 번만

    def _cloud_issue(self, who: str, msg: str, level: str):
        """주의·오류가 생기면 대시보드로 자동 전송. 오류(err)는 직전 자세한 기록 40줄을 함께 보낸다."""
        if level not in ("warn", "err"):
            return
        now = time.time()
        sig = (level, who, re.sub(r"\d+", "N", msg))
        if now - self._issue_seen.get(sig, 0) < self.ISSUE_REPEAT:
            return
        self._issue_seen[sig] = now
        ids = {n: self.login_id(n) for n in self.names()}
        ctx = None
        if level == "err" or "429" in msg or "실패" in msg:
            ctx = [{"ts": r["ts"], "lvl": r["lvl"], "acct": ids.get(r["acct"]) or r["acct"], "cat": r["cat"], "msg": str(r["msg"])[:300]}
                   for r in self.journal.detail_rows()[-self.ISSUE_CONTEXT:]]
        self.cloud.issue(level, ids.get(who, "") if who in ids else "", msg, ctx)

    def client_error(self, p: dict):
        """화면(브라우저) 오류. 위치와 메시지 앞부분만."""
        msg = re.sub(r"\s+", " ", str(p.get("msg", "")))[:160]
        src = str(p.get("src", "")).rsplit("/", 1)[-1][:40]
        self.journal.log("시스템", f"화면 오류 · {msg} ({src}:{int(p.get('line') or 0)})", "error", "화면")

    def _backfill_reports(self):
        """대시보드에 아직 안 올라간 실행 요약(최근 60일)을 올린다. 연결이 꺼져 있던 때 실행한 것까지."""
        if getattr(self, "_backfilled", False):
            return
        self._backfilled = True
        sent_path = self.data / "cloud_reports_sent.json"
        try:
            sent = set(json.loads(sent_path.read_text(encoding="utf-8")))
        except (OSError, ValueError, TypeError):
            sent = set()
        cutoff = (datetime.now(KST) - timedelta(days=60)).strftime("%Y%m%d")
        new = []
        for f in sorted((self.data / "reports").glob("*.json")):
            if f.name in sent or f.stem[:8] < cutoff:
                continue
            try:
                rep = json.loads(f.read_text(encoding="utf-8"))
                self.cloud.report(f.stem, self._cloud_report(rep))   # 같은 이름은 서버가 한 번만 받음
                new.append(f.name)
            except (OSError, ValueError, TypeError):
                continue
        if new:
            sent.update(new)
            try:
                sent_path.write_text(json.dumps(sorted(sent)), encoding="utf-8")
            except OSError:
                pass
            self.journal.log("시스템", f"대시보드에 실행 요약 {len(new)}건을 올려요", "info", "대시보드")

    def _cloud_control(self, ctrl: dict):
        self._backfill_reports()
        block = self.cloud.block_reason()
        if block and self.engine.running:
            self.engine.stop()
            self.journal.log("시스템", f"관리자 제어로 예약 중지 · {block}", "warning", "관리자", notify=True, key="cloud-block")
        elif block:
            self.journal.notify("관리자", block, "warn", key="cloud-block", window=6 * 3600)
        note = self.cloud.take_notice()
        if note:
            self.journal.notify("관리자 공지", note, "info")
        self._check_update(ctrl or {})

    # ---------------------------------------------------------------- 자동 업데이트
    UPDATE_RETRY = 3600

    def _check_update(self, ctrl: dict):
        latest = str(ctrl.get("latest_version") or "")
        self._cloud_rel = {"version": latest, "sha256": str(ctrl.get("release_sha") or ""), "source": "cloud",
                           "notes": str(ctrl.get("release_notes") or "")[:300], "auto": bool(ctrl.get("release_auto"))} if latest else None
        self._decide_update()

    def _gh_loop(self):
        """GitHub 저장소의 releases/latest.json을 켤 때(10초 뒤)와 30분마다 확인."""
        time.sleep(10)
        while True:
            self.check_github()
            time.sleep(ghupdate.EVERY)

    def check_github(self) -> bool:
        try:
            m = ghupdate.manifest()
        except (ghupdate.GhError, requests.RequestException, ValueError) as exc:
            self.update["gh_error"] = str(exc)[:80]
            return False
        self.update["gh_error"] = ""
        self.update["gh_checked"] = time.time()
        self._gh_rel = dict(m, source="github")
        self._decide_update()
        return True

    def _decide_update(self):
        """관리자 배포·GitHub 배포 중 지금보다 새것 가운데 가장 새 버전을 고른다."""
        with self._upd_lock:
            cands = [c for c in (self._cloud_rel, self._gh_rel) if c and version_tuple(c["version"]) > version_tuple(VERSION)]
            if not cands:
                self.update.update(available="", status="", source="", sha="")
                return
            best = max(cands, key=lambda c: (version_tuple(c["version"]), c["source"] == "github"))
            latest = best["version"]
            self.update.update(available=latest, notes=best["notes"], auto=best["auto"], source=best["source"], sha=best["sha256"])
            if not best["auto"]:
                self.journal.notify("관리자", f"새 버전 {latest}이 있어요 · 설정 > 예약 동작에서 업데이트할 수 있어요", "info",
                                    key=f"update:{latest}", window=7 * 86400)
                return
            if self.engine.running or self.login_busy:
                if self.update["status"] != "wait":
                    self.update["status"] = "wait"
                    self.journal.log("시스템", f"새 버전 {latest} · 예약이 끝나면 자동으로 업데이트해요", "info", "업데이트", notify=True,
                                     key=f"update-wait:{latest}")
                return
        self.apply_update(latest, best["sha256"])

    def apply_update(self, version: str, sha: str, manual: bool = False) -> bool:
        if self._upd_busy:
            return False
        if not manual and time.time() - self._upd_failed.get(version, 0) < self.UPDATE_RETRY:
            return False
        if self.engine.running:
            raise ValueError("예약 중에는 업데이트할 수 없어요. 중지한 뒤 해 주세요.")
        self._upd_busy = True
        self.update["status"] = "busy"
        try:
            gh = self._gh_rel
            if gh and gh["version"] == version and (not sha or sha == gh["sha256"]):
                raw, sha = ghupdate.download(gh), gh["sha256"]
            else:
                rel = self.cloud.rpc("app_get_release", {"p_id": self.cloud.install_id, "p_version": version}, 60)
                if not isinstance(rel, dict) or not rel.get("zip_b64"):
                    raise updater.UpdateError("배포된 파일을 찾지 못했어요")
                raw = updater.from_b64(rel["zip_b64"])
                sha = sha or rel.get("sha256", "")
            res = updater.apply(self.root, raw, sha, version, self.data / "backup", VERSION)
        except (updater.UpdateError, CloudError, ValueError, requests.RequestException) as exc:
            self._upd_failed[version] = time.time()
            self.update.update(status="fail", error=str(exc)[:120])
            self.journal.log("시스템", f"업데이트 실패({version}) · {str(exc)[:120]}", "error", "업데이트")
            return False
        finally:
            self._upd_busy = False
        self.update["status"] = "done"
        self.journal.log("시스템", f"새 버전 {version}으로 업데이트했어요 · 파일 {res['files']}개 · 백업 {res['backup']} · 다시 시작해요",
                         "success", "업데이트", notify=True)
        self.restart()
        return True

    def restart(self):
        """새 버전으로 다시 시작: 새 창에서 프로그램을 띄우고 이 서버는 닫는다."""
        if self.restart_hook:
            return self.restart_hook()
        args = [sys.executable, str(self.root / "app.py"), "--after-update"]
        if time.time() - self.last_poll > 30:
            args.append("--open")                   # 열린 화면이 없으면 새로 연다
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)      # 검은 창 없이(설치판과 같게)
        sock = self.listen_socket
        # 포트를 다시 잡지 않도록 지금 열려 있는 접속 소켓을 새 프로그램에 넘긴다(실패하면 새 프로그램이 직접 잡음)
        try:
            if sock is not None and hasattr(sock, "share"):          # Windows
                child = subprocess.Popen(args + ["--sock-stdin"], cwd=str(self.root), creationflags=flags, stdin=subprocess.PIPE,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                try:
                    child.stdin.write(base64.b64encode(sock.share(child.pid)) + b"\n")
                except OSError:
                    child.stdin.write(b"\n")
                child.stdin.close()
            elif sock is not None:                                    # 그 밖(맥·리눅스)
                fd = sock.fileno()
                os.set_inheritable(fd, True)
                subprocess.Popen(args + ["--sock-fd", str(fd)], cwd=str(self.root), pass_fds=(fd,))
            else:
                subprocess.Popen(args, cwd=str(self.root), creationflags=flags, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except OSError as exc:
            self.journal.exception("다시 시작", exc)
            return
        _say("\n새 버전으로 다시 시작했어요. 이 창은 닫아도 돼요.")
        if self.request_shutdown:
            self.request_shutdown()

    def admin_publish(self, p: dict) -> dict:
        """관리자: 이 PC의 프로그램 파일을 새 버전으로 배포."""
        latest = str((self.cloud.control or {}).get("latest_version") or "")
        if latest and version_tuple(VERSION) <= version_tuple(latest):
            raise ValueError(f"이미 {latest} 버전이 배포돼 있어요. 이 PC 버전({VERSION})이 더 새것이어야 배포할 수 있어요.")
        raw, sha = updater.build_package(self.root)
        out = self._admin_rpc("admin_publish_release", {"p_version": VERSION, "p_notes": str(p.get("notes") or "")[:500],
                                                        "p_sha256": sha, "p_zip_b64": updater.to_b64(raw),
                                                        "p_auto": bool(p.get("auto", True))})
        self.journal.log("시스템", f"새 버전 {VERSION} 배포 · {len(raw) // 1024}KB", "success", "업데이트")
        try:
            self.cloud.heartbeat(self._cloud_status())
        except CloudError:
            pass
        return out

    def _admin_rpc(self, fn: str, params: dict):
        if not self.admin_ok() or not self.admin_pw:
            raise ValueError("관리자 확인이 필요해요.")
        try:
            return self.cloud.rpc(fn, {"p_pw": self.admin_pw, **params}, timeout=15)
        except CloudError as exc:
            msg = str(exc)
            if "no_admin" in msg:            # 대시보드 비밀번호가 아직 없으면 지금 관리자 비밀번호로 정한다
                if not self.cloud.rpc("admin_init", {"p_pw": self.admin_pw}):
                    raise ValueError("대시보드 비밀번호가 이미 다르게 정해져 있어요.") from None
                self.journal.log("시스템", "대시보드 관리자 비밀번호 등록", "success", "관리자")
                return self.cloud.rpc(fn, {"p_pw": self.admin_pw, **params}, timeout=15)
            if "denied" in msg:
                raise ValueError("대시보드 비밀번호가 이 PC의 관리자 비밀번호와 달라요.") from None
            raise ValueError(f"대시보드 서버 오류 · {msg[:80]}") from None

    def admin_dashboard(self, days: int = 60) -> dict:
        out = self._admin_rpc("admin_dashboard", {"p_days": max(1, min(365, int(days)))})
        out["me"] = self.cloud.install_id
        return out

    def admin_control(self, p: dict) -> dict:
        patch = {}
        if "stop_all" in p:
            patch["stop_all"] = bool(p["stop_all"])
        if "share_calendar" in p:
            patch["share_calendar"] = bool(p["share_calendar"])
        if "stop_ids" in p:
            ids = [str(x) for x in (p.get("stop_ids") or [])][:200]
            for x in ids:
                if not re.fullmatch(r"[0-9a-f-]{36}", x):
                    raise ValueError("PC 구분 값 오류")
            patch["stop_ids"] = ids
        if "min_version" in p:
            mv = str(p.get("min_version") or "").strip()
            if mv and not re.fullmatch(r"\d+(\.\d+){0,3}", mv):
                raise ValueError("버전은 2026.10.14 같은 숫자 형식으로 적어 주세요.")
            patch["min_version"] = mv
        if "notice" in p:
            patch["notice"] = str(p.get("notice") or "").strip()[:300]
        if not patch:
            raise ValueError("바꿀 내용이 없어요.")
        ctrl = self._admin_rpc("admin_control", {"p_patch": patch})
        self.journal.log("시스템", "대시보드 제어 변경 · " + ", ".join(patch), "warning", "관리자")
        try:                                       # 내 PC에도 바로 반영
            self.cloud.heartbeat(self._cloud_status())
            self._cloud_control(self.cloud.control)
            self.cloud.fetch_shared()
        except CloudError:
            pass
        return ctrl

    def admin_issue(self, issue_id: int) -> dict:
        return self._admin_rpc("admin_issue", {"p_issue": int(issue_id)}) or {}

    def admin_forget(self, install_id: str):
        if not re.fullmatch(r"[0-9a-f-]{36}", install_id or ""):
            raise ValueError("PC 구분 값 오류")
        self._admin_rpc("admin_forget_install", {"p_id": install_id})

    # ---------------------------------------------------------------- 화면 상태
    def target_view(self, snap: dict) -> list:
        out = []
        accts = snap["accounts"]
        for t in self.settings["targets"]:
            st = snap["targets"].get(t["id"])
            a = accts.get(t["account"], {})
            if st and st["status"] in (DONE, REMOVED):
                continue
            if not a.get("linked") or a.get("auth_error"):
                label, kind = "로그인 필요", "login"
            elif st and st["status"] == LIMIT:
                label, kind = "한도 대기", "limit"
            elif st and snap["running"]:
                label, kind = "예약 중", "run"
            else:
                label, kind = "대기 중", "wait"
            out.append({**t, "label": label, "kind": kind, "detail": st["message"] if st and snap["running"] else ""})
        return out

    def state(self, log_after: int = 0) -> dict:
        snap = self.engine.snapshot()
        now = self.engine.now()
        accounts = []
        for a in self.settings["accounts"]:
            info = snap["accounts"].get(a["name"], {})
            if info.get("cart"):
                ext = self.extended()
                info = {**info, "cart": [{**c, "extended": c["sid"] in ext} for c in info["cart"]]}
            st = self.acct_status.get(a["name"], {})
            accounts.append({**a, **info, "state": st.get("state", "idle"), "msg": st.get("msg", ""),
                             "profile": self.profiles.path(a["name"]).is_dir(),
                             # 창이 열렸는지는 '로그인 중' 표시로 본다. 여기서 Chrome 디버그 포트를 물어보면(계정당 최대 2초)
                             # 남아 있는 Chrome이 응답을 안 할 때 화면 갱신이 통째로 막힘(10/20 19:10 '연결 끊김' 원인)
                             "login_open": a["name"] in self.login_busy,
                             "keeper": bool(self.keepers.get(a["name"]) and self.keepers[a["name"]].is_alive())})
        return {"app": APP_ID, "version": VERSION, "csrf": self.csrf, "now": now.isoformat(), "notice": self.notice,
                "clock": snap.get("clock"), "clock_offset_ms": round(self.engine.clock_offset * 1000),
                "running": snap["running"], "test_mode": snap["test_mode"], "events": snap["events"],
                "accounts": accounts, "targets": self.target_view(snap),
                "timing": {k: self.engine.timing[k] for k in TIMING_LIMITS},
                "timing_default": {k: DEFAULT_TIMING[k] for k in TIMING_LIMITS},
                "logs": self.journal.recent(log_after), "log_saved": self.journal.saved,
                "notes": self.journal.recent_notes(30),
                "log_file": self.journal.path.name if self.journal.path else "",
                "admin": {"exists": self.admin_exists(), "ok": self.admin_ok()},
                "cloud": self.cloud.info(),
                "update": dict(self.update),
                "weather_at": self.weather.stamp(),
                "notices_at": self.notices_at,
                "shared": self.cloud.shared if (self.cloud.control or {}).get("share_calendar") else None,
                "test_at": self.test_at.isoformat() if self.test_at else None,
                "rules": {"courts": DEFAULT_RULES["courts"], "starts": SLOT_STARTS, "blocks": {k: block_rules(v) for k, v in DEFAULT_RULES["blocks"].items() if block_rules(v)},
                          "block_note": BLOCK_NOTE, "kind": COURT_KIND, "max_targets": MAX_TARGETS,
                          "open_events": DEFAULT_RULES["open_events"],
                          "lesson": DEFAULT_RULES["weekday_evening_blocked_courts"]}}

    # ---------------------------------------------------------------- 내보내기
    def export_rows(self, acct: str, month: str, kind: str) -> list[tuple]:
        names = self.names() if acct == "all" else [self._need_account(acct)]
        snap = self.engine.snapshot()["accounts"]
        rows = []
        for n in names:
            a = snap.get(n, {})
            items = a.get("cart", []) if kind == "cart" else [r for r in a.get("reservations", []) if not r["cancelled"]]
            for it in items:
                if not it.get("date") or not str(it["date"]).startswith(month):
                    continue
                s = it.get("start")
                e = it.get("end") if kind != "cart" else (s + 120 if isinstance(s, int) else None)
                tm = f"{hm(s)}~{hm(e)}" if isinstance(s, int) and isinstance(e, int) else ""
                court = f"{it['court']}번" if it.get("court") else ""
                rows.append((it["date"], tm, court) + ((n,) if acct == "all" else ()))
        return sorted(rows)

    def export_csv(self, acct: str, month: str, kind: str) -> tuple[str, bytes]:
        if not (len(month) == 7 and month[4] == "-" and month.replace("-", "").isdigit()):
            raise ValueError("달 형식 오류")
        rows = self.export_rows(acct, month, kind)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["날짜", "시간", "코트"] + (["계정"] if acct == "all" else []))
        w.writerows(rows)
        tag = "all" if acct == "all" else f"acct{self.names().index(acct) + 1}"
        name = f"songdo-{'cart' if kind == 'cart' else 'reservations'}_{tag}_{month}.csv"
        return name, ("﻿" + buf.getvalue()).encode("utf-8")

    def list_reports(self) -> list:
        out = []
        folder = self.engine.report_dir
        for f in sorted(folder.glob("*.json"), reverse=True)[:50] if folder.exists() else []:
            try:
                r = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            out.append({"file": f.name, "started": r.get("started"), "ended": r.get("ended"), "test": r.get("test"),
                        "events": [e.get("name") for e in r.get("events", [])], "totals": r.get("totals", {})})
        return out

    def read_report(self, name: str) -> dict:
        if not re.fullmatch(r"[0-9-]+\.json", name or ""):
            raise ValueError("파일 이름 오류")
        path = self.engine.report_dir / name
        if not path.exists():
            raise ValueError("없는 리포트")
        return json.loads(path.read_text(encoding="utf-8"))

    def open_logs_folder(self):
        folder = str((self.data / "logs").resolve())
        if sys.platform.startswith("win"):
            os.startfile(folder)  # noqa: S606 (로컬 폴더 열기)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])
        else:
            subprocess.Popen(["xdg-open", folder])


class Server(ThreadingHTTPServer):
    allow_reuse_address = not sys.platform.startswith("win")    # 윈도우는 아래 독점 사용으로 두 번 실행을 막음
    daemon_threads = True

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if exc is not None and not isinstance(exc, (ConnectionError, BrokenPipeError)) and getattr(self, "app", None):
            self.app.journal.exception("화면 요청 처리", exc)

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


STATIC = {"/": ("static/index.html", "text/html"), "/index.html": ("static/index.html", "text/html"),
          "/static/app.js": ("static/app.js", "application/javascript"),
          "/static/dash.js": ("static/dash.js", "application/javascript"),
          "/static/style.css": ("static/style.css", "text/css")}
CSP = ("default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; "
       "img-src 'self' data:; frame-ancestors 'none'")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    @property
    def app(self) -> App:
        return self.server.app

    def _host_ok(self):
        return self.headers.get("Host") in {f"127.0.0.1:{PORT}", f"localhost:{PORT}"}

    def _send(self, body: bytes, mime: str, code=200, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, value, code=200):
        self._send(json.dumps(value, ensure_ascii=False).encode(), "application/json; charset=utf-8", code)

    def _csv(self, name: str, body: bytes):
        self._send(body, "text/csv; charset=utf-8", extra={"Content-Disposition": f'attachment; filename="{name}"'})

    def do_GET(self):
        if not self._host_ok():
            return self._json({"error": "로컬 주소로 접속하세요."}, 403)
        u = urlsplit(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/api/health":
                return self._json({"app": APP_ID})
            if u.path == "/api/state":
                self.app.last_poll = time.time()
                return self._json(self.app.state(int(q.get("log_after", 0) or 0)))
            if u.path == "/api/admin/issue":
                return self._json(self.app.admin_issue(int(q.get("id", 0) or 0)))
            if u.path == "/api/logs":
                j = self.app.journal
                day = q.get("day") or j.day
                return self._json({"day": day, "today": j.day, "rows": j.read_day(day), "days": j.days()})
            if u.path == "/api/admin/dash":
                return self._json(self.app.admin_dashboard(int(q.get("days", 60) or 60)))
            if u.path == "/api/notices":
                return self._json({"at": self.app.notices_at, "items": self.app.notices})
            if u.path == "/api/weather":
                return self._json(self.app.weather.data or {})
            if u.path == "/api/reports":
                return self._json({"reports": self.app.list_reports()})
            if u.path == "/api/report":
                return self._json(self.app.read_report(q.get("file", "")))
            if u.path == "/api/logs.csv":
                j = self.app.journal
                day = q.get("day") or j.day
                rows = j.read_day(day)
                kind, text, run_only = q.get("kind", "all"), q.get("q", "").lower(), q.get("run") == "1"
                rows = [r for r in rows if (kind == "all" or r["lvl"] == kind or r["cat"] == kind)
                        and (not run_only or r.get("run"))
                        and (not text or text in " ".join(str(v) for v in r.values()).lower())]
                stamp = day + ("_예약실행" if run_only else "")
                return self._csv(f"songdo-log_{stamp}.csv", self.app.journal.detail_csv(rows).encode("utf-8"))
            if u.path == "/api/export.csv":
                name, body = self.app.export_csv(q.get("acct", "all"), q.get("month", ""), q.get("kind", "cart"))
                return self._csv(name, body)
        except (ValueError, KeyError) as exc:
            return self._json({"error": str(exc)}, 400)
        if u.path in STATIC:
            f, mime = STATIC[u.path]
            return self._send((ROOT / f).read_bytes(), mime + "; charset=utf-8")
        self._json({"error": "없는 주소"}, 404)

    def do_POST(self):
        a = self.app
        u = urlsplit(self.path)
        if u.path == "/api/bye" and self._host_ok():
            if parse_qs(u.query).get("c", [""])[0] == a.csrf:
                a.bye_at = time.time()
            self.send_response(204)
            self.end_headers()
            return
        if not self._host_ok() or self.headers.get("X-CSRF-Token") != a.csrf or (
                self.headers.get("Origin") and self.headers["Origin"] not in {URL, f"http://localhost:{PORT}"}):
            return self._json({"error": "화면을 새로고침한 뒤 다시 시도하세요."}, 403)
        try:
            n = int(self.headers.get("Content-Length", "0"))
            if not 0 < n <= 100_000:
                raise ValueError("요청 크기 오류")
            p = json.loads(self.rfile.read(n))
            if not isinstance(p, dict):
                raise ValueError("요청 형식 오류")
            path = urlsplit(self.path).path
            name = p.get("name")
            out = {"ok": True}
            if path == "/api/accounts/add":
                out["name"] = a.add_account(str(p.get("name") or ""))
            elif path == "/api/accounts/rename":
                a.rename_account(name, str(p.get("new", "")))
            elif path == "/api/accounts/remove":
                a.remove_account(name)
            elif path == "/api/accounts/refresh":
                a.refresh(name)
            elif path == "/api/login/open":
                a.open_login(name)
            elif path == "/api/login/check":
                a.check_login(name)
            elif path == "/api/cart/remove":
                a._need_account(name)
                if not isinstance(p.get("sid"), str):
                    raise ValueError("항목을 확인하세요.")
                ok = a.engine.remove_by_user(name, p["sid"]).result(20)
                if not ok:
                    raise ValueError("취소 결과를 확인하지 못했어요. 사이트에서 확인해 주세요.")
            elif path == "/api/targets/add":
                out["added"] = a.add_targets(p)
            elif path == "/api/targets/remove":
                a.remove_target(str(p.get("id", "")))
            elif path == "/api/targets/reorder":
                a.reorder_targets(name, [str(i) for i in p.get("ids", [])])
            elif path == "/api/start":
                a.start()
            elif path == "/api/stop":
                a.engine.stop()
            elif path == "/api/timing":
                a.set_timing(p)
            elif path == "/api/admin/login":
                a.admin_login(p.get("pw", ""))
            elif path == "/api/admin/lock":
                a.admin_lock()
            elif path == "/api/admin/control":
                out["control"] = a.admin_control(p)
            elif path == "/api/admin/publish":
                out["release"] = a.admin_publish(p)
            elif path == "/api/update/apply":
                if not a.update.get("available"):
                    raise ValueError("새 버전이 없어요.")
                ok = a.apply_update(a.update["available"], str(a.update.get("sha") or ""), manual=True)
                if not ok:
                    raise ValueError(a.update.get("error") or "업데이트하지 못했어요.")
            elif path == "/api/admin/forget":
                a.admin_forget(str(p.get("id", "")))
            elif path == "/api/test":
                a.set_test(p)
            elif path == "/api/clientlog":
                a.client_error(p)
            elif path == "/api/cart/extend":
                a._need_account(name)
                if not isinstance(p.get("sid"), str):
                    raise ValueError("항목을 확인하세요.")
                out.update(a.extend_cart(name, p["sid"]))
            elif path == "/api/quit":
                a.quit(bool(p.get("force")))
            elif path == "/api/logs/open":
                a.open_logs_folder()
            elif path == "/api/shutdown":
                if a.engine.running:
                    raise ValueError("예약 중입니다. 먼저 중지하세요.")
                threading.Thread(target=self.server.shutdown, daemon=True).start()
            else:
                return self._json({"error": "없는 작업"}, 404)
            self._json(out)
        except (ValueError, KeyError, TypeError, BrowserError) as exc:
            self._json({"error": str(exc)}, 400)
        except TimeoutError:
            self._json({"error": "응답이 늦어요. 잠시 뒤 장바구니를 다시 확인해 주세요."}, 504)
        except OSError:
            self._json({"error": "파일 처리 실패. 폴더 권한을 확인하세요."}, 500)


def _say(msg: str):
    """콘솔 안내 출력. 창 없이(pythonw·업데이트 뒤 재시작) 돌 때는 출력 통로가 없거나 끊겨 있어
    print가 OSError를 낼 수 있다(2026-10-20 업데이트 뒤 재시작 실패의 원인) → 조용히 넘긴다."""
    try:
        print(msg, flush=True)
    except (OSError, ValueError, AttributeError):
        pass


def _adopt_socket() -> socket.socket | None:
    """업데이트 뒤 다시 시작: 이전 프로그램이 넘겨준 접속 소켓을 받는다."""
    try:
        if "--sock-stdin" in sys.argv:
            line = sys.stdin.buffer.readline().strip()
            return socket.fromshare(base64.b64decode(line)) if line else None
        if "--sock-fd" in sys.argv:
            return socket.socket(fileno=int(sys.argv[sys.argv.index("--sock-fd") + 1]))
    except (OSError, ValueError, IndexError):
        return None
    return None


def main():
    for stream in (sys.stdout, sys.stderr):        # 한글을 못 쓰는 콘솔·파이프에서도 멈추지 않게
        try:
            stream.reconfigure(errors="replace")
        except (AttributeError, ValueError, OSError):
            pass
    after_update = "--after-update" in sys.argv
    server = None
    sock = _adopt_socket() if after_update else None
    if sock is not None:
        server = Server((HOST, PORT), Handler, bind_and_activate=False)
        server.socket.close()
        server.socket = sock
        server.server_address = sock.getsockname()
    for i in range(480 if after_update else 1):    # 넘겨받지 못했으면 이전 연결이 정리될 때까지(최대 4분) 기다렸다가 직접 잡음
        if server is not None:
            break
        try:
            server = Server((HOST, PORT), Handler)
            break
        except OSError:
            if after_update:
                if i % 20 == 0:
                    _say("이전 프로그램이 정리되기를 기다리는 중…")
                time.sleep(0.5)
    if server is None:
        try:
            with urlopen(URL + "/api/health", timeout=2) as r:
                if json.load(r).get("app") == APP_ID:
                    _say("이미 실행 중입니다. 화면을 엽니다.")
                    if "--no-open" not in sys.argv:
                        webbrowser.open(URL)
                    return
        except Exception:
            pass
        raise SystemExit(f"{PORT} 포트를 다른 프로그램이 쓰고 있습니다.")
    server.app = App()
    server.app.request_shutdown = lambda: threading.Thread(target=server.shutdown, daemon=True).start()
    server.app.listen_socket = server.socket
    server.app.auto_exit = True
    _say(f"Songdo Tennis {VERSION}: {URL}\n프로그램 화면(브라우저 탭)을 닫으면 프로그램도 꺼져요(예약 중이면 끝난 뒤). 이 창을 닫아도 꺼져요.")
    if (not after_update or "--open" in sys.argv) and "--no-open" not in sys.argv:
        webbrowser.open(URL)                       # 화면의 '다시 켜기'로 켜졌으면(--no-open) 열려 있는 화면이 다시 붙는다
    try:
        try:
            server.serve_forever(poll_interval=0.25)
        except OSError as exc:
            if sock is None:
                raise
            # 넘겨받은 접속 소켓이 이 PC에서 동작하지 않으면 포트를 직접 다시 잡아서 계속(업데이트 뒤 재시작)
            server.app.journal.log("시스템", f"넘겨받은 접속이 끊겨 다시 연결해요({type(exc).__name__})", "warning", "업데이트")
            try:
                server.socket.close()
            except OSError:
                pass
            for _ in range(240):
                try:
                    server.socket = socket.socket(server.address_family, server.socket_type)
                    server.server_bind()
                    server.server_activate()
                    break
                except OSError:
                    server.socket.close()
                    time.sleep(0.5)
            else:
                raise
            server.app.listen_socket = server.socket
            server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.app.engine.stop()
        for k in server.app.keepers.values():
            k.stop()
        server.server_close()
        server.app.journal.close()


if __name__ == "__main__":
    main()
