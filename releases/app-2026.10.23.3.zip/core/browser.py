"""계정별 전용 Chrome 프로필.

- 로그인: 자동화하지 않은 일반 Chrome 창을 연다. 사용자가 직접 Google 로그인한다(비밀번호는 프로그램이 다루지 않음).
- 유지: 오픈 시간대에 화면 없는(headless) Chrome으로 사이트를 열어 두면 사이트가 1시간짜리 토큰을 스스로 갱신한다.
  프로그램은 그 토큰(convex_auth_token)만 메모리로 읽는다. 갱신용 토큰은 읽지 않는다.
- 자동화 탐지 회피 설정(AutomationControlled 비활성화, UA 위장 등)은 넣지 않는다.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Callable

# Playwright가 내부에서 쓰는 Node의 사용 중단 경고(url.parse 등)가 검은 창에 찍히지 않게 한다(동작과 무관)
os.environ.setdefault("NODE_NO_WARNINGS", "1")

SITE = os.environ.get("SONGDO_SITE_OVERRIDE", "https://songdotennis.co.kr/songdo-tennis")  # 테스트용 덮어쓰기
TOKEN_KEY = "convex_auth_token"


class BrowserError(RuntimeError):
    pass


def chrome_path() -> str:
    cands = [os.environ.get("SONGDO_CHROME"), shutil.which("chrome"), shutil.which("google-chrome")]
    for var in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        if base := os.environ.get(var):
            cands.append(str(Path(base) / "Google/Chrome/Application/chrome.exe"))
    for c in cands:
        if c and Path(c).is_file():
            return c
    raise BrowserError("Google Chrome을 찾지 못했습니다. Chrome 설치 후 다시 시도하세요.")


class Profiles:
    def __init__(self, data: Path):
        self.root = data / "profiles"
        self.root.mkdir(parents=True, exist_ok=True)
        self.windows: dict[str, subprocess.Popen] = {}
        self.ports: dict[str, int] = {}

    def path(self, account: str) -> Path:
        return (self.root / hashlib.sha256(account.encode()).hexdigest()[:20]).resolve()

    def open_login(self, account: str, debug_port: int | None = None) -> None:
        """자동화하지 않은 일반 Chrome을 작은 앱 창으로 연다. debug_port가 있으면 프로그램이 이 창의 상태를 읽을 수 있다
        (로그인 끝남 감지·프로필 읽기·창 닫기용. 자동화 표시·탐지 회피 설정은 넣지 않는다)."""
        prof = self.path(account)
        prof.mkdir(parents=True, exist_ok=True)
        prev = self.windows.get(account)
        if self.window_open(account):
            raise BrowserError("이 계정의 로그인 창이 이미 열려 있습니다.")
        args = [chrome_path(), f"--user-data-dir={prof}", "--no-first-run", "--no-default-browser-check",
                f"--app={SITE}", "--window-size=560,760"]
        if debug_port:
            args += [f"--remote-debugging-port={debug_port}"]
            self.ports[account] = debug_port
        self.windows[account] = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                                 stderr=subprocess.DEVNULL)

    def window_open(self, account: str) -> bool:
        """로그인 창이 열려 있는지. Windows에서는 실행한 chrome.exe가 먼저 끝날 수 있어서 디버그 포트 응답도 본다."""
        p = self.windows.get(account)
        if p and p.poll() is None:
            return True
        port = self.ports.get(account)
        return bool(port and port_alive(port))

    def delete(self, account: str):
        shutil.rmtree(self.path(account), ignore_errors=True)


def _read_token(page) -> str | None:
    raw = page.evaluate(f"() => localStorage.getItem('{TOKEN_KEY}')")
    if not isinstance(raw, str) or not raw.strip():
        return None
    raw = raw.strip()
    if raw.startswith('"'):
        try:
            raw = json.loads(raw)
        except ValueError:
            return None
    return raw if isinstance(raw, str) and raw.count(".") == 2 else None


def token_exp(token: str) -> float:
    """JWT 만료 시각(초). 읽지 못하면 0."""
    try:
        part = token.split(".")[1]
        part += "=" * (-len(part) % 4)
        return float(json.loads(base64.urlsafe_b64decode(part)).get("exp") or 0)
    except Exception:
        return 0.0


def token_fresh(token: str | None, margin: float = 90) -> bool:
    return bool(token) and token_exp(token) > time.time() + margin


class Keeper(threading.Thread):
    """한 계정의 숨은 Chrome. interval초마다 토큰을 읽어 바뀌면 on_token(token)을 부른다."""

    def __init__(self, profiles: Profiles, account: str, on_token: Callable[[str], None],
                 on_status: Callable[[str, str], None], interval: float = 30.0, once: bool = False,
                 wait_seconds: float = 10.0):
        super().__init__(daemon=True, name=f"keeper-{account}")
        self.profiles, self.account = profiles, account
        self.on_token, self.on_status = on_token, on_status
        self.interval, self.once, self.wait_seconds = interval, once, wait_seconds
        self.stop_event = threading.Event()
        self.result: str | None = None
        self.error: str = ""

    def stop(self):
        self.stop_event.set()

    def run(self):
        if self.profiles.window_open(self.account):
            self.error = "로그인 창을 먼저 닫아 주세요(같은 프로필을 동시에 열 수 없음)."
            self.on_status("error", self.error)
            return
        prof = self.profiles.path(self.account)
        if not prof.is_dir():
            self.error = "먼저 '로그인 창 열기'로 로그인해 주세요."
            self.on_status("error", self.error)
            return
        try:
            from playwright.sync_api import sync_playwright, Error as PwError
        except ImportError:
            self.error = "playwright가 설치되지 않았습니다(시작.bat이 설치합니다)."
            self.on_status("error", self.error)
            return
        try:
            with sync_playwright() as pw:
                ctx = pw.chromium.launch_persistent_context(str(prof), executable_path=chrome_path(), headless=True,
                                                            timeout=20_000)
                try:
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                    page.goto(SITE, wait_until="domcontentloaded", timeout=20_000)
                    last, deadline = None, time.monotonic() + self.wait_seconds
                    while not self.stop_event.is_set():
                        try:
                            tok = _read_token(page)
                        except PwError:
                            tok = None
                        # 저장돼 있던 토큰이 이미 만료됐을 수 있다(사이트가 페이지를 연 뒤 새로 받아 바꿔 씀) → 만료 전 토큰만 쓴다
                        fresh = token_fresh(tok)
                        if fresh and tok != last:
                            last = tok
                            self.result = tok
                            self.on_token(tok)
                            if self.once:
                                # 사이트가 갱신 토큰을 저장하는 중일 수 있으니 잠깐 기다렸다 닫는다(로그인 풀림 방지)
                                self.stop_event.wait(4.0)
                                return
                        if not fresh and time.monotonic() > deadline and tok and token_exp(tok) > time.time() + 5:
                            # 새 토큰은 아직 안 나왔지만 지금 토큰이 살아 있음 → 만료로 보지 않는다(사이트는 끝나기 직전에야 바꿔 줌)
                            if self.once:
                                if tok != last:
                                    self.result = tok
                                    self.on_token(tok)
                                return
                            deadline = time.monotonic() + 60
                        elif not fresh and time.monotonic() > deadline:
                            self.error = ("로그인이 만료됐어요. '로그인 창 열기'로 다시 로그인해 주세요." if tok
                                          else "사이트 로그인 정보가 없어요. '로그인 창 열기'로 로그인해 주세요.")
                            self.on_status("error", self.error)
                            if self.once:
                                return
                            deadline = time.monotonic() + 300
                        if self.stop_event.wait(1.0 if (self.once or not last or not token_fresh(last, 300)) else self.interval):
                            return
                        if last and not self.once:
                            # 오래 열어둔 페이지가 멈추지 않도록 가볍게 상태만 확인
                            pass
                finally:
                    ctx.close()
        except Exception as exc:
            msg = str(exc).splitlines()[0][:160]
            self.error = "숨은 Chrome 실행 실패: " + ("프로필이 사용 중입니다(로그인 창을 닫아 주세요)" if "lock" in msg.lower() or "in use" in msg.lower() else type(exc).__name__)
            self.on_status("error", self.error)


# 화면 글자로 버튼을 찾아 누른다(사이트 자체 버튼만. Google 화면에서는 실행하지 않음)
POPUP_JS = """(() => {
  const b = [...document.querySelectorAll('[role=dialog] button, [role=alertdialog] button')]
    .find(x => x.innerText.trim() === '오늘 하루 보지 않기' && x.offsetParent !== null);
  if (b) { b.click(); return true; }
  return false;
})()"""
# Google 계정 선택 화면에서 이 계정(사이트 아이디 = Google 이메일)과 같은 항목만 누른다. 비밀번호 칸은 건드리지 않는다.
def pick_account_js(email: str) -> str:
    return ("(() => { const em = " + json.dumps((email or "").strip().lower()) + ";"
            " if (!em) return 'none';"
            " if (document.querySelector('input[type=password]')) return 'password';"
            " const els = [...document.querySelectorAll('[data-identifier],[data-email]')];"
            " const el = els.find(e => (e.getAttribute('data-identifier') || e.getAttribute('data-email') || '').trim().toLowerCase() === em);"
            " if (el && el.offsetParent !== null) { (el.closest('[role=link],[role=button],li') || el).click(); return 'clicked'; }"
            " if (document.querySelector('input[type=email]')) return 'email';"
            " return 'none'; })()")


# 사이트 로그인 서버(prime-reserve.com/login)의 '구글로 계속하기'(2026-10-20 확인: 구글/네이버 버튼 두 개)
GOOGLE_BTN_JS = """(() => {
  const b = [...document.querySelectorAll('button, a')].find(x => (x.innerText || '').trim() === '구글로 계속하기' && x.offsetParent !== null);
  if (b) { b.click(); return true; }
  return false;
})()"""


LOGIN_JS = """(() => {
  if (document.querySelector('[role=dialog]')) return false;
  const b = document.querySelector('header button[aria-label="로그인"]');
  if (b) { b.click(); return true; }
  return false;
})()"""
TOKEN_JS = "localStorage.getItem('convex_auth_token')"
PROFILE_JS = """(() => {
  const n = document.querySelector('#profile-name'), e = document.querySelector('#profile-email');
  return n && n.value ? JSON.stringify({name: n.value.trim().slice(0, 20), email: (e && e.value || '').trim().slice(0, 80)}) : '';
})()"""


def _http_json(port: int, path: str, timeout: float = 2.0):
    import urllib.request
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # 시스템 프록시를 거치지 않게
    with opener.open(f"http://127.0.0.1:{port}{path}", timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def port_alive(port: int) -> bool:
    try:
        _http_json(port, "/json/version", 0.8)       # 이 PC 안의 포트라 짧게(응답 없는 Chrome에 오래 붙잡히지 않게)
        return True
    except Exception:
        return False


def free_port() -> int:
    import socket
    with socket.socket() as sk:
        sk.bind(("127.0.0.1", 0))
        return sk.getsockname()[1]


class MiniCDP:
    """Chrome 디버그 웹소켓에 짧게 붙어 명령 하나씩 보내는 최소 클라이언트(표준 라이브러리만, 모든 단계에 시간 제한)."""

    def __init__(self, ws_url: str, timeout: float = 3.0):
        import socket
        from urllib.parse import urlsplit
        u = urlsplit(ws_url)
        self.sock = socket.create_connection((u.hostname, u.port), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {u.path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.sock.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("handshake closed")
            buf += chunk
        if b" 101 " not in buf.split(b"\r\n", 1)[0]:
            raise ConnectionError("handshake refused")
        self.rest = buf.split(b"\r\n\r\n", 1)[1]
        self.next_id = 0

    def _recv_exact(self, n: int) -> bytes:
        while len(self.rest) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("closed")
            self.rest += chunk
        out, self.rest = self.rest[:n], self.rest[n:]
        return out

    def _send(self, text: str):
        data = text.encode()
        hdr = bytearray([0x81])
        n = len(data)
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr += bytes([0x80 | 126]) + n.to_bytes(2, "big")
        else:
            hdr += bytes([0x80 | 127]) + n.to_bytes(8, "big")
        mask = os.urandom(4)
        self.sock.sendall(bytes(hdr) + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def _recv_msg(self) -> str:
        parts = b""
        while True:
            b1, b2 = self._recv_exact(2)
            op, n = b1 & 0x0F, b2 & 0x7F
            if n == 126:
                n = int.from_bytes(self._recv_exact(2), "big")
            elif n == 127:
                n = int.from_bytes(self._recv_exact(8), "big")
            mask = self._recv_exact(4) if b2 & 0x80 else None
            payload = self._recv_exact(n)
            if mask:
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
            if op == 0x8:
                raise ConnectionError("closed")
            if op in (0x9, 0xA):
                continue
            parts += payload
            if b1 & 0x80:
                return parts.decode("utf-8", "replace")

    def call(self, method: str, params: dict | None = None, timeout: float = 3.0):
        self.next_id += 1
        mid = self.next_id
        self._send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            msg = json.loads(self._recv_msg())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(str(msg["error"])[:120])
                return msg.get("result", {})
        raise TimeoutError(method)

    def eval(self, expr: str, timeout: float = 3.0):
        r = self.call("Runtime.evaluate", {"expression": expr, "returnByValue": True, "awaitPromise": False}, timeout)
        return (r.get("result") or {}).get("value")

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


def _eval_target(target: dict, expr: str, timeout: float = 3.0):
    c = MiniCDP(target["webSocketDebuggerUrl"], timeout)
    try:
        return c.eval(expr, timeout)
    finally:
        c.close()


class LoginWatcher(threading.Thread):
    """로그인 창 도우미. 사용자가 연 일반 Chrome 창(디버그 포트)을 0.5초마다 새로 살펴본다:
    - 사이트 팝업 공지는 '오늘 하루 보지 않기'와 같은 기록을 저장소에 넣어 안 뜨게 하고(남으면 버튼을 누름),
      사이트의 '로그인' 버튼을 한 번 눌러 준다.
    - Google·로그인 서버 화면에서는 아무것도 하지 않는다(계정 선택·비밀번호는 사용자가).
    - 사이트 화면에 만료 전 토큰이 생기면 창을 바로 숨기고(화면 밖으로, 안 되면 최소화), 숨긴 채로 프로필 화면에서
      이름·이메일만 읽은 뒤(전화번호는 읽지 않음) 창을 닫는다.
    매번 Chrome에 목록을 새로 물어보므로 다른 사이트를 다녀와도 놓치지 않는다.
    on_done(token, profile_dict)  / on_status(state, msg)
    """

    AUTO_LIMIT = 75            # 자동 다시 로그인: 이 안에 안 끝나면 창을 보여 주고 사용자에게 넘김
    GOOGLE_WAIT = 12           # Google 화면에서 고를 계정이 안 보이면 이만큼 기다린 뒤 넘김

    def __init__(self, profiles: Profiles, account: str, port: int, on_done, on_status, timeout: float = 600,
                 on_log=None, popup_ids=None, today: str = "", auto_email: str = "", on_need_user=None, on_end=None):
        super().__init__(daemon=True, name=f"login-{account}")
        # auto_email: 프로그램을 오래 꺼 둬서 사이트 로그인이 풀렸을 때, 창을 숨긴 채 로그인 버튼 → Google 계정 선택(이 이메일)까지만
        # 자동으로 누른다. 비밀번호·2단계 인증·처음 보는 화면이 나오면 창을 보여 주고 사용자에게 넘긴다.
        self.auto_email = auto_email
        self.on_need_user = on_need_user or (lambda why: None)
        self.on_end = on_end or (lambda done: None)    # 도우미가 끝나면(로그인 완료 여부) 항상 호출
        self.done = False
        self.profiles, self.account, self.port = profiles, account, port
        self.on_done, self.on_status, self.timeout = on_done, on_status, timeout
        self.log = on_log or (lambda msg, level="info": None)
        self._popup_src, self.popup_ids, self.today = popup_ids, [], today
        self.last_error = ""
        self.stop_event = threading.Event()

    def stop(self):
        self.stop_event.set()

    def _site_targets(self) -> list | None:
        try:
            lst = _http_json(self.port, "/json/list", 2.0)
        except Exception:
            return None
        return [t for t in lst if t.get("type") == "page" and "webSocketDebuggerUrl" in t]

    def _note_error(self, exc):
        msg = f"{type(exc).__name__}: {str(exc).splitlines()[0][:120] if str(exc) else ''}"
        if msg != self.last_error:
            self.last_error = msg
            self.log(f"로그인 창 도우미 재시도 · {msg}")

    def run(self):
        try:
            self._run()
        finally:
            try:
                self.on_end(self.done)
            except Exception:
                pass

    def _run(self):
        # 연결 대기
        deadline = time.monotonic() + 25
        while time.monotonic() < deadline and not self.stop_event.is_set() and self._site_targets() is None:
            time.sleep(0.5)
        if self._site_targets() is None:
            self.log("로그인 창 도우미 연결 실패 · 창의 디버그 포트가 응답하지 않음", "warning")
            return
        self.log("로그인 창 도우미 연결됨")
        src = self._popup_src

        def load_ids():                       # 공지 목록은 기다리지 않는다(그동안은 버튼 누르기로 닫음)
            try:
                self.popup_ids = list((src() if callable(src) else src) or [])
            except Exception as exc:
                self.log(f"공지 목록 조회 실패 · {type(exc).__name__}", "warning")
            if not self.popup_ids:
                self.log("팝업 공지 ID가 없어 버튼 누르기로 닫음")
        threading.Thread(target=load_ids, daemon=True).start()
        clicked_login, closed, misses, last_hosts = False, 0, 0, None
        host_since, slow_told = time.monotonic(), False
        reloaded: set = set()
        end = time.monotonic() + self.timeout
        why = "시간 초과(10분)"
        auto = bool(self.auto_email)
        auto_end = time.monotonic() + self.AUTO_LIMIT
        picked, google_since, went_google, g_clicks, g_at = False, None, False, 0, 0.0
        if auto:
            first = (self._site_targets() or [None])[0]
            if first:
                self.log(f"자동 다시 로그인 시작 · 창 숨김({self._hide(first)})")

        def hand_over(reason: str):
            nonlocal auto, end
            auto = False
            end = time.monotonic() + self.timeout
            for t in (self._site_targets() or [])[:1]:
                self._show(t)
            self.log(f"자동 다시 로그인 안 됨 · {reason} · 창을 띄워 사용자에게 넘김", "warning")
            self.on_status("login", f"자동 로그인이 안 됐어요({reason}) · 띄운 창에서 직접 로그인해 주세요")
            self.on_need_user(reason)

        while time.monotonic() < end and not self.stop_event.is_set():
            if auto and time.monotonic() > auto_end:
                hand_over("시간 초과")
            targets = self._site_targets()
            if targets is None:
                misses += 1
                if misses >= 4:
                    why = "로그인 창이 닫힘"
                    break
                time.sleep(0.5)
                continue
            misses = 0
            hosts = sorted({(t.get("url", "").split("/") + ["", "", ""])[2] for t in targets})
            if hosts != last_hosts:
                last_hosts, host_since, slow_told = hosts, time.monotonic(), False
                self.log("로그인 창 화면: " + (", ".join(h for h in hosts if h) or "없음"))
            # 사이트 로그인 서버에서 오래 멈춤 → 사이트 응답이 늦은 것. 창은 건드리지 않고 안내만
            if not auto and not slow_told and time.monotonic() - host_since > 40 and any("prime-reserve" in h for h in hosts) \
                    and not any("songdotennis" in h for h in hosts):
                slow_told = True
                self.log("사이트 로그인 서버에서 40초 넘게 멈춤(사이트 응답 지연)", "warning")
                self.on_status("login", "사이트 응답이 늦어요 · 로그인 창에서 F5(새로고침)를 눌러 보세요")
            if auto:
                pr = [t for t in targets if "prime-reserve" in t.get("url", "") and "/login" in t.get("url", "")]
                # 화면이 막 뜬 직후엔 버튼이 아직 동작하지 않을 수 있어(10/20 박철환3), 4초 지나도 그대로면 다시 누른다(최대 4번)
                if pr and g_clicks < 4 and time.monotonic() - g_at > 4:
                    try:
                        if _eval_target(pr[0], GOOGLE_BTN_JS):
                            went_google, g_clicks, g_at = True, g_clicks + 1, time.monotonic()
                            self.log("'구글로 계속하기' 자동으로 누름" + (f"({g_clicks}번째)" if g_clicks > 1 else ""))
                    except Exception as exc:
                        self._note_error(exc)
                gt = [t for t in targets if "accounts.google." in t.get("url", "")]
                if gt and not picked:
                    google_since = google_since or time.monotonic()
                    try:
                        r = _eval_target(gt[0], pick_account_js(self.auto_email))
                    except Exception as exc:
                        self._note_error(exc)
                        r = "none"
                    if r == "clicked":
                        picked = True
                        self.log("Google 계정 선택 자동으로 누름(같은 아이디)")
                    elif r == "password":
                        hand_over("Google이 비밀번호 확인을 요구함")
                    elif r == "email":
                        hand_over("Google 로그인이 풀려 있음")
                    elif time.monotonic() - google_since > self.GOOGLE_WAIT:
                        hand_over("고를 계정이 안 보임")
                elif gt and picked and google_since and time.monotonic() - google_since > self.GOOGLE_WAIT + 10:
                    hand_over("계정을 고른 뒤 Google 화면이 남아 있음(추가 확인 필요)")
            for t in targets:
                if "songdotennis" not in t.get("url", ""):
                    continue                          # Google·로그인 서버 화면은 건드리지 않음(자동 다시 로그인은 위에서 계정 선택만)
                try:
                    tok = _eval_target(t, TOKEN_JS)
                    if isinstance(tok, str) and tok.startswith('"'):
                        tok = json.loads(tok)
                    if token_fresh(tok):
                        how = self._hide(t)
                        self.on_status("checking", "로그인 완료 · 이름과 아이디를 불러오는 중")
                        self.log(f"로그인 확인 · 창 숨김({how}) · 프로필 읽는 중")
                        profile = self._read_profile(t)
                        self.done = True
                        self.on_done(tok, profile)
                        self.stop_event.wait(4.0)    # 사이트가 갱신 정보를 저장할 시간
                        self._close()
                        self.log("로그인 창 닫음")
                        return
                    dismiss = self._dismiss_script()
                    if dismiss and t["id"] not in reloaded:
                        reloaded.add(t["id"])
                        _eval_target(t, dismiss)
                        if _eval_target(t, "!!document.querySelector('[role=dialog]')"):
                            _eval_target(t, "location.reload()")
                            self.log(f"공지 팝업 {len(self.popup_ids)}개 오늘 하루 보지 않기 처리")
                            continue
                    if _eval_target(t, POPUP_JS):
                        closed += 1
                        continue
                    if not clicked_login and _eval_target(t, LOGIN_JS):
                        clicked_login = True
                        self.log(f"공지 {closed}개 닫고 로그인 버튼 누름")
                        self.on_status("login", "자동으로 다시 로그인하는 중" if auto else "Google 계정을 골라 로그인해 주세요")
                except Exception as exc:
                    self._note_error(exc)
            time.sleep(0.5)
        self.log(f"로그인 창 도우미 끝 · {why}")

    def _dismiss_script(self) -> str:
        if not self.popup_ids or not self.today:
            return ""
        return ("(() => { try { if (!location.href.includes('songdotennis')) return false;"
                " const k = 'prime_reserve_dismissed_popups'; const d = JSON.parse(localStorage.getItem(k) || '{}');"
                f" for (const id of {json.dumps(self.popup_ids)}) d[id] = {json.dumps(self.today)};"
                " localStorage.setItem(k, JSON.stringify(d)); return true; } catch (e) { return false; } })()")

    def _show(self, target: dict):
        """숨겨 둔 창을 다시 화면에 보이게(자동 로그인이 안 됐을 때)."""
        try:
            ver = _http_json(self.port, "/json/version", 2.0)
            c = MiniCDP(ver["webSocketDebuggerUrl"], 3.0)
            try:
                wid = c.call("Browser.getWindowForTarget", {"targetId": target["id"]}, 3.0)["windowId"]
                c.call("Browser.setWindowBounds", {"windowId": wid, "bounds": {"windowState": "normal"}}, 3.0)
                c.call("Browser.setWindowBounds", {"windowId": wid, "bounds": {"left": 120, "top": 80}}, 3.0)
            finally:
                c.close()
        except Exception as exc:
            self._note_error(exc)

    def _hide(self, target: dict) -> str:
        """로그인이 끝난 창을 안 보이게: 화면 밖으로 옮기고, 그게 안 되면 최소화. 창은 그대로 살아 있어서 뒤 작업은 계속된다."""
        try:
            ver = _http_json(self.port, "/json/version", 2.0)
            c = MiniCDP(ver["webSocketDebuggerUrl"], 3.0)
            try:
                wid = c.call("Browser.getWindowForTarget", {"targetId": target["id"]}, 3.0)["windowId"]
                c.call("Browser.setWindowBounds", {"windowId": wid, "bounds": {"windowState": "normal"}}, 3.0)
                c.call("Browser.setWindowBounds", {"windowId": wid, "bounds": {"left": -32000, "top": -32000}}, 3.0)
                b = c.call("Browser.getWindowBounds", {"windowId": wid}, 3.0).get("bounds", {})
                if b.get("left", 0) <= -10000:
                    return "화면 밖"
                c.call("Browser.setWindowBounds", {"windowId": wid, "bounds": {"windowState": "minimized"}}, 3.0)
                return "최소화"
            finally:
                c.close()
        except Exception as exc:
            self._note_error(exc)
            return "실패"

    def _read_profile(self, target: dict) -> dict:
        """프로필 화면의 이름·이메일 칸만 읽는다. 저장 버튼은 누르지 않는다."""
        try:
            _eval_target(target, "location.href = location.origin + '/profile'")
            deadline = time.monotonic() + 12
            while time.monotonic() < deadline:
                time.sleep(0.5)
                for t in self._site_targets() or []:
                    if "/profile" not in t.get("url", ""):
                        continue
                    try:
                        v = _eval_target(t, PROFILE_JS)
                    except Exception:
                        continue
                    if v:
                        return json.loads(v)
        except Exception as exc:
            self._note_error(exc)
        return {}

    def _close(self):
        try:
            ver = _http_json(self.port, "/json/version", 2.0)
            c = MiniCDP(ver["webSocketDebuggerUrl"], 3.0)
            try:
                c.call("Browser.close", {}, 3.0)
            except Exception:
                pass
            c.close()
        except Exception as exc:
            self._note_error(exc)
