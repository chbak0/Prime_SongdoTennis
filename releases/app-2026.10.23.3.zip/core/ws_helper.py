"""실시간(WebSocket) 칸 구독 도우미 — 별도 프로세스로 실행.

본 프로그램 안에서 convex 클라이언트의 비동기 구독(anext)을 쓰면 첫 결과만 오고 그 뒤 변화가 오지 않았다
(10/20·10/23 오픈 기록: ws_first 뒤 실시간 변화 0건). 그래서 공식 클라이언트의 '동기' 방식으로,
본 프로그램과 떨어진 프로세스에서 모든 구독을 하나의 반복(watch_all)으로 받아 결과를 한 줄씩 JSON으로 내보낸다.
이 프로세스가 멈추거나 죽어도 본 프로그램(조회·담기)은 영향을 받지 않는다.

  python -I ws_helper.py <backend_url> '<[{"id": "...", "path": "...", "args": {...}}, ...]>'
출력(한 줄에 하나): {"id": ..., "value": ...} / {"id": ..., "error": "..."} / {"ready": n}
읽기 전용 조회 구독만 한다(담기·빼기 같은 변경은 하지 않음).
"""
from __future__ import annotations

import json
import sys
import threading

_lock = threading.Lock()


def emit(obj) -> None:
    line = json.dumps(obj, ensure_ascii=False, default=str)
    with _lock:
        try:
            sys.stdout.write(line + "\n")
            sys.stdout.flush()
        except (OSError, ValueError):
            raise SystemExit(0)                  # 본 프로그램이 닫음 → 끝


def watch(client, sid: str, path: str, args: dict) -> None:
    last = None
    try:
        sub = client.subscribe(path, args)
        for value in sub:                        # 동기 반복: 값이 바뀔 때마다 하나씩
            text = json.dumps(value, sort_keys=True, default=str)
            if text != last:
                last = text
                emit({"id": sid, "value": value})
    except SystemExit:
        raise
    except Exception as exc:                     # noqa: BLE001
        emit({"id": sid, "error": f"{type(exc).__name__}: {str(exc)[:120]}"})


def unwrap(v):
    """watch_all 결과는 {type, value} 형태일 수도, 값 그대로일 수도 있다."""
    if isinstance(v, dict) and v.get("type") in ("value", "convexerror", "error") and ("value" in v or "message" in v):
        if v["type"] == "value":
            return v.get("value"), None
        return None, str(v.get("message") or v.get("type"))[:120]
    return v, None


def main(argv: list[str]) -> int:
    """구독을 모두 걸고, 하나의 반복(watch_all)으로 모든 결과를 받는다.
    (구독마다 스레드를 두고 동기 반복하면 한 구독만 진행되고 나머지가 멈췄다: 10/23 점검에서 8곳 중 1곳만 첫 결과)"""
    url, subs = argv[1], json.loads(argv[2])
    from convex import ConvexClient
    client = ConvexClient(url)
    keep, idmap = [], {}
    for s in subs:
        sub = client.subscribe(s["path"], s.get("args") or {})
        keep.append(sub)                         # 붙잡아 둬야 구독이 유지됨
        idmap[sub.id] = str(s["id"])
    emit({"ready": len(keep)})
    last: dict = {}
    for snapshot in client.watch_all():
        if not snapshot:
            continue
        for sub_id, raw in snapshot.items():
            ours = idmap.get(sub_id)
            if ours is None:
                continue
            value, err = unwrap(raw)
            if err:
                if last.get(ours) != ("err", err):
                    last[ours] = ("err", err)
                    emit({"id": ours, "error": err})
                continue
            text = json.dumps(value, sort_keys=True, default=str)
            if last.get(ours) != text:
                last[ours] = text
                emit({"id": ours, "value": value})
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
