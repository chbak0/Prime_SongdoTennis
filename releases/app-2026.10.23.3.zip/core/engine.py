"""감시·담기 엔진.

흐름(오픈마다):  대기 → 준비(오픈 N분 전) → 미리 확인(오픈 N초 전) → 러시(오픈~N초) → 사후 감시(N분) → 종료
- 공개 슬롯은 WebSocket 구독(오픈 60초 전부터)과 HTTP 재조회(미리 확인부터)를 함께 쓴다. 먼저 온 쪽으로 판단.
- 계정별 작업자 1개가 담기를 순서대로 처리한다. 같은 계정에서 동시에 쓰지 않는다.
- 한도: 만든 날 5건, 같은 이용일 3건. 장바구니·결과 확인 중·방금 빠진(결제로 넘어가는 중일 수 있는) 항목도
  포함해 계산한다. 날짜를 모르는 장바구니 항목은 모든 날짜에 포함시킨다(보수적).
- 시도는 적게: 목표당 담기 요청은 max_attempts번까지. 그 뒤에는 그 칸이 '닫힘→열림'으로 바뀔 때만 다시 시도.
  거절되면 reject_cooldown초 쉰다.
- 담기 응답이 끊기면 그 요청이 끝날 때까지 다시 보내지 않고, 한도 계산에도 넣어 둔다.
- 빼기는 사용자가 화면에서 누른 항목만. 자동 교체·자동 빼기는 하지 않는다.
- 예약 생성·확정·결제·취소 함수는 없다(rules.check_allowed).
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import re
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from .journal import Journal
from .rules import (KST, TENANT, Target, capacity, hm, is_cancelled, open_event_for, price, slot_available)
from .transport import BACKEND, AuthExpired, RateGate, RateLimited, Rejected, Transport, Unknown, check_allowed

SLOTS_Q = "slots/queries:listByFacilityAndDatePublic"
FAC_Q = "facilities/queries:listByTenantSlug"
OPEN_Q = "slotOpenRules/queries:getNextOpenForMonth"
ANN_Q = "tenantAnnouncements/queries:listByTenantSlug"
ME_Q = "users/queries:currentUser"
CART_IDS_Q = "cart/queries:listMySlotIds"
CART_LIST_Q = "cart/queries:list"
RES_Q = "reservations/queries:listMyReservationsPaginated"
ADD_M = "cart/mutations:add"
REMOVE_M = "cart/mutations:remove"

# 2026-09-23 수집, 2026-10-13 12번 코트 일치 확인. 서버 조회가 실패할 때만 사용.
FALLBACK_FACILITIES = {
    5: "m9787fez1x2bp21pqr0x8dvx317x9qf9", 6: "m978zp6vrw0w11er8yz6x2qzk17x9khv",
    7: "m9764dajj4f06nkp0d6jrvjpqd7xaxge", 8: "m976pg32eekdexh0xrefzpk4t97xbg6z",
    9: "m977z2za3ec6v43gfk7p4nc6fx7xabxq", 10: "m973cgbwa1d7gfbdf1exqn04t97xabdt",
    11: "m972rjmrm4ktyv30vg6hsxpvzh7xadwt", 12: "m979pkhytj09c63e1mx79mg7m97xbrc1",
    13: "m978g4bjz22bjyzkxr01b4z4qx7xbyve", 14: "m971jqwc9320js03vz18mgcmp17xah1k",
    15: "m97465ggdha291khbvsndkb0vh7xa21t", 16: "m97cxedxgkw0556dsab19nrzhx7xac5q",
    17: "m975kendczwmx4bf2kkfdwcsrs7xbgpw",
}

DEFAULT_TIMING = {
    "prepare_minutes": 10, "pre_seconds": 5, "rush_seconds": 60, "after_minutes": 30,
    "rush_poll": 1.0, "after_poll": 5.0, "http_rps": 4.0, "ws_lead_seconds": 150,
    "verify_seconds": 20.0, "reject_cooldown": 2.0, "max_attempts": 4, "cart_hold_hours": 5,
    "now_delay": 3.0, "gone_grace": 15.0,
    # 사이트는 정각에 칸 만들기를 시작해 약 12초 뒤에야 칸이 보인다(10/20 10:00·20:00 두 번 모두).
    # 이 구간(오픈 후 burst_from~burst_to초)에는 초당 상한을 꽉 채워 촘촘히 조회한다.
    "burst_from": 5.0, "burst_to": 30.0,
    "poll_timeout_rush": 1.5,     # 러시 중 응답 없는 조회는 이만큼만 기다리고 다음 조회로
    "inflight_max": 3,            # 한 곳(코트·날짜)에 동시에 나가 있을 수 있는 조회 수(느린 응답에 안 붙잡히게)
    "add_slow_ms": 800,           # 담기 응답이 이만큼 늦으면 장바구니를 바로 확인(다시 보내지는 않음)
    "hedge_ms": 500,              # '바로 조회'의 응답이 이만큼 늦으면 같은 조회를 한 번 더(느린 서버 대비, 소식당 1번)
}
# 설정 화면에서 바꿀 수 있는 값과 범위
TIMING_LIMITS = {"pre_seconds": (0, 30), "rush_seconds": (10, 600), "after_minutes": (0, 180), "prepare_minutes": (1, 30)}

DONE, WATCH, WAIT, ADDING, VERIFY, LIMIT, BLOCKED, STOPPED, ENDED, REMOVED = (
    "done", "watching", "waiting", "adding", "verifying", "limit", "blocked", "stopped", "ended", "removed")
ACTIVE_PHASES = ("미리 확인", "러시", "사후 감시")


def token_info(token: str) -> dict:
    """JWT의 만료·주체만 읽는다(서명 검증 없음, 표시용). 토큰 자체는 반환하지 않는다."""
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload))
        sub = str(data.get("sub", ""))
        return {"exp": data.get("exp"), "who": hashlib.sha256(sub.encode()).hexdigest()[:10] if sub else ""}
    except Exception:
        return {"exp": None, "who": ""}


@dataclass
class Pending:
    tid: str
    sent_at: float
    deadline: float
    inflight: object = None        # concurrent.futures.Future | None


@dataclass
class Account:
    name: str
    token: str | None = field(default=None, repr=False)
    exp: float | None = None
    who: str = ""
    transport: Transport | None = field(default=None, repr=False)
    cart_ids: set = field(default_factory=set)
    cart_info: dict = field(default_factory=dict)        # slotId -> {date, start, court, created}
    cart_first_seen: dict = field(default_factory=dict)
    cart_applied_at: float = 0.0                          # 마지막으로 반영한 장바구니 조회의 '보낸 시각'
    recently_gone: dict = field(default_factory=dict)    # slotId -> 빠진 시각(결제로 넘어가는 중일 수 있음)
    reservations: list = field(default_factory=list)
    res_slot_ids: set = field(default_factory=set)
    program_added: dict = field(default_factory=dict)    # slotId -> target id (보낸 뒤 장바구니에서 확인된 것만)
    pending: dict = field(default_factory=dict)          # slotId -> Pending
    self_removed: set = field(default_factory=set)       # 사용자 요청으로 뺀 slotId(유예 계산에서 제외)
    auth_error: str = ""
    profile: dict = field(default_factory=dict)          # {name, email} 사이트 프로필(전화번호 등은 저장 안 함)
    synced_at: float = 0.0
    last_refresh_req: float = 0.0
    dirty: asyncio.Event | None = None
    tasks: list = field(default_factory=list)
    add_tasks: set = field(default_factory=set)          # 진행 중인 담기 요청(병렬)


@dataclass
class TState:
    target: Target
    event_key: str
    status: str = WAIT
    message: str = "오픈 대기"
    attempts: int = 0
    last_attempt: float = 0.0
    slot_id: str | None = None
    slot_state: str = ""
    cooldown_until: float = 0.0
    done_at: str = ""


@dataclass
class Event:
    key: str
    name: str
    at: datetime
    target_ids: list
    phase: str = "대기"
    source: str = "공지 규칙"
    ends_at: datetime | None = None


def _int(v):
    """서버는 숫자를 실수로 보낸다(예: 360.0). 정수 값이면 int로 바꾸고, 아니면 None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return None


def _cart_item_info(item) -> tuple[str | None, dict]:
    """cart/queries:list 항목에서 (slotId, {date,start,facility,created})를 최대한 찾는다(형식 미확인이라 여러 모양 허용)."""
    if not isinstance(item, dict):
        return None, {}
    slot = item.get("slot") if isinstance(item.get("slot"), dict) else {}
    sid = item.get("slotId") or slot.get("_id")
    info = {
        "date": item.get("date") or slot.get("date"),
        "start": _int(item.get("startMinute")) if item.get("startMinute") is not None else _int(slot.get("startMinute")),
        "facility": item.get("facilityId") or slot.get("facilityId"),
        "created": item.get("_creationTime") or item.get("createdAt"),
        "locked_until": item.get("lockedUntil") if isinstance(item.get("lockedUntil"), (int, float)) else None,
    }
    return (sid if isinstance(sid, str) else None), {k: v for k, v in info.items() if v is not None}


class Engine:
    def __init__(self, journal: Journal, transport_factory=None, timing: dict | None = None,
                 now=None):
        self.journal = journal
        self.timing = {**DEFAULT_TIMING, **{k: v for k, v in (timing or {}).items() if k in DEFAULT_TIMING}}
        self.gate = RateGate(self.timing["http_rps"])
        self.make_transport = transport_factory or (lambda token: Transport(token, self.gate))
        # 실시간 칸 구독을 별도 프로세스(core/ws_helper.py)로. 실제 사이트에 붙을 때만(테스트의 가짜 연결에서는 기존 방식)
        self.ws_helper = transport_factory is None
        self.ws_helper_script = ""                   # 테스트용(가짜 도우미)
        self.selftest_until = 0.0                    # 실시간 점검이 끝나는 시각(time.time) · 그때까지 화면을 닫아도 안 꺼짐
        # 서버 시각 = PC 시각 + clock_offset. 오픈 시각 판단은 모두 보정된 시각으로 한다.
        self.clock_offset = 0.0
        self.clock: dict | None = None             # 마지막 측정 결과
        self.measure_clock = None                  # () -> dict | None (app이 넣음. 테스트에선 없음)
        self.now = now or (lambda: datetime.now(KST) + timedelta(seconds=self.clock_offset))
        self.lock = threading.RLock()
        self.accounts: dict[str, Account] = {}
        self.states: dict[str, TState] = {}
        self.events: dict[str, Event] = {}
        self.facilities: dict[int, str] = {}
        self.slots: dict[tuple, dict] = {}          # (date, court, start) -> slot
        self.seen_state: dict[tuple, str] = {}       # (source, key) -> 상태 문자열
        self.reopened: dict[tuple, float] = {}       # key -> 마지막으로 '닫힘→열림'이 된 시각
        self.slot_meta: dict[str, tuple] = {}        # slotId -> (date, court, start)
        self.warned: set = set()
        # 러시 동안 HTTP 줄(초당 상한)을 칸 조회에만 쓰기: 이 시각(monotonic)까지 계정 장바구니 정기 새로고침을 멈춤
        self.quiet_until = 0.0
        # 한 칸 조회에서 '열림'을 처음 보면 다른 (코트, 날짜) 조회를 바로 깨우는 신호
        self.kicks: dict[tuple, asyncio.Event] = {}
        self.kicked: set = set()                     # 이미 깨운 이벤트(실행당 1번)
        self.poll_applied: dict[tuple, float] = {}  # (시설, 날짜) → 마지막으로 반영한 조회를 보낸 시각
        self.polled_once: set = set()                # (출처, 시설, 날짜) 한 번이라도 응답을 받은 곳
        self.running = False
        self.test_mode = False
        self.run_id = 0
        self.public: Transport | None = None
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run_loop, daemon=True, name="engine")
        self.thread.start()
        self.main_task = None
        self.stats: dict = {"http": {"n": 0, "ms_sum": 0, "ms_max": 0, "errors": 0, "rate_limited": 0}, "targets": {}}
        self.report_dir = journal.folder.parent / "reports"
        self.last_report: dict | None = None
        self.on_report = None                        # 실행 요약이 저장되면 호출(관리자 대시보드 업로드용)

    # ------------------------------------------------------------------ 기반
    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def call(self, coro, timeout=None):
        return asyncio.run_coroutine_threadsafe(coro, self.loop).result(timeout)

    def submit(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def _poke(self, acct: Account):
        if acct.dirty is not None:
            try:
                self.loop.call_soon_threadsafe(acct.dirty.set)
            except RuntimeError:
                pass

    def set_timing(self, values: dict):
        with self.lock:
            for k, (lo, hi) in TIMING_LIMITS.items():
                if k in values:
                    self.timing[k] = max(lo, min(hi, float(values[k])))

    # ------------------------------------------------------------------ 계정
    def ensure_account(self, name: str) -> Account:
        with self.lock:
            if name not in self.accounts:
                self.accounts[name] = Account(name)
            return self.accounts[name]

    def remove_account(self, name: str):
        with self.lock:
            acct = self.accounts.pop(name, None)
        if acct and acct.transport:
            acct.transport.close()

    def rename_account(self, old: str, new: str):
        with self.lock:
            acct = self.accounts.pop(old)
            acct.name = new
            self.accounts[new] = acct

    def link_token(self, name: str, token: str) -> dict:
        info = token_info(token)
        with self.lock:
            for other in self.accounts.values():
                if other.name != name and info["who"] and other.who == info["who"]:
                    raise ValueError(f"이 로그인은 이미 '{other.name}' 계정에 연결돼 있습니다.")
            acct = self.ensure_account(name)
            changed = acct.token != token
            if acct.who and info["who"] and acct.who != info["who"]:
                acct.profile = {}
            acct.token, acct.exp, acct.who, acct.auth_error = token, info["exp"], info["who"], ""
            if acct.transport is None:
                acct.transport = self.make_transport(token)
            elif changed:
                acct.transport.set_token(token)
        if changed:
            self.journal.log(name, "로그인 정보 연결/갱신", cat="계정")
            self._poke(acct)
        return info

    def announcements(self, timeout: float = 8):
        """사이트 공지 원본 목록(공개 조회 1번). 실패하면 None."""
        async def run():
            self.public = self.public or self.make_transport(None)
            return await self.public.query(ANN_Q, {"tenantSlug": TENANT}, timeout=timeout)
        try:
            v = self.call(run(), timeout=timeout + 1)
            return v if isinstance(v, list) else None
        except Exception as exc:
            self.journal.event("http_error", detail=f"공지 조회 실패 {type(exc).__name__}")
            return None

    def popup_ids(self, timeout: float = 5) -> list[str]:
        """사이트의 팝업 공지 ID 목록(공개 조회 1번). 실패하면 빈 목록."""
        async def run():
            self.public = self.public or self.make_transport(None)
            v = await self.public.query(ANN_Q, {"tenantSlug": TENANT}, timeout=timeout)
            return [a["_id"] for a in v if isinstance(a, dict) and a.get("isPopup") and isinstance(a.get("_id"), str)] \
                if isinstance(v, list) else []
        try:
            return self.call(run(), timeout=timeout + 1)
        except Exception as exc:
            self.journal.event("http_error", detail=f"공지 목록 조회 실패 {type(exc).__name__}: {str(exc)[:100]}")
            return []

    def token_fresh(self, name: str, margin: float = 120) -> bool:
        a = self.accounts.get(name)
        return bool(a and a.token and a.exp and a.exp - time.time() > margin)

    def rush_quiet(self) -> bool:
        return any(e.phase in ("미리 확인", "러시") for e in self.events.values()) or time.monotonic() < self.quiet_until

    def _request_refresh(self, acct: Account):
        if time.monotonic() - acct.last_refresh_req > 3:
            acct.last_refresh_req = time.monotonic()
            self.submit(self.refresh_account(acct))

    async def refresh_account(self, acct: Account) -> None:
        """장바구니·예약을 HTTP로 한 번 읽는다."""
        if not acct.transport:
            return
        try:
            sent = time.monotonic()
            ids = await acct.transport.query(CART_IDS_Q, {"tenantSlug": TENANT})
            try:
                items = await acct.transport.query(CART_LIST_Q, {"tenantSlug": TENANT})
                if isinstance(items, list):
                    for it in items:
                        sid, info = _cart_item_info(it)
                        if sid and info:
                            acct.cart_info.setdefault(sid, {}).update(info)
            except (Rejected, Unknown, RateLimited):
                pass
            self._set_cart(acct, ids, sent)
            res = await acct.transport.query(RES_Q, {"tenantSlug": TENANT, "paginationOpts": {"numItems": 100, "cursor": None}})
            self._set_reservations(acct, res)
            if not acct.profile:
                try:
                    me = await acct.transport.query(ME_Q, {})
                    if isinstance(me, dict) and isinstance(me.get("name"), str):
                        acct.profile = {"name": me["name"].strip()[:20], "email": str(me.get("email") or "")[:80]}
                except (Rejected, Unknown, RateLimited):
                    pass
            acct.auth_error = ""
            acct.synced_at = time.time()
        except AuthExpired as exc:
            if not acct.auth_error:
                self.journal.log(acct.name, "로그인 만료 · 장바구니/예약 조회 안 됨", "warning", "계정",
                                 notify=True, key=f"auth:{acct.name}")
            acct.auth_error = str(exc)
        except (Rejected, Unknown, RateLimited) as exc:
            self.journal.log(acct.name, f"장바구니/예약 조회 실패: {type(exc).__name__}", "warning", "통신")

    def remove_by_user(self, name: str, sid: str):
        """화면의 '취소' 버튼. 장바구니에 실제로 있는 항목만. 실행 중이면 그 목표는 다시 담지 않는다."""
        acct = self.accounts.get(name)
        if not acct or not acct.transport:
            raise ValueError("로그인 확인이 필요합니다.")
        if sid not in acct.cart_ids:
            raise ValueError("장바구니에 없는 항목입니다. 새로고침 후 다시 시도하세요.")
        for st in list(self.states.values()):
            if st.target.account == name and st.slot_id == sid:
                st.status, st.message = REMOVED, "사용자가 장바구니에서 취소 · 다시 담지 않음"

        async def run():
            label = self._label_sid(sid, acct)
            self.journal.log(name, f"장바구니 취소 요청 · {label}", cat="장바구니")
            ok = await self._remove(acct, sid)
            self.journal.event("user_remove", account=name, slot=label, result="완료" if ok else "확인 실패")
            self.journal.log(name, f"장바구니 취소 {'완료' if ok else '확인 실패 · 사이트에서 확인'} · {label}",
                             "success" if ok else "error", "장바구니", notify=True)
            return ok
        return self.submit(run())

    def extend_by_user(self, name: str, sid: str):
        """화면의 '시간 연장'(사용자가 직접 누름, 같은 칸 1번만은 app이 관리). 빼고 바로 다시 담는다.
        빼는 순간 칸이 모두에게 열리므로 그 사이 다른 사람이 담으면 잃을 수 있다(화면에서 미리 알림).
        반환 future → (결과, 문구): ok / lost / kept(빼지 못해 그대로) / unknown"""
        acct = self.accounts.get(name)
        if not acct or not acct.transport:
            raise ValueError("로그인 확인이 필요합니다.")
        if self.running:
            raise ValueError("예약 실행 중에는 연장할 수 없어요. 실행이 끝난 뒤에 해 주세요.")
        if sid not in acct.cart_ids:
            raise ValueError("장바구니에 없는 항목입니다. 새로고침 후 다시 시도하세요.")

        async def run():
            label = self._label_sid(sid, acct)
            self.journal.log(name, f"시간 연장 요청 · {label} · 빼고 바로 다시 담기", cat="장바구니")
            was_program = sid in acct.program_added
            acct.self_removed.add(sid)
            t0 = time.monotonic()
            # 1) 빼기: 확실히 빠졌을 때만 다시 담는다
            try:
                res = await acct.transport.mutation(REMOVE_M, {"slotId": sid, "tenantSlug": TENANT})
                if isinstance(res, dict) and res.get("success") is False:
                    raise Rejected("빼기 실패")
            except (Rejected, RateLimited, AuthExpired) as exc:
                acct.self_removed.discard(sid)
                self.journal.log(name, f"시간 연장 안 함 · 빼지 못해서 그대로 둠({str(exc)[:40]}) · {label}", "warning", "장바구니", notify=True)
                return "kept", "빼지 못해서 그대로 두었어요"
            except Unknown:
                try:
                    sent = time.monotonic()
                    self._set_cart(acct, await acct.transport.query(CART_IDS_Q, {"tenantSlug": TENANT}, timeout=2.5), sent)
                except Exception:
                    pass
                if sid in acct.cart_ids:
                    acct.self_removed.discard(sid)
                    return "kept", "응답이 불확실해서 그대로 두었어요"
            # 2) 바로 다시 담기
            gap = round((time.monotonic() - t0) * 1000)
            result = "unknown"
            try:
                await acct.transport.mutation(ADD_M, {"slotId": sid, "tenantSlug": TENANT})
                result = "ok"
            except Rejected as exc:
                result = "lost"
                self.journal.event("add_result", account=name, target=f"연장 {label}", result="거절", detail=str(exc))
            except (Unknown, RateLimited, AuthExpired):
                result = "unknown"
            # 3) 실제 장바구니·남은 시간 다시 읽기
            await self.refresh_account(acct)
            if sid in acct.cart_ids:
                result = "ok"
                if was_program:
                    acct.program_added[sid] = acct.program_added.get(sid) or "extend"
            elif result != "lost":
                result = "lost"
            ms = round((time.monotonic() - t0) * 1000)
            self.journal.event("user_extend", account=name, slot=label, result=result, ms=ms, detail=f"빼고 다시 담기까지 {gap}ms")
            if result == "ok":
                self.journal.log(name, f"시간 연장 완료 · {label}", "success", "장바구니", notify=True)
                return "ok", "다시 담았어요 · 자동취소 시간이 새로 시작돼요"
            self.journal.log(name, f"시간 연장 실패 · 다시 담지 못함(다른 사람이 담았을 수 있음) · {label}", "error", "장바구니", notify=True)
            return "lost", "다시 담지 못했어요 · 다른 사람이 먼저 담았을 수 있어요"
        return self.submit(run())

    def refresh_now(self, name: str):
        acct = self.accounts.get(name)
        if acct:
            return self.submit(self.refresh_account(acct))

    def _set_cart(self, acct: Account, ids, sent_at: float):
        """sent_at: 그 조회를 '보낸' 시각. 더 먼저 보낸 조회의 늦은 응답은 무시한다(오래된 스냅샷 방지)."""
        if not isinstance(ids, list) or sent_at < acct.cart_applied_at:
            return
        acct.cart_applied_at = sent_at
        new = set()
        for i in ids:                     # 형식 미확인: 문자열 ID 또는 {slotId}/{slot:{_id}} 객체 모두 허용
            sid = i if isinstance(i, str) else _cart_item_info(i)[0]
            if sid:
                new.add(sid)
        now_wall, now = time.time(), time.monotonic()
        for sid in new - acct.cart_ids:
            acct.cart_first_seen.setdefault(sid, now_wall)
            acct.recently_gone.pop(sid, None)
            p = acct.pending.pop(sid, None)
            if p:                                   # 프로그램이 보낸 담기가 실제로 반영됨
                acct.program_added[sid] = p.tid
            self.journal.event("cart_seen", account=acct.name, slot=self._label_sid(sid, acct),
                               result="프로그램" if p else "기존/직접", ms=round((now - p.sent_at) * 1000) if p else "")
        for sid in acct.cart_ids - new:
            acct.cart_first_seen.pop(sid, None)
            acct.program_added.pop(sid, None)
            if sid in acct.self_removed:
                acct.self_removed.discard(sid)
            else:
                acct.recently_gone[sid] = now      # 사용자가 결제로 넘겼을 수 있음 → 잠깐 한도에 유지
            self.journal.event("cart_gone", account=acct.name, slot=self._label_sid(sid, acct))
        acct.cart_ids = new
        self._poke(acct)

    def _set_reservations(self, acct: Account, value):
        page = value.get("page") if isinstance(value, dict) else value
        if isinstance(page, list):
            acct.reservations = [r for r in page if isinstance(r, dict)]
            acct.res_slot_ids = {r["slotId"] for r in acct.reservations if isinstance(r.get("slotId"), str)}
            self._poke(acct)

    # ------------------------------------------------------------------ 슬롯 장부
    def court_of(self, facility) -> int | None:
        for src in (self.facilities, FALLBACK_FACILITIES):
            for c, f in src.items():
                if f == facility:
                    return c
        return None

    def slot_where(self, sid: str, acct: Account | None = None) -> tuple | None:
        """slotId → (date, court, start). 슬롯 조회나 장바구니 목록에서 알게 된 만큼."""
        m = self.slot_meta.get(sid)
        if m:
            return m
        info = acct.cart_info.get(sid) if acct else None
        if info and info.get("date"):
            return (info["date"], self.court_of(info.get("facility")), info.get("start"))
        return None

    def _label_sid(self, sid: str, acct: Account | None = None) -> str:
        m = self.slot_where(sid, acct)
        if m:
            court = f" {m[1]}번" if m[1] else ""
            start = f" {hm(m[2])}" if isinstance(m[2], int) else ""
            return f"{m[0]}{court}{start}"
        return f"슬롯 …{sid[-6:]}"

    def on_slots(self, facility: str, date: str, value, source: str):
        if not isinstance(value, list):
            self.journal.event("bad_response", source=source, detail=f"{date} 목록 형식 아님")
            return
        court = self.court_of(facility)
        if court is None:
            return
        touched = False
        seen_before = (source, facility, date) in self.polled_once   # 이 곳을 전에 본 적이 있어야 '새로 생김'으로 친다
        for s in value:
            start = _int(s.get("startMinute")) if isinstance(s, dict) else None
            if start is None or s.get("date", date) != date:
                continue
            key = (date, court, start)
            avail = slot_available(s) if isinstance(s.get("_id"), str) else None
            state = "열림" if avail else "판단불가" if avail is None else (
                "예약됨" if s.get("isBooked") else "다른 장바구니" if s.get("cartHeldByAnyone") else "지남" if s.get("isPast") else "불가")
            if isinstance(s.get("_id"), str):
                self.slot_meta[s["_id"]] = key
            prev = self.seen_state.get((source, key))
            if prev != state:
                self.seen_state[(source, key)] = state
                if state == "열림" and prev not in (None, "열림"):
                    self.reopened[key] = time.monotonic()
                if state == "열림":                     # 목표 칸이 열림 → 다른 곳도 바로 조회
                    self._kick_others(facility, date, key, "open")
                elif prev is None and seen_before:      # 전엔 없던 목표 칸이 새로 생김(사이트가 칸을 만듦) → 다른 곳도 바로 조회
                    self._kick_others(facility, date, key, "appear")
                if state == "열림":
                    for st in self.states.values():
                        if st.target.key == key:
                            ts = self._tstat(st)
                            if ts is not None and ts["first_open_ms"] is None:
                                ts["first_open_ms"], ts["open_source"] = self._since_open(st), source
                self.journal.event("slot_change", slot=f"{date} {court}번 {hm(key[2])}", source=source,
                                   result=state, detail=prev or "처음")
            self.slots[key] = s
            touched = True
        self.polled_once.add((source, facility, date))
        if touched:
            for acct in list(self.accounts.values()):
                self._poke(acct)
        elif value and (source, facility, date) not in self.warned:
            self.warned.add((source, facility, date))
            keys = sorted(value[0].keys())[:12] if isinstance(value[0], dict) else type(value[0]).__name__
            self.journal.log("시스템", f"{date} 슬롯 형식을 인식하지 못함({source})", "error", "통신")
            self.journal.event("bad_response", source=source, detail=f"fields={keys}")

    def _kick_others(self, facility: str, date: str, key: tuple, why: str = "open"):
        """목표 칸이 처음 열린 게 보이면, 같은 이벤트의 다른 (코트, 날짜) 조회를 차례를 기다리지 않고 바로 보낸다(이벤트당 1번)."""
        for st in self.states.values():
            if st.target.key != key:
                continue
            e = self.events.get(st.event_key)
            if not e or (e.key, why) in self.kicked or e.phase not in ("미리 확인", "러시", "사후 감시"):
                continue
            self.kicked.add((e.key, why))
            others = [g for g in self._groups(e) if g != (facility, date)]
            for g in others:
                ev = self.kicks.get(g)
                if ev:
                    ev.set()
            if others:
                self.journal.event("kick", slot=f"{date}", detail=f"{'열림' if why == 'open' else '칸 생김'} 확인 → 다른 {len(others)}곳 바로 조회")

    # ------------------------------------------------------------------ 실행 통계(실행 요약 리포트용)
    def _tstat(self, st: TState) -> dict | None:
        return self.stats["targets"].get(st.target.id)

    def _since_open(self, st: TState) -> int | None:
        ev = self.events.get(st.event_key)
        return round((self.now() - ev.at).total_seconds() * 1000) if ev else None

    def _reset_stats(self):
        self.stats = {"started": self.now().isoformat(timespec="seconds"), "test": self.test_mode,
                      "http": {"n": 0, "ms_sum": 0, "ms_max": 0, "errors": 0, "rate_limited": 0},
                      "ws": {"mode": "", "first": 0, "updates": 0, "errors": 0},
                      "targets": {tid: {"label": st.target.label, "account": st.target.account, "event": st.event_key,
                                        "date": st.target.date, "court": st.target.court, "start": st.target.start,
                                        "priority": st.target.priority, "first_open_ms": None, "open_source": "",
                                        "attempts": 0, "ok": 0, "rejected": 0, "unknown": 0, "lat": [],
                                        "done_ms": None, "reject_reasons": []}
                                  for tid, st in self.states.items()}}

    def build_report(self) -> dict:
        S = self.stats
        targets = []
        for tid, t in S.get("targets", {}).items():
            st = self.states.get(tid)
            lat = t["lat"]
            targets.append({**{k: v for k, v in t.items() if k != "lat"},
                            "lat_avg": round(sum(lat) / len(lat)) if lat else None, "lat_max": max(lat) if lat else None,
                            "result": st.status if st else "", "message": st.message if st else ""})
        targets.sort(key=lambda x: (x["account"], x["priority"]))
        h = S["http"]
        all_lat = [x for t in S.get("targets", {}).values() for x in t["lat"]]
        events = [{"name": e.name, "at": e.at.isoformat(timespec="seconds"), "source": e.source} for e in self.events.values()]
        return {"started": S.get("started"), "ended": self.now().isoformat(timespec="seconds"), "test": S.get("test"),
                "events": events, "targets": targets,
                "totals": {"targets": len(targets), "done": sum(1 for t in targets if t["result"] == DONE),
                           "attempts": sum(t["attempts"] for t in targets), "rejected": sum(t["rejected"] for t in targets),
                           "unknown": sum(t["unknown"] for t in targets),
                           "lat_avg": round(sum(all_lat) / len(all_lat)) if all_lat else None},
                "http": {"polls": h["n"], "avg_ms": round(h["ms_sum"] / h["n"]) if h["n"] else None, "max_ms": h["ms_max"],
                         "errors": h["errors"], "rate_limited": h["rate_limited"]},
                "ws": dict(S.get("ws") or {}),
                "clock": {k: self.clock[k] for k in ("offset", "error", "rtt")} if self.clock else None,
                "log_file": self.journal.path.name if self.journal.path else ""}

    def _save_report(self):
        try:
            rep = self.build_report()
            self.report_dir.mkdir(parents=True, exist_ok=True)
            name = datetime.now(KST).strftime("%Y%m%d-%H%M%S") + ".json"
            (self.report_dir / name).write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
            self.last_report = {**rep, "file": name}
            if self.on_report:
                try:
                    self.on_report(rep, name)
                except Exception:
                    pass
            T = rep["totals"]
            msg = (f"실행 요약 · 담김 {T['done']}/{T['targets']} · 시도 {T['attempts']} · 거절 {T['rejected']}"
                   + (f" · 평균 응답 {T['lat_avg']}ms" if T["lat_avg"] is not None else ""))
            self.journal.log("시스템", msg, "success" if T["done"] else "info", "엔진", notify=True)
        except Exception as exc:
            self.journal.log("시스템", f"실행 요약 저장 실패: {type(exc).__name__}", "warning")

    # ------------------------------------------------------------------ 계획
    def plan(self, targets: list[Target], start_now: bool = False, test_at: datetime | None = None) -> list[Event]:
        """목표를 오픈별로 묶는다. 이미 지난 오픈(러시까지 끝남)은 '바로 시작'으로. test_at이 있으면 전부 그 시각."""
        groups: dict[str, Event] = {}
        now = self.now()
        soon = now + timedelta(seconds=self.timing["now_delay"])
        for t in targets:
            if test_at is not None:
                key, name, at = "test" + test_at.strftime("@%m%d%H%M%S"), "테스트", test_at
            else:
                d = datetime.strptime(t.date, "%Y-%m-%d").date()
                ev = open_event_for(d, t.start)
                if start_now or ev["at"] + timedelta(seconds=self.timing["rush_seconds"]) < now:
                    key, name, at = "now" + soon.strftime("@%m%d%H%M%S"), "바로 시작", soon
                else:
                    key, name, at = ev["key"] + ev["at"].strftime("@%m%d%H%M"), ev["name"], ev["at"]
            groups.setdefault(key, Event(key=key, name=name, at=at, target_ids=[]))
            groups[key].target_ids.append(t.id)
        return sorted(groups.values(), key=lambda e: e.at)

    def arm(self, targets: list[Target], start_now: bool = False, timing: dict | None = None,
            test_at: datetime | None = None):
        with self.lock:
            if self.running:
                raise ValueError("이미 실행 중입니다. 중지한 뒤 다시 시작하세요.")
            if self.main_task is not None and not self.main_task.done():
                raise ValueError("이전 실행을 정리하는 중입니다. 몇 초 뒤 다시 시도하세요.")
            if not targets:
                raise ValueError("예약 목표를 하나 이상 넣어 주세요.")
            if timing:
                self.set_timing(timing)
            for t in targets:
                self.ensure_account(t.account)
            events = self.plan(targets, start_now, test_at)
            by_id = {t.id: t for t in targets}
            self.states = {tid: TState(by_id[tid], e.key) for e in events for tid in e.target_ids}
            self.events = {e.key: e for e in events}
            for acct in self.accounts.values():       # 이전 실행의 '프로그램 항목' 표시는 넘기지 않는다
                acct.program_added.clear()
                acct.pending.clear()
            self.test_mode = test_at is not None
            self._reset_stats()
            self.run_id += 1
            self.running = True
        self.journal.start_run("test" if test_at else events[0].key.split("@")[0])
        for e in events:
            self.journal.log("시스템", f"{e.name} 오픈 {e.at:%m/%d %H:%M:%S} · 목표 {len(e.target_ids)}개", "success")
        self.journal.notify("시스템", f"예약 시작 · 목표 {len(self.states)}개 · 첫 오픈 {events[0].at:%m/%d %H:%M}", "ok")
        self.main_task = self.submit(self._main(self.run_id))

    def stop(self):
        with self.lock:
            was = self.running
            self.running = False
        if self.main_task:
            self.main_task.cancel()
        if was:
            self.journal.log("시스템", "예약 중지", "warning")

    # ------------------------------------------------------------------ 실행
    async def _main(self, rid: int):
        states, events = self.states, self.events
        self.kicked, self.kicks, self.poll_applied, self.polled_once = set(), {}, {}, set()
        try:
            self.public = self.public or self.make_transport(None)
            await asyncio.gather(*(self._run_event(e) for e in events.values()))
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.journal.exception("예약 실행", exc)
        finally:
            for acct in self.accounts.values():
                for task in acct.tasks:
                    task.cancel()
                acct.tasks = []
                acct.dirty = None
            stopped = not self.running
            for st in states.values():
                if st.status not in (DONE, REMOVED):
                    st.status, st.message = (STOPPED, "중지됨") if stopped else (ENDED, "감시 시간 종료")
            for e in events.values():
                e.phase = "종료"
            with self.lock:
                if self.run_id == rid:
                    self.running = False
            self.journal.log("시스템", "실행 종료")
            self.journal.event("phase", detail="종료")
            self._save_report()

    async def _sleep_until(self, when: datetime):
        while True:
            left = (when - self.now()).total_seconds()
            if left <= 0:
                return
            await asyncio.sleep(min(left, 0.25))

    QUIET_AFTER_RUSH = 60

    def _phase(self, e: Event, name: str, quiet: bool = False):
        if e.phase == "러시" and name != "러시":
            self.quiet_until = max(self.quiet_until, time.monotonic() + self.QUIET_AFTER_RUSH)
        e.phase = name
        if not quiet:
            self.journal.log("시스템", f"{e.name} · {name}")
        self.journal.event("phase", detail=f"{e.name}:{name}")

    def _all_settled(self, e: Event) -> bool:
        return all(self.states[t].status in (DONE, REMOVED) for t in e.target_ids)

    def apply_clock(self, m: dict | None, where: str = "") -> dict | None:
        """측정 결과를 반영. 오차 범위가 0.5초 이하일 때만 보정한다."""
        if not m:
            return None
        from .clock import describe
        self.clock = {**m, "at": time.time()}
        if m["error"] <= 0.5:
            self.clock_offset = m["offset"]
        msg = f"{describe(m['offset'])}(±{m['error']:.2f}초)" + (" · 자동으로 맞춰서 진행해요" if abs(m["offset"]) >= 0.3 and m["error"] <= 0.5 else "")
        if abs(m["offset"]) >= 1.0:
            self.journal.log("시스템", msg + " · Windows 설정 > 시간 > 지금 동기화를 권장해요", "warning", "엔진", notify=True, key="clock",
                             window=86400)   # 알림은 하루 한 번만(로그에는 매번)
        else:
            self.journal.log("시스템", f"시계 확인{(' · ' + where) if where else ''} · {msg}", cat="엔진")
        self.journal.event("clock", detail=f"offset={m['offset']} err={m['error']} rtt={m['rtt']} n={m['n']}")
        return self.clock

    async def check_clock(self, where: str = "오픈 준비"):
        if not self.measure_clock:
            return None
        try:
            m = await asyncio.get_running_loop().run_in_executor(None, self.measure_clock)
        except Exception:
            m = None
        if m is None:
            self.journal.log("시스템", "사이트 시계를 확인하지 못했어요(PC 시계 그대로 진행)", "warning", "엔진")
            return None
        return self.apply_clock(m, where)

    async def _run_event(self, e: Event):
        T = self.timing
        await self._sleep_until(e.at - timedelta(minutes=T["prepare_minutes"]))
        self._phase(e, "준비")
        await self.check_clock()
        await self._prepare(e)
        lead = max(T["ws_lead_seconds"], T["pre_seconds"])
        await self._sleep_until(e.at - timedelta(seconds=lead))
        tasks = ([asyncio.create_task(self._watch_ws_helper(e))] if self.ws_helper
                 else [asyncio.create_task(self._watch_ws(f, d)) for f, d in self._groups(e)])
        try:
            await self._sleep_until(e.at - timedelta(seconds=T["pre_seconds"]))
            self._phase(e, "미리 확인")
            for tid in e.target_ids:
                st = self.states[tid]
                if st.status == WAIT:
                    st.status, st.message = WATCH, "확인 중"
            tasks += [asyncio.create_task(self._watch_http(f, d, e)) for f, d in self._groups(e)]
            self._poke_event(e)
            await self._sleep_until(e.at)
            self._phase(e, "러시")
            await self._sleep_until(e.at + timedelta(seconds=T["rush_seconds"]))
            if T["after_minutes"] > 0 and not self._all_settled(e):
                self._phase(e, "사후 감시")
                e.ends_at = e.at + timedelta(seconds=T["rush_seconds"], minutes=T["after_minutes"])
                while self.now() < e.ends_at and not self._all_settled(e):
                    await asyncio.sleep(0.5)
        finally:
            for w in tasks:
                w.cancel()
        for tid in e.target_ids:
            st = self.states[tid]
            if st.status not in (DONE, REMOVED):
                st.status, st.message = ENDED, "감시 시간 종료 · 담지 못함"
        self._phase(e, "종료")

    def _poke_event(self, e: Event):
        for name in {self.states[t].target.account for t in e.target_ids}:
            if name in self.accounts:
                self._poke(self.accounts[name])

    async def _prepare(self, e: Event):
        if not self.facilities:
            try:
                value = await self.public.query(FAC_Q, {"tenantSlug": TENANT})
                fac = {}
                for item in value if isinstance(value, list) else []:
                    m = re.search(r"(?<!\d)(\d{1,2})\s*번\s*코트", str(item.get("name", "")))
                    if m and isinstance(item.get("_id"), str):
                        fac[int(m[1])] = item["_id"]
                self.facilities = fac or dict(FALLBACK_FACILITIES)
            except Exception as exc:
                self.facilities = dict(FALLBACK_FACILITIES)
                self.journal.log("시스템", f"코트 목록 조회 실패({type(exc).__name__}) · 저장된 코트 ID 사용", "warning", "통신")
        # API 공개 시각: 이 오픈과 맞아 보일 때만(±3시간, 미래) 채택. 아니면 기록만.
        t0 = self.states[e.target_ids[0]].target
        if e.name not in ("바로 시작", "테스트"):
            try:
                v = await self.public.query(OPEN_Q, {"facilityId": self.facilities.get(t0.court, ""),
                                                     "month": t0.date[:7], "tenantSlug": TENANT})
                ms = v.get("openAtUtcMs") if isinstance(v, dict) else None
                if isinstance(ms, (int, float)):
                    api_at = datetime.fromtimestamp(ms / 1000, KST)
                    diff = abs((api_at - e.at).total_seconds())
                    if 60 < diff <= 3 * 3600 and api_at > self.now():
                        self.journal.log("시스템", f"{e.name} · 사이트 공개 시각 {api_at:%m/%d %H:%M}을 따름", "warning")
                        e.at, e.source = api_at, "API"
                    elif diff > 60:
                        self.journal.event("phase", detail=f"API 공개 시각 {api_at:%m/%d %H:%M} 무시(오픈과 안 맞음)")
            except Exception:
                pass
        for name in sorted({self.states[t].target.account for t in e.target_ids}):
            acct = self.accounts[name]
            if acct.transport:
                await self.refresh_account(acct)
            if acct.dirty is None:
                acct.dirty = asyncio.Event()
                acct.tasks = [asyncio.create_task(self._account_worker(acct)),
                              asyncio.create_task(self._account_sync(acct))]
            if not acct.transport or acct.auth_error:
                self.journal.log(name, "로그인 필요 · 숨은 Chrome으로 확인 중", "warning", "계정")
            else:
                self.journal.log(name, f"준비 완료 · 장바구니 {len(acct.cart_ids)}개", "success", "계정")

    def _groups(self, e: Event):
        return sorted({(self.facilities.get(self.states[t].target.court) or FALLBACK_FACILITIES.get(self.states[t].target.court),
                        self.states[t].target.date) for t in e.target_ids})

    async def _watch_ws_helper(self, e: Event):
        """실시간 칸 구독을 별도 프로세스에서(동기 방식). 결과는 한 줄씩 받아 칸 상태에 반영.
        도우미가 시작되지 않거나 죽으면 다시 띄우고(최대 5번), 그래도 안 되면 기존 방식으로."""
        groups = self._groups(e)
        W = self.stats.setdefault("ws", {"mode": "", "first": 0, "updates": 0, "errors": 0})
        W["mode"] = "helper"
        ok = await self._run_ws_helper(groups, lambda f, d, v: self.on_slots(f, d, v, "ws"), W)
        if not ok:
            W["mode"] = "inline"
            await asyncio.gather(*(self._watch_ws(f, d) for f, d in groups))

    async def _run_ws_helper(self, groups: list, on_value, W: dict, restarts: int = 5) -> bool:
        """도우미 프로세스를 돌리며 값을 on_value(시설, 날짜, 값)로 넘긴다. 끝까지 시작조차 못 하면 False."""
        subs = [{"id": str(i), "path": SLOTS_Q, "args": {"date": d, "facilityId": f, "tenantSlug": TENANT}}
                for i, (f, d) in enumerate(groups)]
        for x in subs:
            check_allowed("query", x["path"])
        script = self.ws_helper_script or os.path.join(os.path.dirname(os.path.abspath(__file__)), "ws_helper.py")
        flags = 0x08000000 if sys.platform == "win32" else 0          # CREATE_NO_WINDOW
        counts: dict[str, int] = {}
        started = False
        for attempt in range(restarts + 1):
            t0 = time.monotonic()
            try:
                proc = await asyncio.create_subprocess_exec(
                    sys.executable, "-I", script, BACKEND, json.dumps(subs), stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL, creationflags=flags, limit=4 * 1024 * 1024)
            except Exception as exc:
                self.journal.event("http_error", detail=f"실시간 도우미 시작 실패 {type(exc).__name__}")
                return started
            started = True
            try:
                while True:
                    line = await proc.stdout.readline()
                    if not line:
                        break
                    try:
                        msg = json.loads(line)
                    except ValueError:
                        continue
                    if "ready" in msg:
                        self.journal.event("ws_helper", detail=f"실시간 도우미 준비 · 구독 {msg['ready']}개")
                        continue
                    i = msg.get("id")
                    if not isinstance(i, str) or not i.isdigit() or int(i) >= len(groups):
                        continue
                    f, d = groups[int(i)]
                    if "error" in msg:
                        W["errors"] = W.get("errors", 0) + 1
                        self.journal.event("http_error", slot=d, detail=f"실시간 {str(msg['error'])[:80]}")
                        continue
                    n = counts.get(i, 0) + 1
                    counts[i] = n
                    if n == 1:
                        W["first"] = W.get("first", 0) + 1
                        self.journal.event("ws_first", slot=d, ms=round((time.monotonic() - t0) * 1000))
                    else:
                        W["updates"] = W.get("updates", 0) + 1
                        self.journal.event("ws_update", slot=d)
                    on_value(f, d, msg.get("value"))
            finally:
                if proc.returncode is None:
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                    try:
                        await asyncio.wait_for(proc.wait(), 3)
                    except Exception:
                        pass
            self.journal.event("http_error", detail=f"실시간 도우미 끝남({proc.returncode}) · 다시 시작")
            await asyncio.sleep(min(10, 1 + 2 * attempt))
        return started

    def ws_selftest(self, dates: list[str], courts: list[int], minutes: float = 30):
        """예약 실행이 아닐 때 실시간 도우미 점검(읽기 전용): 실시간으로 받은 변화와, 30초마다 직접 조회해 본 변화를 비교해 기록.
        사이트에 보내는 건 칸 조회뿐(코트·날짜당 30초에 1번)."""
        if self.running:
            raise ValueError("예약 실행 중에는 점검할 수 없어요.")
        groups = []
        for d in dates:
            for c in courts:
                f = self.facilities.get(c) or FALLBACK_FACILITIES.get(c)
                if f:
                    groups.append((f, d))
        groups = groups[:12]
        if not groups:
            raise ValueError("점검할 날짜·코트가 없어요.")
        self.selftest_until = time.time() + minutes * 60 + 30

        async def run():
            self.public = self.public or self.make_transport(None)
            W = {"mode": "selftest", "first": 0, "updates": 0, "errors": 0}
            ws_seen: dict = {}
            http_changes = {"n": 0, "ws_had": 0}

            def sig(v):
                try:
                    return json.dumps([(x.get("startMinute"), x.get("isBooked"), x.get("cartHeldByAnyone"), x.get("_id"))
                                       for x in v if isinstance(x, dict)], sort_keys=True, default=str)
                except Exception:
                    return ""

            def on_ws(f, d, v):
                ws_seen[(f, d)] = (sig(v), time.monotonic())

            self.journal.log("시스템", f"실시간 점검 시작 · {len(groups)}곳 · {minutes:g}분", cat="통신")
            helper = asyncio.create_task(self._run_ws_helper(groups, on_ws, W, restarts=2))
            last_http: dict = {}
            end = time.monotonic() + minutes * 60
            try:
                while time.monotonic() < end:
                    for g in groups:
                        try:
                            v = await self.public.query(SLOTS_Q, {"date": g[1], "facilityId": g[0], "tenantSlug": TENANT}, timeout=5.0)
                        except Exception:
                            continue
                        sg = sig(v if isinstance(v, list) else [])
                        if g in last_http and last_http[g] != sg:
                            http_changes["n"] += 1
                            if ws_seen.get(g, ("", 0))[0] == sg:
                                http_changes["ws_had"] += 1
                            self.journal.event("ws_selftest", slot=g[1],
                                               detail=f"조회에서 변화 발견 · 실시간에도 {'왔음' if ws_seen.get(g, ('', 0))[0] == sg else '안 옴'}")
                        last_http[g] = sg
                    await asyncio.sleep(30)
            finally:
                helper.cancel()
                self.selftest_until = 0.0
            msg = (f"실시간 점검 끝 · 실시간 첫 결과 {W['first']}곳 · 실시간 변화 {W['updates']}번 · "
                   f"조회로 본 변화 {http_changes['n']}번 중 실시간에도 온 것 {http_changes['ws_had']}번 · 오류 {W['errors']}")
            self.journal.log("시스템", msg, "info", "통신", notify=True)
            return {**W, **http_changes}
        return self.submit(run())

    async def _watch_ws(self, facility: str, date: str):
        args = {"date": date, "facilityId": facility, "tenantSlug": TENANT}
        failures = 0
        t0 = time.monotonic()
        silent = asyncio.get_running_loop().call_later(
            15, lambda: self.journal.event("ws_silent", slot=date, detail="실시간 구독 15초째 응답 없음 · HTTP 조회로 감시"))
        first = True
        while True:
            try:
                async for value in self.public.subscribe(SLOTS_Q, args):
                    failures = 0
                    if first:
                        first = False
                        silent.cancel()
                        self.journal.event("ws_first", slot=date, ms=round((time.monotonic() - t0) * 1000))
                    self.on_slots(facility, date, value, "ws")
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                failures += 1
                if failures == 1:
                    self.journal.log("시스템", f"{date} 실시간 구독 끊김 · HTTP로 계속", "warning", "통신")
                    self.journal.event("http_error", slot=date, detail=f"ws {type(exc).__name__}")
                await asyncio.sleep(min(10, 2 * failures))

    def _poll_interval(self, e: Event) -> float:
        """조회 간격. 사후 감시는 느리게, 칸이 생기는 구간(burst)에는 초당 상한을 나눠 촘촘히."""
        T = self.timing
        if e.phase == "사후 감시":
            return T["after_poll"]
        since = (self.now() - e.at).total_seconds()
        if T["burst_from"] <= since <= T["burst_to"]:
            n = max(1, len(self._groups(e)))
            return max(0.25, n / max(0.5, T["http_rps"]))
        return T["rush_poll"]

    async def _watch_http(self, facility: str, date: str, e: Event):
        """칸 조회. 정해진 간격마다 보내되 앞 조회의 응답을 기다리지 않는다(동시에 최대 inflight_max개).
        차례(초당 상한 줄)를 기다리는 중에 다른 곳에서 목표 칸이 보이면(kick) 기다림을 끊고 맨 앞으로 보낸다.
        늦게 온 응답이 더 새 응답을 덮어쓰지 않도록 보낸 순서로 거른다."""
        args = {"date": date, "facilityId": facility, "tenantSlug": TENANT}
        T = self.timing
        key = (facility, date)
        kick = self.kicks.setdefault(key, asyncio.Event())
        kick.clear()
        inflight: set = set()
        urgent = False
        hedge = None                                   # (바로 조회 작업, 한 번 더 보낼 시각)
        try:
            while True:
                interval = self._poll_interval(e)
                t0 = time.monotonic()
                if len(inflight) < max(1, int(T["inflight_max"])) + (1 if urgent else 0):
                    if not urgent:
                        deadline = time.monotonic() + self.gate.reserve()
                        while True:                    # 줄에서 차례를 기다리되, 소식이 오거나 바로 조회가 늦으면 맨 앞으로
                            now = time.monotonic()
                            rem = deadline - now
                            hp = hedge is not None and hedge[0] is not None and not hedge[0].done()
                            if hp:
                                rem = min(rem, hedge[1] - now)
                            if rem <= 0:
                                if hp and now >= hedge[1]:
                                    urgent = True
                                    self.journal.event("http_hedge", slot=date, ms=T["hedge_ms"])
                                break
                            try:
                                await asyncio.wait_for(kick.wait(), rem)
                                urgent, hedge = True, None
                                break
                            except asyncio.TimeoutError:
                                continue
                    if urgent:
                        self.gate.reserve(urgent=True)
                    elif kick.is_set():
                        urgent = True                  # 차례가 온 바로 그때 소식이 옴 → 이 조회가 소식을 반영(늦으면 한 번 더)
                    kick.clear()                       # 지금 보내는 조회가 그 소식을 반영한다
                    timeout = T["poll_timeout_rush"] if e.phase in ("미리 확인", "러시") else 3.0
                    task = asyncio.create_task(self._poll_once(key, args, time.monotonic(), urgent, timeout))
                    inflight.add(task)
                    task.add_done_callback(inflight.discard)
                    if urgent and hedge is None:
                        hedge = (task, time.monotonic() + T["hedge_ms"] / 1000)
                    elif urgent:
                        hedge = (None, 0.0)            # 한 번 더 보냈음 → 이 소식에 대해선 끝
                urgent = False
                while True:                            # 다음 차례까지 쉬되, 그 사이 소식이 오거나 바로 조회가 늦으면 바로 조회
                    left = interval - (time.monotonic() - t0)
                    pending = hedge and hedge[0] is not None and not hedge[0].done()
                    if pending:
                        left = min(left, hedge[1] - time.monotonic())
                    try:
                        await asyncio.wait_for(kick.wait(), max(0.0, left))
                        urgent, hedge = True, None
                        break
                    except asyncio.TimeoutError:
                        if pending and time.monotonic() >= hedge[1] and not hedge[0].done():
                            urgent = True              # 바로 조회 응답이 늦음 → 같은 조회 한 번 더
                            self.journal.event("http_hedge", slot=date, ms=T["hedge_ms"])
                            break
                        if time.monotonic() - t0 >= interval:
                            break
                if hedge and (hedge[0] is None or hedge[0].done()) and not urgent:
                    hedge = None
        finally:
            for t in list(inflight):
                t.cancel()

    async def _poll_once(self, key: tuple, args: dict, sent: float, urgent: bool, timeout: float):
        facility, date = key
        try:
            value = await self.public.query(SLOTS_Q, args, timeout=timeout, skip_gate=True)
            if sent < self.poll_applied.get(key, 0.0):
                return                                  # 더 나중에 보낸 조회가 먼저 반영됨 → 오래된 응답은 버림
            self.poll_applied[key] = sent
            self.on_slots(facility, date, value, "http")
            ms = round((time.monotonic() - sent) * 1000)
            self.journal.event("http_poll", slot=date, ms=ms, **({"detail": "바로 조회"} if urgent else {}))
            h = self.stats["http"]
            h["n"] += 1; h["ms_sum"] += ms; h["ms_max"] = max(h["ms_max"], ms)
        except asyncio.CancelledError:
            raise
        except RateLimited as rl:
            self.journal.log("시스템", f"요청 제한(429) · {rl.wait:.0f}초 대기", "warning", "통신",
                             notify=True, key="429")
            self.stats["http"]["rate_limited"] += 1
            self.journal.event("rate_limited", detail=f"{rl.wait:.1f}s")
            self.gate.pause(rl.wait)
        except (Unknown, Rejected) as exc:
            self.journal.event("http_error", slot=date, detail=str(exc))
            self.stats["http"]["errors"] += 1
        except Exception as exc:
            self.journal.event("http_error", slot=date, detail=type(exc).__name__)

    async def _account_sync(self, acct: Account):
        """장바구니 ID·예약을 WebSocket으로 구독, 그리고 HTTP 주기 조회로 보강. 로그인 전이면 기다린다."""
        while acct.transport is None:
            await asyncio.sleep(1.0)
        await self.refresh_account(acct)
        self._poke(acct)

        async def sub(path, args, apply):
            fails = 0
            while True:
                try:
                    async for v in acct.transport.subscribe(path, args):
                        fails = 0
                        apply(v)
                except asyncio.CancelledError:
                    raise
                except AuthExpired as exc:
                    acct.auth_error = str(exc)
                    await asyncio.sleep(5)
                except Exception:
                    fails += 1
                    await asyncio.sleep(min(10, 2 * fails))

        async def poll():
            last = time.monotonic()
            synced_after_done = False
            while True:
                await asyncio.sleep(1)
                if self.rush_quiet():
                    # 러시 동안은 정기 새로고침을 멈춘다(담기 성공은 담기 응답·실시간 연결로 확인).
                    # 이 계정 목표가 이번 러시에서 모두 담기면 그때 1번만 새로고침해 실제 장바구니·남은 시간을 맞춘다.
                    mine = [st for st in self.states.values() if st.target.account == acct.name
                            and (self.events.get(st.event_key) and self.events[st.event_key].phase in ("미리 확인", "러시"))]
                    if mine and not synced_after_done and all(st.status in (DONE, REMOVED) for st in mine):
                        synced_after_done = True
                        await self.refresh_account(acct)
                        last = time.monotonic()
                    continue
                synced_after_done = False
                if time.monotonic() - last >= 15:
                    await self.refresh_account(acct)
                    last = time.monotonic()

        await asyncio.gather(sub(CART_IDS_Q, {"tenantSlug": TENANT}, lambda v: self._set_cart(acct, v, time.monotonic())),
                             sub(RES_Q, {"tenantSlug": TENANT, "paginationOpts": {"numItems": 100, "cursor": None}},
                                 lambda v: self._set_reservations(acct, v)),
                             poll())

    # ------------------------------------------------------------------ 한도
    def _cart_entries(self, acct: Account) -> list[str | None]:
        """한도에 넣을 장바구니성 항목들의 날짜 목록(None=날짜 모름)."""
        now = time.monotonic()
        sids = set(acct.cart_ids) | set(acct.pending)
        sids |= {sid for sid, t in acct.recently_gone.items()
                 if now - t < self.timing["gone_grace"] and sid not in acct.res_slot_ids}
        return [(self.slot_where(sid, acct) or (None,))[0] for sid in sids]

    def _capacity(self, acct: Account, date: str) -> dict:
        # 날짜를 모르는 항목은 이 날짜에도 포함(보수적)
        cart = [{"date": d if d else date} for d in self._cart_entries(acct)]
        return capacity(acct.reservations, cart, self.now().date(), date)

    # ------------------------------------------------------------------ 판단
    def _active_targets(self, acct: Account) -> list[TState]:
        out = []
        for st in self.states.values():
            if st.target.account != acct.name or st.status == REMOVED:
                continue
            ev = self.events.get(st.event_key)
            if ev and ev.phase in ACTIVE_PHASES:
                out.append(st)
        return sorted(out, key=lambda s: (s.target.priority, s.target.id))

    async def _account_worker(self, acct: Account):
        while True:
            await acct.dirty.wait()
            acct.dirty.clear()
            try:
                await self._evaluate(acct)
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.journal.log(acct.name, f"판단 중 오류: {type(exc).__name__}", "error")
                await asyncio.sleep(0.5)

    def _expire_pending(self, acct: Account):
        now = time.monotonic()
        for sid, p in list(acct.pending.items()):
            if sid in acct.cart_ids:
                continue                                  # _set_cart가 처리
            fut = p.inflight
            if fut is not None and not fut.done():
                p.deadline = max(p.deadline, now + 2)     # 요청이 살아 있는 동안은 다시 보내지 않음
                continue
            if fut is not None and fut.done():
                p.inflight = None
                if fut.exception() is not None:           # 늦게 '거절'로 끝남 → 바로 해제
                    p.deadline = 0
                else:                                     # 늦게 '성공'으로 끝남 → 지금부터 다시 확인 기간
                    p.deadline = now + self.timing["verify_seconds"]
                    continue
            if now > p.deadline:
                acct.pending.pop(sid)
                st = self.states.get(p.tid)
                if st and st.status in (VERIFY, ADDING):
                    st.status, st.message = WATCH, "장바구니에 반영되지 않음"
                    st.cooldown_until = now + 1.0
                self.journal.event("add_result", account=acct.name, target=st.target.label if st else sid, result="미반영")

    async def _evaluate(self, acct: Account):
        self._expire_pending(acct)
        now = time.monotonic()
        for st in self._active_targets(acct):
            t = st.target
            slot = self.slots.get(t.key)
            sid = slot.get("_id") if isinstance(slot, dict) else None
            if isinstance(sid, str) and sid in acct.cart_ids:
                if st.status != DONE:
                    st.status, st.message, st.slot_id = DONE, "장바구니 확인됨", sid
                    st.done_at = self.now().strftime("%H:%M:%S.%f")[:-3]
                    self.journal.log(acct.name, f"장바구니 담김 · {t.label}", "success", "장바구니",
                                     notify=True, key=f"done:{t.id}")
                    ts = self._tstat(st)
                    if ts is not None and ts.get("done_ms") is None:
                        ts["done_ms"] = self._since_open(st)
                continue
            if st.status == DONE:
                st.status, st.message = WATCH, "장바구니에서 사라짐 · 다시 감시"
            if isinstance(sid, str) and sid in acct.pending:
                continue
            if acct.transport is None or acct.auth_error:
                st.status, st.message = BLOCKED, "로그인 필요"
                continue
            if st.status == BLOCKED:
                st.status, st.message = WATCH, "확인 중"
            if not slot:
                st.status, st.slot_state, st.message = WATCH, "슬롯 없음", "슬롯이 아직 보이지 않음"
                continue
            avail = slot_available(slot) if isinstance(sid, str) else None
            st.slot_state = self.seen_state.get(("ws", t.key)) or self.seen_state.get(("http", t.key)) or ""
            if avail is None:
                st.status, st.message = WATCH, "응답 불완전 · 다시 확인"
                continue
            if not avail:
                st.status, st.message = WATCH, f"{st.slot_state or '불가'} · 감시 중"
                continue
            if now < st.cooldown_until:
                continue
            if st.attempts >= self.timing["max_attempts"] and self.reopened.get(t.key, 0) <= st.last_attempt:
                st.status, st.message = WATCH, f"{st.attempts}번 시도 · 다시 열리면 시도"
                continue
            # 한 계정 안에서도 병렬로 바로 보낸다. 한도(하루 5건·같은 날 3건)는 목표를 넣을 때 맞추고,
            # 넘치면 사이트가 거절한다(거절도 목표당 시도 횟수에 포함).
            t0 = time.monotonic()
            acct.pending[sid] = Pending(t.id, t0, t0 + self.timing["verify_seconds"])
            task = asyncio.create_task(self._add(acct, st, sid))
            acct.add_tasks.add(task)
            task.add_done_callback(lambda tk, a=acct: (a.add_tasks.discard(tk), self._poke(a)))

    async def _add(self, acct: Account, st: TState, sid: str) -> str:
        """담기 1회. 반환: ok / rejected / unknown / auth / limited"""
        t = st.target
        st.status, st.message, st.slot_id = ADDING, "담는 중", sid
        st.attempts += 1
        st.last_attempt = time.monotonic()
        ts = self._tstat(st) or {"attempts": 0, "ok": 0, "rejected": 0, "unknown": 0, "lat": [], "reject_reasons": []}
        ts["attempts"] += 1
        self.journal.event("add_sent", account=acct.name, target=t.label, slot=sid[-6:], detail=f"시도 {st.attempts}")
        t0 = time.monotonic()
        acct.pending[sid] = Pending(t.id, t0, t0 + self.timing["verify_seconds"])   # 보내는 순간부터 한도에 포함
        try:
            fut = asyncio.ensure_future(acct.transport.mutation(ADD_M, {"slotId": sid, "tenantSlug": TENANT}))
            try:                                    # 응답이 늦으면 기다리는 동안 장바구니를 먼저 확인(다시 보내지는 않음)
                await asyncio.wait_for(asyncio.shield(fut), self.timing["add_slow_ms"] / 1000)
            except asyncio.TimeoutError:
                self.journal.event("add_slow", account=acct.name, target=t.label, ms=self.timing["add_slow_ms"])
                self.submit(self._verify_soon(acct))
                await fut
            else:
                fut.result()
        except Rejected as exc:
            acct.pending.pop(sid, None)
            ms = round((time.monotonic() - t0) * 1000)
            st.status, st.message = WATCH, f"거절됨 · {exc}"[:60]
            st.cooldown_until = time.monotonic() + self.timing["reject_cooldown"]
            ts["rejected"] += 1; ts["lat"].append(ms)
            if str(exc)[:60] not in ts["reject_reasons"]:
                ts["reject_reasons"].append(str(exc)[:60])
            self.journal.event("add_result", account=acct.name, target=t.label, result="거절", detail=str(exc), ms=ms)
            self.journal.log(acct.name, f"담기 거절 · {t.label}", "warning", "장바구니",
                             notify=True, key=f"reject:{t.id}")
            self._request_refresh(acct)
            return "rejected"
        except AuthExpired as exc:
            acct.pending.pop(sid, None)
            acct.auth_error = str(exc)
            st.status, st.message = BLOCKED, "로그인 필요"
            self.journal.log(acct.name, "로그인 만료로 담기 중단", "error", "계정", notify=True, key=f"auth:{acct.name}")
            return "auth"
        except RateLimited as rl:
            acct.pending.pop(sid, None)
            st.status, st.message = WATCH, f"요청 제한 · {rl.wait:.0f}초 후"
            st.cooldown_until = time.monotonic() + rl.wait
            return "limited"
        except Unknown as exc:
            p = acct.pending.get(sid)
            if p:
                p.inflight = exc.inflight
            ms = round((time.monotonic() - t0) * 1000)
            if sid not in acct.cart_ids:
                st.status, st.message = VERIFY, "응답 불확실 · 장바구니로 확인 중"
            ts["unknown"] += 1
            self.journal.event("add_result", account=acct.name, target=t.label, result="불확실", detail=str(exc), ms=ms)
            self.submit(self._verify_soon(acct))
            return "unknown"
        ms = round((time.monotonic() - t0) * 1000)
        if sid in acct.pending:
            acct.pending[sid].deadline = time.monotonic() + self.timing["verify_seconds"]
            st.status, st.message = VERIFY, f"응답 {ms}ms · 반영 확인 중"
        ts["ok"] += 1; ts["lat"].append(ms)
        self.journal.event("add_result", account=acct.name, target=t.label, result="성공응답", ms=ms)
        self.submit(self._verify_soon(acct))
        return "ok"

    async def _verify_soon(self, acct: Account):
        end = time.monotonic() + self.timing["verify_seconds"]
        while acct.pending and time.monotonic() < end:
            await asyncio.sleep(0.6)
            if not acct.pending:
                break
            try:
                sent = time.monotonic()
                ids = await acct.transport.query(CART_IDS_Q, {"tenantSlug": TENANT}, timeout=3.0, urgent=True)
                self._set_cart(acct, ids, sent)
            except Exception:
                pass
        self._poke(acct)

    async def _remove(self, acct: Account, sid: str) -> bool:
        """사용자 요청 빼기 1회 + 장바구니로 확인.
        사이트 관찰(2026-10-13): cart/mutations:remove {slotId, tenantSlug} → {"success": true}"""
        acct.self_removed.add(sid)
        try:
            res = await acct.transport.mutation(REMOVE_M, {"slotId": sid, "tenantSlug": TENANT})
            if isinstance(res, dict) and res.get("success") is False:
                self.journal.event("remove_result", account=acct.name, slot=self._label_sid(sid, acct), result="success=false")
        except Unknown:
            pass                                  # 요청은 진행 중일 수 있음 → 아래에서 장바구니로 확인
        except (Rejected, RateLimited, AuthExpired) as exc:
            self.journal.event("remove_result", account=acct.name, slot=self._label_sid(sid, acct), result="응답 이상", detail=type(exc).__name__)
        for _ in range(8):
            try:
                sent = time.monotonic()
                ids = await acct.transport.query(CART_IDS_Q, {"tenantSlug": TENANT}, timeout=2.5)
                self._set_cart(acct, ids, sent)
                if sid not in acct.cart_ids:
                    return True
            except Exception:
                pass
            await asyncio.sleep(0.4)
        return False

    # ------------------------------------------------------------------ 화면
    def _res_row(self, r: dict) -> dict:
        a0, a1 = _int(r.get("startMinute")), _int(r.get("endMinute"))
        slot = r.get("slot") if isinstance(r.get("slot"), dict) else {}
        if a0 is None:
            a0, a1 = _int(slot.get("startMinute")), _int(slot.get("endMinute"))
        court = self.court_of(r.get("facilityId") or slot.get("facilityId"))
        if court is None:
            m = re.search(r"(\d{1,2})\s*번", str(r.get("facilityName", "")))
            court = int(m[1]) if m else None
        created = r.get("createdAt") or r.get("_creationTime")
        return {"id": str(r.get("_id", "")), "date": r.get("date") or slot.get("date") or "", "start": a0,
                "end": a1 if a1 is not None else (a0 + 120 if a0 is not None else None), "court": court,
                "status": str(r.get("status", "")), "cancelled": is_cancelled(r.get("status")),
                "created": created if isinstance(created, (int, float)) else None,
                "price": _int(r.get("totalPrice")) or _int(r.get("price")) or (price(a0) if a0 is not None else None)}

    def snapshot(self) -> dict:
        now = self.now()
        hold = self.timing["cart_hold_hours"] * 3600
        accts = {}
        for name, a in list(self.accounts.items()):
            cart = []
            for sid in sorted(a.cart_ids):
                where = self.slot_where(sid, a) or (None, None, None)
                info = a.cart_info.get(sid) or {}
                created = info.get("created")
                first = created / 1000 if isinstance(created, (int, float)) else a.cart_first_seen.get(sid)
                start = where[2] if isinstance(where[2], int) else None
                locked = info.get("locked_until")
                if isinstance(locked, (int, float)):      # 사이트가 알려 준 자동취소 시각(서버 시계 기준)
                    left = round(locked / 1000 - now.timestamp())
                    exact = "site"
                else:
                    left = round(hold - (time.time() - first)) if first else None
                    exact = "created" if isinstance(created, (int, float)) else ""
                cart.append({"sid": sid, "date": where[0], "court": where[1], "start": start,
                             "price": price(start) if start is not None else None,
                             "by_program": sid in a.program_added, "exact_time": exact,
                             "left_s": left})
            daily = capacity(a.reservations, [{"date": d} for d in self._cart_entries(a)], now.date(), "")
            accts[name] = {"linked": bool(a.token), "exp_in": round(a.exp - time.time()) if a.exp else None,
                           "auth_error": a.auth_error, "cart": cart,
                           "reservations": [self._res_row(r) for r in a.reservations],
                           "daily_used": daily["daily_used"], "synced_at": a.synced_at,
                           "profile": dict(a.profile)}
        targets = {s.target.id: {"status": s.status, "message": s.message, "attempts": s.attempts,
                                 "slot_state": s.slot_state}
                   for s in list(self.states.values())}
        events = [{"key": e.key, "name": e.name, "at": e.at.isoformat(), "phase": e.phase, "source": e.source,
                   "targets": len(e.target_ids)} for e in list(self.events.values())]
        return {"running": self.running, "test_mode": self.test_mode, "accounts": accts, "targets": targets,
                "clock": dict(self.clock) if self.clock else None, "clock_offset": self.clock_offset,
                "events": events}
