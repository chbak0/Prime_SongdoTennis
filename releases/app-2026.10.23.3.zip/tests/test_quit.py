"""화면의 '프로그램 끄기' 버튼과 다시 켜기용 주소 등록."""
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import app as appmod
from core.engine import Engine
from core.journal import Journal
from test_engine import FakeServer, FakeTransport


class QuitTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=d, engine=self.eng, start_threads=False)
        self.down = []
        self.app.request_shutdown = lambda: self.down.append(time.time())
        self.app.auto_exit = True

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_quit_now(self):
        t0 = time.time()
        self.app.quit()
        time.sleep(0.7)
        self.assertEqual(len(self.down), 1)
        self.assertLess(self.down[0] - t0, 1.0)            # 15초 기다리지 않음
        self.assertFalse(self.app.auto_exit)

    def test_running_needs_force(self):
        self.eng.running = True
        stopped = []
        self.eng.stop = lambda: stopped.append(1)
        with self.assertRaises(ValueError):
            self.app.quit()
        self.app.quit(force=True)
        time.sleep(0.6)
        self.assertEqual(stopped, [1])
        self.assertEqual(len(self.down), 1)

    def test_protocol_registration_skipped_off_windows(self):
        self.assertFalse(appmod.App.register_protocol(Path(self.tmp.name)))


if __name__ == "__main__":
    unittest.main()


class AutoReloginAppTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        self.eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(FakeServer(), tok))
        self.app = appmod.App(data=d, engine=self.eng, start_threads=False)
        self.app.add_account("A")
        self.app.settings["accounts"][0]["login_id"] = "me@gmail.com"
        self.app.profiles.path("A").mkdir(parents=True)
        self.calls = []
        self.app.open_login = lambda name, auto_email="": self.calls.append((name, auto_email))

    def tearDown(self):
        self.app.journal.close()
        self.tmp.cleanup()

    def test_expired_login_tries_auto_once_per_hour(self):
        self.app.status("A", "error", "사이트 로그인 정보가 없어요. '로그인 창 열기'로 로그인해 주세요.")
        time.sleep(0.3)
        self.assertEqual(self.calls, [("A", "me@gmail.com")])
        self.assertEqual(self.app.acct_status["A"]["state"], "login")
        self.app.status("A", "error", "사이트 로그인 정보가 없어요. '로그인 창 열기'로 로그인해 주세요.")
        time.sleep(0.3)
        self.assertEqual(len(self.calls), 1)                  # 1시간 안에는 다시 안 함 → 사용자에게 알림
        self.assertEqual(self.app.acct_status["A"]["state"], "error")

    def test_first_login_is_manual(self):
        self.app.settings["accounts"][0]["login_id"] = ""
        self.app.status("A", "error", "사이트 로그인 정보가 없어요. '로그인 창 열기'로 로그인해 주세요.")
        time.sleep(0.3)
        self.assertEqual(self.calls, [])


class LoginWindowEndTests(unittest.TestCase):
    def test_closed_window_releases_busy(self):
        with tempfile.TemporaryDirectory() as t:
            d = Path(t)
            eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(FakeServer(), tok))
            app = appmod.App(data=d, engine=eng, start_threads=False)
            app.add_account("A")
            app.login_busy.add("A")
            app.acct_status["A"] = {"state": "login", "msg": "x"}
            app._login_window_end("A", False)
            self.assertNotIn("A", app.login_busy)
            self.assertEqual(app.acct_status["A"]["state"], "idle")
            app.journal.close()


class StateNotBlockedTests(unittest.TestCase):
    def test_state_fast_with_hung_chrome_port(self):
        """응답 없는 Chrome 디버그 포트가 남아 있어도 화면 갱신(state)은 바로 돌아와야 한다."""
        import socket
        hung = socket.socket(); hung.bind(("127.0.0.1", 0)); hung.listen(5)     # 받기만 하고 응답 안 함
        with tempfile.TemporaryDirectory() as t:
            d = Path(t)
            eng = Engine(Journal(d / "elogs"), lambda tok: FakeTransport(FakeServer(), tok))
            app = appmod.App(data=d, engine=eng, start_threads=False)
            for n in ("A", "B", "C"):
                app.add_account(n)
                app.profiles.ports[n] = hung.getsockname()[1]
            t0 = time.time()
            app.state()
            self.assertLess(time.time() - t0, 0.5)
            app.journal.close()
        hung.close()
