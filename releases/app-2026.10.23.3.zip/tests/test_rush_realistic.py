"""10/20 실제 관찰을 따라 한 러시 시뮬레이션.
- 사이트는 오픈 정각이 아니라 몇 초 뒤에 칸을 '만든다'(그 전엔 목록에 칸이 아예 없음)
- 목표 4곳(날짜 2 × 코트 2), 계정 2개, 실시간 슬롯 구독은 조용함, HTTP는 공용 줄(초당 4회) + 왕복 지연
- (느린 서버) 조회 응답 일부가 2.5초씩 걸림
확인: 칸이 생긴 뒤 모든 계정이 담기 요청을 보내기까지 걸린 시간(가장 늦은 계정 기준)."""
import asyncio
import random
import sys
import tempfile
import time
import unittest
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core.engine import SLOTS_Q, DONE, FALLBACK_FACILITIES, Engine, Target
from core.journal import Journal
from core.rules import KST
from core.transport import check_allowed
from test_engine import FakeServer, FakeTransport, jwt

D1 = (datetime.now(KST) + timedelta(days=12)).date().isoformat()
D2 = (datetime.now(KST) + timedelta(days=13)).date().isoformat()


class Site(FakeServer):
    def __init__(self):
        super().__init__()
        self.hidden = True

    def query(self, token, path, args):
        if path.startswith("slots/") and self.hidden:
            return []                                   # 칸이 아직 없음
        return super().query(token, path, args)


class Net(FakeTransport):
    gate = None
    slow_every = 0          # 조회 n번에 1번꼴(무작위)로 느리게
    count = 0
    rng = random.Random(0)

    async def subscribe(self, path, args):
        if path == SLOTS_Q:
            await asyncio.Event().wait()
        async for v in super().subscribe(path, args):
            yield v

    async def query(self, path, args, timeout=4.0, urgent=False, skip_gate=False):
        check_allowed("query", path)
        wait = self.gate.reserve(urgent, skip_gate)
        Net.count += 1
        rtt = 0.1
        if Net.slow_every and path == SLOTS_Q and Net.rng.random() < 1 / Net.slow_every:
            rtt = 2.5
        await asyncio.sleep(wait)
        if rtt > timeout:
            await asyncio.sleep(timeout)
            from core.transport import Unknown
            raise Unknown("응답 시간 초과")
        await asyncio.sleep(rtt / 2)
        v = self.server.query(self.token, path, args)    # 서버가 처리한 시점의 상태
        await asyncio.sleep(rtt / 2)
        return v


def simulate(appear_after: float, slow_every: int = 0, seed: int = 0):
    tmp = tempfile.TemporaryDirectory()
    site = Site()
    groups = [(12, D1), (13, D1), (12, D2), (13, D2)]
    for c, d in groups:
        site.make_slots(FALLBACK_FACILITIES[c], d, open_=True)
    timing = {"prepare_minutes": 0.1, "pre_seconds": 3, "rush_seconds": 20, "after_minutes": 0, "rush_poll": 1.0,
              "verify_seconds": 1.5, "now_delay": 0.3, "http_rps": 4.0, "reject_cooldown": 0.3}
    journal = Journal(Path(tmp.name))
    eng = Engine(journal, lambda tok: Net(site, tok), timing=timing)
    Net.gate, Net.slow_every, Net.count, Net.rng = eng.gate, slow_every, 0, random.Random(seed)
    eng.facilities = dict(FALLBACK_FACILITIES)
    for n in ("A", "B"):
        eng.link_token(n, jwt("u" + n))
    targets = [Target(account="A", date=D1, court=12, start=600), Target(account="A", date=D1, court=13, start=600),
               Target(account="B", date=D2, court=12, start=600), Target(account="B", date=D2, court=13, start=600)]
    sent = {}
    orig = eng._add

    async def spy(acct, st, sid):
        sent.setdefault(st.target.label, time.monotonic())
        return await orig(acct, st, sid)
    eng._add = spy
    at = datetime.now(KST) + timedelta(seconds=9)
    eng.arm(targets, test_at=at)
    time.sleep(9 + appear_after)
    appeared = time.monotonic()
    site.hidden = False                                  # 사이트가 칸을 만듦
    end = time.time() + 15
    while time.time() < end and len(sent) < 4:
        time.sleep(0.05)
    time.sleep(1.5)
    eng.stop(); journal.close(); tmp.cleanup()
    lags = sorted(round(v - appeared, 2) for v in sent.values())
    return lags


class RealisticRushTests(unittest.TestCase):
    def test_slots_created_12s_after_open(self):
        lags = simulate(appear_after=12.0)
        print(f"\\n  칸 생김(오픈+12초) → 담기 요청: {lags}")
        self.assertEqual(len(lags), 4)
        self.assertLess(lags[-1], 0.6)                  # 4곳 모두 0.6초 안

    def test_slow_server_does_not_stall(self):
        worst = []
        for seed in range(5):                            # 조회 3번에 1번꼴(무작위)로 2.5초 걸림
            lags = simulate(appear_after=7.0, slow_every=3, seed=seed)
            self.assertEqual(len(lags), 4)
            worst.append(lags[-1])
        print(f"\n  느린 서버(조회 1/3이 2.5초) · 칸 생김 → 가장 늦은 계정 담기(5번): {worst}")
        self.assertLess(sorted(worst)[2], 1.2)           # 가운데 값


if __name__ == "__main__":
    unittest.main()
