"""실행 기록.

- 화면용 짧은 로그(log): 최근 300줄. 코트 예약 화면 '실행 로그'.
- 자세한 로그(detail): log + event를 한 형식(시각·종류·계정·분류·내용)으로 최근 5000줄. 설정 '자세한 로그'.
- 파일: 하루에 하나 data/logs/YYYY-MM-DD.jsonl(자정이 지나면 새 파일)에 전부(HTTP 조회 지연 포함) 저장.
  켤 때마다 'session'(프로그램 시작·버전) 줄로 구분하고, 예약 실행은 'run start' ~ '종료' 줄로 구분한다.
  예전 형식(켤 때마다 YYYYMMDD-HHMMSS.jsonl)도 같은 날짜로 묶어서 읽는다. 지우지 않는다.
토큰·비밀번호·이름·연락처는 기록하지 않는다. 슬롯 상태·시각·결과만 남긴다.
"""
from __future__ import annotations

import csv
import io
import json
import threading
import time
import traceback
from pathlib import Path as _P
from collections import deque
from datetime import datetime
from pathlib import Path

from .rules import KST

LEVEL = {"info": "info", "success": "ok", "ok": "ok", "warning": "warn", "warn": "warn", "error": "err", "err": "err"}

# 이벤트 종류 → (분류, 기본 레벨)
EVENT_CAT = {
    "slot_change": ("슬롯", "info"), "add_sent": ("장바구니", "info"), "add_result": ("장바구니", "info"),
    "cart_seen": ("장바구니", "ok"), "cart_gone": ("장바구니", "info"), "user_remove": ("장바구니", "info"),
    "remove_result": ("장바구니", "warn"), "phase": ("엔진", "info"), "rate_limited": ("통신", "warn"),
    "http_error": ("통신", "warn"), "bad_response": ("통신", "err"), "http_poll": ("통신", "info"),
    "session": ("엔진", "ok"),
}
QUIET = {"http_poll"}   # 파일에만 남김(너무 잦음)


def _event_text(kind: str, d: dict) -> str:
    parts = [kind]
    for k in ("target", "slot", "source", "result", "detail"):
        v = d.get(k)
        if v not in (None, ""):
            parts.append(f"{k}={v}")
    if d.get("ms") not in (None, ""):
        parts.append(f"{d['ms']}ms")
    return " · ".join(parts)


class Journal:
    def __init__(self, folder: Path):
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)
        # 알림: 사람이 알아야 하는 일만. 프로그램을 다시 켜도 이어지도록 파일에 보관(최근 100개)
        self.notes_path = folder.parent / "notifications.json"
        self.notes: list = []
        try:
            self.notes = json.loads(self.notes_path.read_text(encoding="utf-8"))[-100:]
        except (OSError, ValueError):
            self.notes = []
        self.lock = threading.Lock()
        self.listeners: list = []      # 알림이 새로 생기면 호출(who, msg, level)
        self.lines: deque = deque(maxlen=300)
        self.detail: deque = deque(maxlen=5000)
        self.seq = 0
        self.saved = 0
        self.day = datetime.now(KST).strftime("%Y-%m-%d")
        self.path: Path | None = folder / f"{self.day}.jsonl"
        self.file = self.path.open("a", encoding="utf-8")

    def start_run(self, label: str):
        self.event("phase", detail=f"run start · {label}")

    def _write(self, row: dict):
        day = str(row.get("ts", ""))[:10]
        if self.file and len(day) == 10 and day != self.day:      # 자정이 지나면 그날 파일로
            self.file.close()
            self.day = day
            self.path = self.folder / f"{day}.jsonl"
            self.file = self.path.open("a", encoding="utf-8")
        if self.file:
            self.file.write(json.dumps(row, ensure_ascii=False) + "\n")
            self.file.flush()
            self.saved += 1

    def _detail(self, now: datetime, lvl: str, who: str, cat: str, msg: str):
        self.seq += 1
        self.detail.append({"id": self.seq, "ts": now.strftime("%m-%d %H:%M:%S.%f")[:-3], "lvl": lvl,
                            "acct": who if who not in ("시스템", "") else "-", "cat": cat, "msg": msg})

    def notify(self, who: str, message: str, level: str = "info", key: str | None = None, window: float = 600):
        """알림 1건. 같은 key가 window초 안에 다시 오면 새로 만들지 않고 횟수만 올린다(반복 알림 방지)."""
        now = time.time()
        lvl = LEVEL.get(level, "info")
        with self.lock:
            if key:
                for n in reversed(self.notes):
                    if n.get("key") == key and now - n["at"] < window:
                        n["count"] = n.get("count", 1) + 1
                        n["at"], n["msg"], n["level"] = now, message, lvl
                        n["id"] = max(int(now * 1000), self.notes[-1]["id"] + 1)
                        self.notes.remove(n)
                        self.notes.append(n)
                        self._save_notes()
                        return
            nid = int(now * 1000)
            if self.notes and nid <= self.notes[-1]["id"]:
                nid = self.notes[-1]["id"] + 1
            self.notes.append({"id": nid, "at": now, "who": who, "msg": message, "level": lvl, "key": key, "count": 1})
            self.notes = self.notes[-100:]
            self._save_notes()
        self._fire(who, message, lvl)

    def _fire(self, who: str, message: str, lvl: str):
        for fn in list(self.listeners):
            try:
                fn(who, message, lvl)
            except Exception:
                pass

    def exception(self, where: str, exc: BaseException, who: str = "시스템"):
        """예상 못 한 오류: 종류와 위치(파일:줄·함수)만 남긴다. 값(토큰 등)은 남기지 않는다."""
        frames = traceback.extract_tb(exc.__traceback__)[-6:]
        trace = " ← ".join(f"{_P(f.filename).name}:{f.lineno} {f.name}" for f in reversed(frames)) or "-"
        now = datetime.now(KST)
        with self.lock:
            self._detail(now, "err", who, "오류", f"{type(exc).__name__} @ {trace}")
            self._write({"ts": now.isoformat(timespec="milliseconds"), "kind": "exception", "where": where,
                         "type": type(exc).__name__, "trace": trace})
        self.log(who, f"프로그램 오류({where}) · {type(exc).__name__} · {trace.split(' ← ')[0]}", "error", "오류")

    def _save_notes(self):
        try:
            tmp = self.notes_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.notes, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.notes_path)
        except OSError:
            pass

    def recent_notes(self, n: int = 30) -> list:
        with self.lock:
            return [dict(x) for x in self.notes[-n:]]

    def log(self, who: str, message: str, level: str = "info", cat: str = "", notify: bool = False,
            key: str | None = None, window: float = 600):
        if notify:
            self.notify(who, message, level, key, window)
        elif LEVEL.get(level) == "err":       # 알림이 아닌 오류 로그도 대시보드로(알림은 notify에서 이미 보냄)
            self._fire(who, message, "err")
        now = datetime.now(KST)
        lvl = LEVEL.get(level, "info")
        cat = cat or ("엔진" if who == "시스템" else "계정")
        row = {"time": now.strftime("%H:%M:%S"), "who": who, "msg": message, "level": lvl}
        with self.lock:
            self.seq += 1
            row["id"] = self.seq
            self.lines.append(row)
            self._detail(now, lvl, who, cat, message)
            self._write({"ts": now.isoformat(timespec="milliseconds"), "kind": "log", "cat": cat, **row})

    def event(self, kind: str, **data):
        """타이밍 분석용 이벤트. kind 예: slot_change, add_sent, add_result, cart_seen, phase, http_poll."""
        now = datetime.now(KST)
        row = {"ts": now.isoformat(timespec="milliseconds"), "mono": round(time.monotonic(), 4), "kind": kind, **data}
        cat, lvl = EVENT_CAT.get(kind, ("엔진", "info"))
        res = str(data.get("result", ""))
        if kind == "add_result":
            lvl = "ok" if res == "성공응답" else "err" if res == "거절" else "warn"
        with self.lock:
            if kind not in QUIET:
                self._detail(now, lvl, str(data.get("account", "-")), cat, _event_text(kind, data))
            self._write(row)

    def recent(self, after: int = 0) -> list:
        with self.lock:
            return [r for r in self.lines if r["id"] > after]

    def detail_rows(self) -> list:
        with self.lock:
            return list(self.detail)

    def files(self) -> list:
        out = []
        for f in sorted(self.folder.glob("*.jsonl"), reverse=True)[:60]:
            out.append({"name": f.name, "size": f.stat().st_size, "current": f == self.path})
        return out

    @staticmethod
    def _day_of(name: str) -> str | None:
        stem = name[:-6] if name.endswith(".jsonl") else ""
        if len(stem) == 10 and stem[4] == "-" and stem[7] == "-":
            return stem
        if len(stem) >= 8 and stem[:8].isdigit():                 # 예전 형식 YYYYMMDD-HHMMSS
            return f"{stem[:4]}-{stem[4:6]}-{stem[6:8]}"
        return None

    def _legacy_span(self, f: Path) -> tuple[str, str]:
        """예전 형식 파일(켤 때마다 한 파일)이 걸친 날짜 범위. 자정을 넘겨 켜 둔 경우가 있어서 내용으로 본다."""
        first = last = ""
        try:
            with f.open(encoding="utf-8") as fh:
                for line in fh:
                    ts = line[8:18] if line.startswith('{"ts": "') else ""
                    if len(ts) == 10:
                        first = first or ts
                        last = ts
        except OSError:
            pass
        d = self._day_of(f.name) or ""
        return (first or d), (last or d)

    def days(self) -> list:
        """기록이 있는 날짜(최근 것부터)."""
        from datetime import date, timedelta
        ds = {self.day}
        for f in self.folder.glob("*.jsonl"):
            d = self._day_of(f.name)
            if not d:
                continue
            if len(f.stem) == 10:
                ds.add(d)
                continue
            a, b = self._legacy_span(f)
            try:
                x, y = date.fromisoformat(a), date.fromisoformat(b)
            except ValueError:
                ds.add(d)
                continue
            while x <= y and len(ds) < 400:
                ds.add(x.isoformat())
                x += timedelta(days=1)
        return sorted(ds, reverse=True)[:120]

    def read_day(self, day: str, limit: int = 20000) -> list:
        """그날 기록 전부(예전 형식 파일 포함, 시각 순). 각 줄에 run(예약 실행 구간 안인지) 표시."""
        if len(day) != 10 or day[4] != "-" or day[7] != "-" or not day.replace("-", "").isdigit():
            raise ValueError("날짜 형식 오류")
        files = []
        for f in self.folder.glob("*.jsonl"):
            d = self._day_of(f.name)
            if not d:
                continue
            if len(f.stem) == 10:
                if d == day:
                    files.append(f)
            elif d <= day:
                a, b = self._legacy_span(f)
                if a <= day <= b:
                    files.append(f)
        raw = []
        with self.lock:
            if self.file:
                self.file.flush()
        for f in files:
            try:
                with f.open(encoding="utf-8") as fh:
                    for line in fh:
                        try:
                            r = json.loads(line)
                        except ValueError:
                            continue
                        if r.get("kind") not in QUIET and str(r.get("ts", ""))[:10] == day:
                            raw.append(r)
            except OSError:
                continue
        raw.sort(key=lambda r: str(r.get("ts", "")))
        rows, in_run = [], False
        for seq, r in enumerate(raw, 1):
            kind, detail = r.get("kind"), str(r.get("detail", ""))
            if kind == "session":
                in_run = False                      # 켜고 끄면 실행 구간도 끝
            if kind == "phase" and detail.startswith("run start"):
                in_run = True
            row = self._row(seq, r)
            row["run"] = in_run
            rows.append(row)
            if kind == "phase" and detail == "종료":
                in_run = False
        return rows[-limit:]

    @staticmethod
    def _row(seq: int, r: dict) -> dict:
        kind = r.get("kind")
        ts = str(r.get("ts", ""))[5:23].replace("T", " ")
        if kind == "log":
            return {"id": seq, "ts": ts, "lvl": LEVEL.get(r.get("level", "info"), r.get("level", "info")),
                    "acct": r.get("who", "-") if r.get("who") != "시스템" else "-", "cat": r.get("cat", ""), "msg": r.get("msg", "")}
        cat, lvl = EVENT_CAT.get(kind, ("엔진", "info"))
        if kind == "add_result":
            res = str(r.get("result", ""))
            lvl = "ok" if res == "성공응답" else "err" if res == "거절" else "warn"
        msg = str(r.get("detail", "")) if kind == "session" else _event_text(kind, r)
        return {"id": seq, "ts": ts, "lvl": lvl, "acct": str(r.get("account", "-")), "cat": cat, "msg": msg}

    def read_file(self, name: str, limit: int = 5000) -> list:
        """지난 기록 파일을 자세한 로그 형식으로 읽는다(http_poll 제외)."""
        if "/" in name or "\\" in name or not name.endswith(".jsonl"):
            raise ValueError("파일 이름 오류")
        path = self.folder / name
        rows, seq = [], 0
        with path.open(encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                kind = r.get("kind")
                if kind in QUIET:
                    continue
                seq += 1
                ts = str(r.get("ts", ""))[5:23].replace("T", " ")
                if kind == "log":
                    rows.append({"id": seq, "ts": ts, "lvl": r.get("level", "info"), "acct": r.get("who", "-") if r.get("who") != "시스템" else "-",
                                 "cat": r.get("cat", ""), "msg": r.get("msg", "")})
                else:
                    cat, lvl = EVENT_CAT.get(kind, ("엔진", "info"))
                    if kind == "add_result":
                        res = str(r.get("result", ""))
                        lvl = "ok" if res == "성공응답" else "err" if res == "거절" else "warn"
                    rows.append({"id": seq, "ts": ts, "lvl": lvl, "acct": str(r.get("account", "-")), "cat": cat,
                                 "msg": _event_text(kind, r)})
        return rows[-limit:]

    def detail_csv(self, rows: list) -> str:
        names = {"info": "정보", "ok": "성공", "warn": "주의", "err": "오류"}
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["시각", "종류", "계정", "분류", "내용"])
        for r in rows:
            w.writerow([r["ts"], names.get(r["lvl"], r["lvl"]), r["acct"], r["cat"], r["msg"]])
        return "﻿" + buf.getvalue()

    def close(self):
        with self.lock:
            if self.file:
                self.file.close()
                self.file = None
